package it.gssi.cs.archqualitydef.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import it.gssi.cs.archqualitydef.services.ArchQualityDefGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalArchQualityDefParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'QualityModel'", "'{'", "';'", "'bibtex'", "','", "'}'", "'qualitydef'", "'lastupdate'", "'author='", "'and'", "'title='", "'year='", "'pages='", "'address='", "'booktitle='", "'journal='", "'chapter='", "'series='", "'volume='", "'editor='", "'organization='", "'note='", "'Cited'", "'by:'", "'@'", "'article'", "'book'", "'inbook'", "'booklet'", "'misc'", "'incollection'", "'inproceedings'", "'Metric'", "'description:'", "'['", "']'", "'QualityAttribute'", "'QualityCharacteristic'", "'->'"
    };
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int RULE_ID=5;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalArchQualityDefParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalArchQualityDefParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalArchQualityDefParser.tokenNames; }
    public String getGrammarFileName() { return "InternalArchQualityDef.g"; }



     	private ArchQualityDefGrammarAccess grammarAccess;

        public InternalArchQualityDefParser(TokenStream input, ArchQualityDefGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "ArchQualityModel";
       	}

       	@Override
       	protected ArchQualityDefGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleArchQualityModel"
    // InternalArchQualityDef.g:64:1: entryRuleArchQualityModel returns [EObject current=null] : iv_ruleArchQualityModel= ruleArchQualityModel EOF ;
    public final EObject entryRuleArchQualityModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleArchQualityModel = null;


        try {
            // InternalArchQualityDef.g:64:57: (iv_ruleArchQualityModel= ruleArchQualityModel EOF )
            // InternalArchQualityDef.g:65:2: iv_ruleArchQualityModel= ruleArchQualityModel EOF
            {
             newCompositeNode(grammarAccess.getArchQualityModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleArchQualityModel=ruleArchQualityModel();

            state._fsp--;

             current =iv_ruleArchQualityModel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArchQualityModel"


    // $ANTLR start "ruleArchQualityModel"
    // InternalArchQualityDef.g:71:1: ruleArchQualityModel returns [EObject current=null] : ( () otherlv_1= 'QualityModel' otherlv_2= '{' ( ( (lv_lastupdate_3_0= ruleEDate ) ) otherlv_4= ';' )? (otherlv_5= 'bibtex' otherlv_6= '{' ( (lv_research_7_0= ruleResearchContribution ) ) (otherlv_8= ',' ( (lv_research_9_0= ruleResearchContribution ) ) )* otherlv_10= '}' )? (otherlv_11= 'qualitydef' otherlv_12= '{' ( (lv_qualitydef_13_0= ruleQualityElement ) ) (otherlv_14= ',' ( (lv_qualitydef_15_0= ruleQualityElement ) ) )* otherlv_16= '}' )? otherlv_17= '}' ) ;
    public final EObject ruleArchQualityModel() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        AntlrDatatypeRuleToken lv_lastupdate_3_0 = null;

        EObject lv_research_7_0 = null;

        EObject lv_research_9_0 = null;

        EObject lv_qualitydef_13_0 = null;

        EObject lv_qualitydef_15_0 = null;



        	enterRule();

        try {
            // InternalArchQualityDef.g:77:2: ( ( () otherlv_1= 'QualityModel' otherlv_2= '{' ( ( (lv_lastupdate_3_0= ruleEDate ) ) otherlv_4= ';' )? (otherlv_5= 'bibtex' otherlv_6= '{' ( (lv_research_7_0= ruleResearchContribution ) ) (otherlv_8= ',' ( (lv_research_9_0= ruleResearchContribution ) ) )* otherlv_10= '}' )? (otherlv_11= 'qualitydef' otherlv_12= '{' ( (lv_qualitydef_13_0= ruleQualityElement ) ) (otherlv_14= ',' ( (lv_qualitydef_15_0= ruleQualityElement ) ) )* otherlv_16= '}' )? otherlv_17= '}' ) )
            // InternalArchQualityDef.g:78:2: ( () otherlv_1= 'QualityModel' otherlv_2= '{' ( ( (lv_lastupdate_3_0= ruleEDate ) ) otherlv_4= ';' )? (otherlv_5= 'bibtex' otherlv_6= '{' ( (lv_research_7_0= ruleResearchContribution ) ) (otherlv_8= ',' ( (lv_research_9_0= ruleResearchContribution ) ) )* otherlv_10= '}' )? (otherlv_11= 'qualitydef' otherlv_12= '{' ( (lv_qualitydef_13_0= ruleQualityElement ) ) (otherlv_14= ',' ( (lv_qualitydef_15_0= ruleQualityElement ) ) )* otherlv_16= '}' )? otherlv_17= '}' )
            {
            // InternalArchQualityDef.g:78:2: ( () otherlv_1= 'QualityModel' otherlv_2= '{' ( ( (lv_lastupdate_3_0= ruleEDate ) ) otherlv_4= ';' )? (otherlv_5= 'bibtex' otherlv_6= '{' ( (lv_research_7_0= ruleResearchContribution ) ) (otherlv_8= ',' ( (lv_research_9_0= ruleResearchContribution ) ) )* otherlv_10= '}' )? (otherlv_11= 'qualitydef' otherlv_12= '{' ( (lv_qualitydef_13_0= ruleQualityElement ) ) (otherlv_14= ',' ( (lv_qualitydef_15_0= ruleQualityElement ) ) )* otherlv_16= '}' )? otherlv_17= '}' )
            // InternalArchQualityDef.g:79:3: () otherlv_1= 'QualityModel' otherlv_2= '{' ( ( (lv_lastupdate_3_0= ruleEDate ) ) otherlv_4= ';' )? (otherlv_5= 'bibtex' otherlv_6= '{' ( (lv_research_7_0= ruleResearchContribution ) ) (otherlv_8= ',' ( (lv_research_9_0= ruleResearchContribution ) ) )* otherlv_10= '}' )? (otherlv_11= 'qualitydef' otherlv_12= '{' ( (lv_qualitydef_13_0= ruleQualityElement ) ) (otherlv_14= ',' ( (lv_qualitydef_15_0= ruleQualityElement ) ) )* otherlv_16= '}' )? otherlv_17= '}'
            {
            // InternalArchQualityDef.g:79:3: ()
            // InternalArchQualityDef.g:80:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getArchQualityModelAccess().getArchQualityModelAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,11,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getArchQualityModelAccess().getQualityModelKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_4); 

            			newLeafNode(otherlv_2, grammarAccess.getArchQualityModelAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalArchQualityDef.g:94:3: ( ( (lv_lastupdate_3_0= ruleEDate ) ) otherlv_4= ';' )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==18) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalArchQualityDef.g:95:4: ( (lv_lastupdate_3_0= ruleEDate ) ) otherlv_4= ';'
                    {
                    // InternalArchQualityDef.g:95:4: ( (lv_lastupdate_3_0= ruleEDate ) )
                    // InternalArchQualityDef.g:96:5: (lv_lastupdate_3_0= ruleEDate )
                    {
                    // InternalArchQualityDef.g:96:5: (lv_lastupdate_3_0= ruleEDate )
                    // InternalArchQualityDef.g:97:6: lv_lastupdate_3_0= ruleEDate
                    {

                    						newCompositeNode(grammarAccess.getArchQualityModelAccess().getLastupdateEDateParserRuleCall_3_0_0());
                    					
                    pushFollow(FOLLOW_5);
                    lv_lastupdate_3_0=ruleEDate();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getArchQualityModelRule());
                    						}
                    						set(
                    							current,
                    							"lastupdate",
                    							lv_lastupdate_3_0,
                    							"it.gssi.cs.archqualitydef.ArchQualityDef.EDate");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    otherlv_4=(Token)match(input,13,FOLLOW_6); 

                    				newLeafNode(otherlv_4, grammarAccess.getArchQualityModelAccess().getSemicolonKeyword_3_1());
                    			

                    }
                    break;

            }

            // InternalArchQualityDef.g:119:3: (otherlv_5= 'bibtex' otherlv_6= '{' ( (lv_research_7_0= ruleResearchContribution ) ) (otherlv_8= ',' ( (lv_research_9_0= ruleResearchContribution ) ) )* otherlv_10= '}' )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==14) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalArchQualityDef.g:120:4: otherlv_5= 'bibtex' otherlv_6= '{' ( (lv_research_7_0= ruleResearchContribution ) ) (otherlv_8= ',' ( (lv_research_9_0= ruleResearchContribution ) ) )* otherlv_10= '}'
                    {
                    otherlv_5=(Token)match(input,14,FOLLOW_3); 

                    				newLeafNode(otherlv_5, grammarAccess.getArchQualityModelAccess().getBibtexKeyword_4_0());
                    			
                    otherlv_6=(Token)match(input,12,FOLLOW_7); 

                    				newLeafNode(otherlv_6, grammarAccess.getArchQualityModelAccess().getLeftCurlyBracketKeyword_4_1());
                    			
                    // InternalArchQualityDef.g:128:4: ( (lv_research_7_0= ruleResearchContribution ) )
                    // InternalArchQualityDef.g:129:5: (lv_research_7_0= ruleResearchContribution )
                    {
                    // InternalArchQualityDef.g:129:5: (lv_research_7_0= ruleResearchContribution )
                    // InternalArchQualityDef.g:130:6: lv_research_7_0= ruleResearchContribution
                    {

                    						newCompositeNode(grammarAccess.getArchQualityModelAccess().getResearchResearchContributionParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_8);
                    lv_research_7_0=ruleResearchContribution();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getArchQualityModelRule());
                    						}
                    						add(
                    							current,
                    							"research",
                    							lv_research_7_0,
                    							"it.gssi.cs.archqualitydef.ArchQualityDef.ResearchContribution");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalArchQualityDef.g:147:4: (otherlv_8= ',' ( (lv_research_9_0= ruleResearchContribution ) ) )*
                    loop2:
                    do {
                        int alt2=2;
                        int LA2_0 = input.LA(1);

                        if ( (LA2_0==15) ) {
                            alt2=1;
                        }


                        switch (alt2) {
                    	case 1 :
                    	    // InternalArchQualityDef.g:148:5: otherlv_8= ',' ( (lv_research_9_0= ruleResearchContribution ) )
                    	    {
                    	    otherlv_8=(Token)match(input,15,FOLLOW_7); 

                    	    					newLeafNode(otherlv_8, grammarAccess.getArchQualityModelAccess().getCommaKeyword_4_3_0());
                    	    				
                    	    // InternalArchQualityDef.g:152:5: ( (lv_research_9_0= ruleResearchContribution ) )
                    	    // InternalArchQualityDef.g:153:6: (lv_research_9_0= ruleResearchContribution )
                    	    {
                    	    // InternalArchQualityDef.g:153:6: (lv_research_9_0= ruleResearchContribution )
                    	    // InternalArchQualityDef.g:154:7: lv_research_9_0= ruleResearchContribution
                    	    {

                    	    							newCompositeNode(grammarAccess.getArchQualityModelAccess().getResearchResearchContributionParserRuleCall_4_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_8);
                    	    lv_research_9_0=ruleResearchContribution();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getArchQualityModelRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"research",
                    	    								lv_research_9_0,
                    	    								"it.gssi.cs.archqualitydef.ArchQualityDef.ResearchContribution");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop2;
                        }
                    } while (true);

                    otherlv_10=(Token)match(input,16,FOLLOW_9); 

                    				newLeafNode(otherlv_10, grammarAccess.getArchQualityModelAccess().getRightCurlyBracketKeyword_4_4());
                    			

                    }
                    break;

            }

            // InternalArchQualityDef.g:177:3: (otherlv_11= 'qualitydef' otherlv_12= '{' ( (lv_qualitydef_13_0= ruleQualityElement ) ) (otherlv_14= ',' ( (lv_qualitydef_15_0= ruleQualityElement ) ) )* otherlv_16= '}' )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==17) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalArchQualityDef.g:178:4: otherlv_11= 'qualitydef' otherlv_12= '{' ( (lv_qualitydef_13_0= ruleQualityElement ) ) (otherlv_14= ',' ( (lv_qualitydef_15_0= ruleQualityElement ) ) )* otherlv_16= '}'
                    {
                    otherlv_11=(Token)match(input,17,FOLLOW_3); 

                    				newLeafNode(otherlv_11, grammarAccess.getArchQualityModelAccess().getQualitydefKeyword_5_0());
                    			
                    otherlv_12=(Token)match(input,12,FOLLOW_10); 

                    				newLeafNode(otherlv_12, grammarAccess.getArchQualityModelAccess().getLeftCurlyBracketKeyword_5_1());
                    			
                    // InternalArchQualityDef.g:186:4: ( (lv_qualitydef_13_0= ruleQualityElement ) )
                    // InternalArchQualityDef.g:187:5: (lv_qualitydef_13_0= ruleQualityElement )
                    {
                    // InternalArchQualityDef.g:187:5: (lv_qualitydef_13_0= ruleQualityElement )
                    // InternalArchQualityDef.g:188:6: lv_qualitydef_13_0= ruleQualityElement
                    {

                    						newCompositeNode(grammarAccess.getArchQualityModelAccess().getQualitydefQualityElementParserRuleCall_5_2_0());
                    					
                    pushFollow(FOLLOW_8);
                    lv_qualitydef_13_0=ruleQualityElement();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getArchQualityModelRule());
                    						}
                    						add(
                    							current,
                    							"qualitydef",
                    							lv_qualitydef_13_0,
                    							"it.gssi.cs.archqualitydef.ArchQualityDef.QualityElement");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalArchQualityDef.g:205:4: (otherlv_14= ',' ( (lv_qualitydef_15_0= ruleQualityElement ) ) )*
                    loop4:
                    do {
                        int alt4=2;
                        int LA4_0 = input.LA(1);

                        if ( (LA4_0==15) ) {
                            alt4=1;
                        }


                        switch (alt4) {
                    	case 1 :
                    	    // InternalArchQualityDef.g:206:5: otherlv_14= ',' ( (lv_qualitydef_15_0= ruleQualityElement ) )
                    	    {
                    	    otherlv_14=(Token)match(input,15,FOLLOW_10); 

                    	    					newLeafNode(otherlv_14, grammarAccess.getArchQualityModelAccess().getCommaKeyword_5_3_0());
                    	    				
                    	    // InternalArchQualityDef.g:210:5: ( (lv_qualitydef_15_0= ruleQualityElement ) )
                    	    // InternalArchQualityDef.g:211:6: (lv_qualitydef_15_0= ruleQualityElement )
                    	    {
                    	    // InternalArchQualityDef.g:211:6: (lv_qualitydef_15_0= ruleQualityElement )
                    	    // InternalArchQualityDef.g:212:7: lv_qualitydef_15_0= ruleQualityElement
                    	    {

                    	    							newCompositeNode(grammarAccess.getArchQualityModelAccess().getQualitydefQualityElementParserRuleCall_5_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_8);
                    	    lv_qualitydef_15_0=ruleQualityElement();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getArchQualityModelRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"qualitydef",
                    	    								lv_qualitydef_15_0,
                    	    								"it.gssi.cs.archqualitydef.ArchQualityDef.QualityElement");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop4;
                        }
                    } while (true);

                    otherlv_16=(Token)match(input,16,FOLLOW_11); 

                    				newLeafNode(otherlv_16, grammarAccess.getArchQualityModelAccess().getRightCurlyBracketKeyword_5_4());
                    			

                    }
                    break;

            }

            otherlv_17=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_17, grammarAccess.getArchQualityModelAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArchQualityModel"


    // $ANTLR start "entryRuleQualityElement"
    // InternalArchQualityDef.g:243:1: entryRuleQualityElement returns [EObject current=null] : iv_ruleQualityElement= ruleQualityElement EOF ;
    public final EObject entryRuleQualityElement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleQualityElement = null;


        try {
            // InternalArchQualityDef.g:243:55: (iv_ruleQualityElement= ruleQualityElement EOF )
            // InternalArchQualityDef.g:244:2: iv_ruleQualityElement= ruleQualityElement EOF
            {
             newCompositeNode(grammarAccess.getQualityElementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleQualityElement=ruleQualityElement();

            state._fsp--;

             current =iv_ruleQualityElement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleQualityElement"


    // $ANTLR start "ruleQualityElement"
    // InternalArchQualityDef.g:250:1: ruleQualityElement returns [EObject current=null] : (this_Metric_0= ruleMetric | this_QualityAttribute_1= ruleQualityAttribute | this_QualityCharacteristic_2= ruleQualityCharacteristic | this_ResearchContribution_3= ruleResearchContribution | this_QualityRel_4= ruleQualityRel ) ;
    public final EObject ruleQualityElement() throws RecognitionException {
        EObject current = null;

        EObject this_Metric_0 = null;

        EObject this_QualityAttribute_1 = null;

        EObject this_QualityCharacteristic_2 = null;

        EObject this_ResearchContribution_3 = null;

        EObject this_QualityRel_4 = null;



        	enterRule();

        try {
            // InternalArchQualityDef.g:256:2: ( (this_Metric_0= ruleMetric | this_QualityAttribute_1= ruleQualityAttribute | this_QualityCharacteristic_2= ruleQualityCharacteristic | this_ResearchContribution_3= ruleResearchContribution | this_QualityRel_4= ruleQualityRel ) )
            // InternalArchQualityDef.g:257:2: (this_Metric_0= ruleMetric | this_QualityAttribute_1= ruleQualityAttribute | this_QualityCharacteristic_2= ruleQualityCharacteristic | this_ResearchContribution_3= ruleResearchContribution | this_QualityRel_4= ruleQualityRel )
            {
            // InternalArchQualityDef.g:257:2: (this_Metric_0= ruleMetric | this_QualityAttribute_1= ruleQualityAttribute | this_QualityCharacteristic_2= ruleQualityCharacteristic | this_ResearchContribution_3= ruleResearchContribution | this_QualityRel_4= ruleQualityRel )
            int alt6=5;
            switch ( input.LA(1) ) {
            case 43:
                {
                alt6=1;
                }
                break;
            case 47:
                {
                alt6=2;
                }
                break;
            case 48:
                {
                alt6=3;
                }
                break;
            case 35:
                {
                alt6=4;
                }
                break;
            case RULE_ID:
                {
                alt6=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }

            switch (alt6) {
                case 1 :
                    // InternalArchQualityDef.g:258:3: this_Metric_0= ruleMetric
                    {

                    			newCompositeNode(grammarAccess.getQualityElementAccess().getMetricParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Metric_0=ruleMetric();

                    state._fsp--;


                    			current = this_Metric_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalArchQualityDef.g:267:3: this_QualityAttribute_1= ruleQualityAttribute
                    {

                    			newCompositeNode(grammarAccess.getQualityElementAccess().getQualityAttributeParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_QualityAttribute_1=ruleQualityAttribute();

                    state._fsp--;


                    			current = this_QualityAttribute_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalArchQualityDef.g:276:3: this_QualityCharacteristic_2= ruleQualityCharacteristic
                    {

                    			newCompositeNode(grammarAccess.getQualityElementAccess().getQualityCharacteristicParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_QualityCharacteristic_2=ruleQualityCharacteristic();

                    state._fsp--;


                    			current = this_QualityCharacteristic_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalArchQualityDef.g:285:3: this_ResearchContribution_3= ruleResearchContribution
                    {

                    			newCompositeNode(grammarAccess.getQualityElementAccess().getResearchContributionParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_ResearchContribution_3=ruleResearchContribution();

                    state._fsp--;


                    			current = this_ResearchContribution_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalArchQualityDef.g:294:3: this_QualityRel_4= ruleQualityRel
                    {

                    			newCompositeNode(grammarAccess.getQualityElementAccess().getQualityRelParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_QualityRel_4=ruleQualityRel();

                    state._fsp--;


                    			current = this_QualityRel_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleQualityElement"


    // $ANTLR start "entryRuleEDate"
    // InternalArchQualityDef.g:306:1: entryRuleEDate returns [String current=null] : iv_ruleEDate= ruleEDate EOF ;
    public final String entryRuleEDate() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEDate = null;


        try {
            // InternalArchQualityDef.g:306:45: (iv_ruleEDate= ruleEDate EOF )
            // InternalArchQualityDef.g:307:2: iv_ruleEDate= ruleEDate EOF
            {
             newCompositeNode(grammarAccess.getEDateRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEDate=ruleEDate();

            state._fsp--;

             current =iv_ruleEDate.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEDate"


    // $ANTLR start "ruleEDate"
    // InternalArchQualityDef.g:313:1: ruleEDate returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'lastupdate' this_STRING_1= RULE_STRING ) ;
    public final AntlrDatatypeRuleToken ruleEDate() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_STRING_1=null;


        	enterRule();

        try {
            // InternalArchQualityDef.g:319:2: ( (kw= 'lastupdate' this_STRING_1= RULE_STRING ) )
            // InternalArchQualityDef.g:320:2: (kw= 'lastupdate' this_STRING_1= RULE_STRING )
            {
            // InternalArchQualityDef.g:320:2: (kw= 'lastupdate' this_STRING_1= RULE_STRING )
            // InternalArchQualityDef.g:321:3: kw= 'lastupdate' this_STRING_1= RULE_STRING
            {
            kw=(Token)match(input,18,FOLLOW_12); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getEDateAccess().getLastupdateKeyword_0());
            		
            this_STRING_1=(Token)match(input,RULE_STRING,FOLLOW_2); 

            			current.merge(this_STRING_1);
            		

            			newLeafNode(this_STRING_1, grammarAccess.getEDateAccess().getSTRINGTerminalRuleCall_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEDate"


    // $ANTLR start "entryRuleAuthor"
    // InternalArchQualityDef.g:337:1: entryRuleAuthor returns [EObject current=null] : iv_ruleAuthor= ruleAuthor EOF ;
    public final EObject entryRuleAuthor() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAuthor = null;


        try {
            // InternalArchQualityDef.g:337:47: (iv_ruleAuthor= ruleAuthor EOF )
            // InternalArchQualityDef.g:338:2: iv_ruleAuthor= ruleAuthor EOF
            {
             newCompositeNode(grammarAccess.getAuthorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAuthor=ruleAuthor();

            state._fsp--;

             current =iv_ruleAuthor; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAuthor"


    // $ANTLR start "ruleAuthor"
    // InternalArchQualityDef.g:344:1: ruleAuthor returns [EObject current=null] : ( ( (lv_name_0_1= RULE_ID | lv_name_0_2= RULE_STRING ) ) ) ;
    public final EObject ruleAuthor() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_1=null;
        Token lv_name_0_2=null;


        	enterRule();

        try {
            // InternalArchQualityDef.g:350:2: ( ( ( (lv_name_0_1= RULE_ID | lv_name_0_2= RULE_STRING ) ) ) )
            // InternalArchQualityDef.g:351:2: ( ( (lv_name_0_1= RULE_ID | lv_name_0_2= RULE_STRING ) ) )
            {
            // InternalArchQualityDef.g:351:2: ( ( (lv_name_0_1= RULE_ID | lv_name_0_2= RULE_STRING ) ) )
            // InternalArchQualityDef.g:352:3: ( (lv_name_0_1= RULE_ID | lv_name_0_2= RULE_STRING ) )
            {
            // InternalArchQualityDef.g:352:3: ( (lv_name_0_1= RULE_ID | lv_name_0_2= RULE_STRING ) )
            // InternalArchQualityDef.g:353:4: (lv_name_0_1= RULE_ID | lv_name_0_2= RULE_STRING )
            {
            // InternalArchQualityDef.g:353:4: (lv_name_0_1= RULE_ID | lv_name_0_2= RULE_STRING )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==RULE_ID) ) {
                alt7=1;
            }
            else if ( (LA7_0==RULE_STRING) ) {
                alt7=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // InternalArchQualityDef.g:354:5: lv_name_0_1= RULE_ID
                    {
                    lv_name_0_1=(Token)match(input,RULE_ID,FOLLOW_2); 

                    					newLeafNode(lv_name_0_1, grammarAccess.getAuthorAccess().getNameIDTerminalRuleCall_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getAuthorRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"name",
                    						lv_name_0_1,
                    						"org.eclipse.xtext.common.Terminals.ID");
                    				

                    }
                    break;
                case 2 :
                    // InternalArchQualityDef.g:369:5: lv_name_0_2= RULE_STRING
                    {
                    lv_name_0_2=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    					newLeafNode(lv_name_0_2, grammarAccess.getAuthorAccess().getNameSTRINGTerminalRuleCall_0_1());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getAuthorRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"name",
                    						lv_name_0_2,
                    						"org.eclipse.xtext.common.Terminals.STRING");
                    				

                    }
                    break;

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAuthor"


    // $ANTLR start "entryRuleField"
    // InternalArchQualityDef.g:389:1: entryRuleField returns [EObject current=null] : iv_ruleField= ruleField EOF ;
    public final EObject entryRuleField() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleField = null;


        try {
            // InternalArchQualityDef.g:389:46: (iv_ruleField= ruleField EOF )
            // InternalArchQualityDef.g:390:2: iv_ruleField= ruleField EOF
            {
             newCompositeNode(grammarAccess.getFieldRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleField=ruleField();

            state._fsp--;

             current =iv_ruleField; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleField"


    // $ANTLR start "ruleField"
    // InternalArchQualityDef.g:396:1: ruleField returns [EObject current=null] : ( () ( (otherlv_1= 'author=' otherlv_2= '{' ( (lv_authors_3_0= ruleAuthor ) ) (otherlv_4= 'and' ( (lv_authors_5_0= ruleAuthor ) ) )? otherlv_6= '}' ) | (otherlv_7= 'title=' otherlv_8= '{' ( (lv_title_9_0= RULE_STRING ) ) otherlv_10= '}' ) | (otherlv_11= 'year=' otherlv_12= '{' ( (lv_year_13_0= RULE_STRING ) ) otherlv_14= '}' ) | (otherlv_15= 'pages=' otherlv_16= '{' ( (lv_pages_17_0= RULE_STRING ) ) otherlv_18= '}' )? | (otherlv_19= 'address=' otherlv_20= '{' ( (lv_address_21_0= RULE_STRING ) ) otherlv_22= '}' )? | (otherlv_23= 'booktitle=' otherlv_24= '{' ( (lv_booktitle_25_0= RULE_STRING ) ) otherlv_26= '}' )? | (otherlv_27= 'journal=' otherlv_28= '{' ( (lv_journal_29_0= RULE_STRING ) ) otherlv_30= '}' )? | (otherlv_31= 'chapter=' otherlv_32= '{' ( (lv_chapter_33_0= RULE_STRING ) ) otherlv_34= '}' )? | (otherlv_35= 'series=' otherlv_36= '{' ( (lv_series_37_0= RULE_STRING ) ) otherlv_38= '}' )? | (otherlv_39= 'volume=' otherlv_40= '{' ( (lv_volume_41_0= RULE_STRING ) ) otherlv_42= '}' )? | (otherlv_43= 'editor=' otherlv_44= '{' ( (lv_editor_45_0= RULE_STRING ) ) otherlv_46= '}' )? | (otherlv_47= 'organization=' otherlv_48= '{' ( (lv_organization_49_0= RULE_STRING ) ) otherlv_50= '}' )? | (otherlv_51= 'note=' otherlv_52= '{' otherlv_53= 'Cited' otherlv_54= 'by:' ( (lv_citationscount_55_0= RULE_INT ) ) otherlv_56= '}' )? ) ) ;
    public final EObject ruleField() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token lv_title_9_0=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token lv_year_13_0=null;
        Token otherlv_14=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Token lv_pages_17_0=null;
        Token otherlv_18=null;
        Token otherlv_19=null;
        Token otherlv_20=null;
        Token lv_address_21_0=null;
        Token otherlv_22=null;
        Token otherlv_23=null;
        Token otherlv_24=null;
        Token lv_booktitle_25_0=null;
        Token otherlv_26=null;
        Token otherlv_27=null;
        Token otherlv_28=null;
        Token lv_journal_29_0=null;
        Token otherlv_30=null;
        Token otherlv_31=null;
        Token otherlv_32=null;
        Token lv_chapter_33_0=null;
        Token otherlv_34=null;
        Token otherlv_35=null;
        Token otherlv_36=null;
        Token lv_series_37_0=null;
        Token otherlv_38=null;
        Token otherlv_39=null;
        Token otherlv_40=null;
        Token lv_volume_41_0=null;
        Token otherlv_42=null;
        Token otherlv_43=null;
        Token otherlv_44=null;
        Token lv_editor_45_0=null;
        Token otherlv_46=null;
        Token otherlv_47=null;
        Token otherlv_48=null;
        Token lv_organization_49_0=null;
        Token otherlv_50=null;
        Token otherlv_51=null;
        Token otherlv_52=null;
        Token otherlv_53=null;
        Token otherlv_54=null;
        Token lv_citationscount_55_0=null;
        Token otherlv_56=null;
        EObject lv_authors_3_0 = null;

        EObject lv_authors_5_0 = null;



        	enterRule();

        try {
            // InternalArchQualityDef.g:402:2: ( ( () ( (otherlv_1= 'author=' otherlv_2= '{' ( (lv_authors_3_0= ruleAuthor ) ) (otherlv_4= 'and' ( (lv_authors_5_0= ruleAuthor ) ) )? otherlv_6= '}' ) | (otherlv_7= 'title=' otherlv_8= '{' ( (lv_title_9_0= RULE_STRING ) ) otherlv_10= '}' ) | (otherlv_11= 'year=' otherlv_12= '{' ( (lv_year_13_0= RULE_STRING ) ) otherlv_14= '}' ) | (otherlv_15= 'pages=' otherlv_16= '{' ( (lv_pages_17_0= RULE_STRING ) ) otherlv_18= '}' )? | (otherlv_19= 'address=' otherlv_20= '{' ( (lv_address_21_0= RULE_STRING ) ) otherlv_22= '}' )? | (otherlv_23= 'booktitle=' otherlv_24= '{' ( (lv_booktitle_25_0= RULE_STRING ) ) otherlv_26= '}' )? | (otherlv_27= 'journal=' otherlv_28= '{' ( (lv_journal_29_0= RULE_STRING ) ) otherlv_30= '}' )? | (otherlv_31= 'chapter=' otherlv_32= '{' ( (lv_chapter_33_0= RULE_STRING ) ) otherlv_34= '}' )? | (otherlv_35= 'series=' otherlv_36= '{' ( (lv_series_37_0= RULE_STRING ) ) otherlv_38= '}' )? | (otherlv_39= 'volume=' otherlv_40= '{' ( (lv_volume_41_0= RULE_STRING ) ) otherlv_42= '}' )? | (otherlv_43= 'editor=' otherlv_44= '{' ( (lv_editor_45_0= RULE_STRING ) ) otherlv_46= '}' )? | (otherlv_47= 'organization=' otherlv_48= '{' ( (lv_organization_49_0= RULE_STRING ) ) otherlv_50= '}' )? | (otherlv_51= 'note=' otherlv_52= '{' otherlv_53= 'Cited' otherlv_54= 'by:' ( (lv_citationscount_55_0= RULE_INT ) ) otherlv_56= '}' )? ) ) )
            // InternalArchQualityDef.g:403:2: ( () ( (otherlv_1= 'author=' otherlv_2= '{' ( (lv_authors_3_0= ruleAuthor ) ) (otherlv_4= 'and' ( (lv_authors_5_0= ruleAuthor ) ) )? otherlv_6= '}' ) | (otherlv_7= 'title=' otherlv_8= '{' ( (lv_title_9_0= RULE_STRING ) ) otherlv_10= '}' ) | (otherlv_11= 'year=' otherlv_12= '{' ( (lv_year_13_0= RULE_STRING ) ) otherlv_14= '}' ) | (otherlv_15= 'pages=' otherlv_16= '{' ( (lv_pages_17_0= RULE_STRING ) ) otherlv_18= '}' )? | (otherlv_19= 'address=' otherlv_20= '{' ( (lv_address_21_0= RULE_STRING ) ) otherlv_22= '}' )? | (otherlv_23= 'booktitle=' otherlv_24= '{' ( (lv_booktitle_25_0= RULE_STRING ) ) otherlv_26= '}' )? | (otherlv_27= 'journal=' otherlv_28= '{' ( (lv_journal_29_0= RULE_STRING ) ) otherlv_30= '}' )? | (otherlv_31= 'chapter=' otherlv_32= '{' ( (lv_chapter_33_0= RULE_STRING ) ) otherlv_34= '}' )? | (otherlv_35= 'series=' otherlv_36= '{' ( (lv_series_37_0= RULE_STRING ) ) otherlv_38= '}' )? | (otherlv_39= 'volume=' otherlv_40= '{' ( (lv_volume_41_0= RULE_STRING ) ) otherlv_42= '}' )? | (otherlv_43= 'editor=' otherlv_44= '{' ( (lv_editor_45_0= RULE_STRING ) ) otherlv_46= '}' )? | (otherlv_47= 'organization=' otherlv_48= '{' ( (lv_organization_49_0= RULE_STRING ) ) otherlv_50= '}' )? | (otherlv_51= 'note=' otherlv_52= '{' otherlv_53= 'Cited' otherlv_54= 'by:' ( (lv_citationscount_55_0= RULE_INT ) ) otherlv_56= '}' )? ) )
            {
            // InternalArchQualityDef.g:403:2: ( () ( (otherlv_1= 'author=' otherlv_2= '{' ( (lv_authors_3_0= ruleAuthor ) ) (otherlv_4= 'and' ( (lv_authors_5_0= ruleAuthor ) ) )? otherlv_6= '}' ) | (otherlv_7= 'title=' otherlv_8= '{' ( (lv_title_9_0= RULE_STRING ) ) otherlv_10= '}' ) | (otherlv_11= 'year=' otherlv_12= '{' ( (lv_year_13_0= RULE_STRING ) ) otherlv_14= '}' ) | (otherlv_15= 'pages=' otherlv_16= '{' ( (lv_pages_17_0= RULE_STRING ) ) otherlv_18= '}' )? | (otherlv_19= 'address=' otherlv_20= '{' ( (lv_address_21_0= RULE_STRING ) ) otherlv_22= '}' )? | (otherlv_23= 'booktitle=' otherlv_24= '{' ( (lv_booktitle_25_0= RULE_STRING ) ) otherlv_26= '}' )? | (otherlv_27= 'journal=' otherlv_28= '{' ( (lv_journal_29_0= RULE_STRING ) ) otherlv_30= '}' )? | (otherlv_31= 'chapter=' otherlv_32= '{' ( (lv_chapter_33_0= RULE_STRING ) ) otherlv_34= '}' )? | (otherlv_35= 'series=' otherlv_36= '{' ( (lv_series_37_0= RULE_STRING ) ) otherlv_38= '}' )? | (otherlv_39= 'volume=' otherlv_40= '{' ( (lv_volume_41_0= RULE_STRING ) ) otherlv_42= '}' )? | (otherlv_43= 'editor=' otherlv_44= '{' ( (lv_editor_45_0= RULE_STRING ) ) otherlv_46= '}' )? | (otherlv_47= 'organization=' otherlv_48= '{' ( (lv_organization_49_0= RULE_STRING ) ) otherlv_50= '}' )? | (otherlv_51= 'note=' otherlv_52= '{' otherlv_53= 'Cited' otherlv_54= 'by:' ( (lv_citationscount_55_0= RULE_INT ) ) otherlv_56= '}' )? ) )
            // InternalArchQualityDef.g:404:3: () ( (otherlv_1= 'author=' otherlv_2= '{' ( (lv_authors_3_0= ruleAuthor ) ) (otherlv_4= 'and' ( (lv_authors_5_0= ruleAuthor ) ) )? otherlv_6= '}' ) | (otherlv_7= 'title=' otherlv_8= '{' ( (lv_title_9_0= RULE_STRING ) ) otherlv_10= '}' ) | (otherlv_11= 'year=' otherlv_12= '{' ( (lv_year_13_0= RULE_STRING ) ) otherlv_14= '}' ) | (otherlv_15= 'pages=' otherlv_16= '{' ( (lv_pages_17_0= RULE_STRING ) ) otherlv_18= '}' )? | (otherlv_19= 'address=' otherlv_20= '{' ( (lv_address_21_0= RULE_STRING ) ) otherlv_22= '}' )? | (otherlv_23= 'booktitle=' otherlv_24= '{' ( (lv_booktitle_25_0= RULE_STRING ) ) otherlv_26= '}' )? | (otherlv_27= 'journal=' otherlv_28= '{' ( (lv_journal_29_0= RULE_STRING ) ) otherlv_30= '}' )? | (otherlv_31= 'chapter=' otherlv_32= '{' ( (lv_chapter_33_0= RULE_STRING ) ) otherlv_34= '}' )? | (otherlv_35= 'series=' otherlv_36= '{' ( (lv_series_37_0= RULE_STRING ) ) otherlv_38= '}' )? | (otherlv_39= 'volume=' otherlv_40= '{' ( (lv_volume_41_0= RULE_STRING ) ) otherlv_42= '}' )? | (otherlv_43= 'editor=' otherlv_44= '{' ( (lv_editor_45_0= RULE_STRING ) ) otherlv_46= '}' )? | (otherlv_47= 'organization=' otherlv_48= '{' ( (lv_organization_49_0= RULE_STRING ) ) otherlv_50= '}' )? | (otherlv_51= 'note=' otherlv_52= '{' otherlv_53= 'Cited' otherlv_54= 'by:' ( (lv_citationscount_55_0= RULE_INT ) ) otherlv_56= '}' )? )
            {
            // InternalArchQualityDef.g:404:3: ()
            // InternalArchQualityDef.g:405:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getFieldAccess().getFieldAction_0(),
            					current);
            			

            }

            // InternalArchQualityDef.g:411:3: ( (otherlv_1= 'author=' otherlv_2= '{' ( (lv_authors_3_0= ruleAuthor ) ) (otherlv_4= 'and' ( (lv_authors_5_0= ruleAuthor ) ) )? otherlv_6= '}' ) | (otherlv_7= 'title=' otherlv_8= '{' ( (lv_title_9_0= RULE_STRING ) ) otherlv_10= '}' ) | (otherlv_11= 'year=' otherlv_12= '{' ( (lv_year_13_0= RULE_STRING ) ) otherlv_14= '}' ) | (otherlv_15= 'pages=' otherlv_16= '{' ( (lv_pages_17_0= RULE_STRING ) ) otherlv_18= '}' )? | (otherlv_19= 'address=' otherlv_20= '{' ( (lv_address_21_0= RULE_STRING ) ) otherlv_22= '}' )? | (otherlv_23= 'booktitle=' otherlv_24= '{' ( (lv_booktitle_25_0= RULE_STRING ) ) otherlv_26= '}' )? | (otherlv_27= 'journal=' otherlv_28= '{' ( (lv_journal_29_0= RULE_STRING ) ) otherlv_30= '}' )? | (otherlv_31= 'chapter=' otherlv_32= '{' ( (lv_chapter_33_0= RULE_STRING ) ) otherlv_34= '}' )? | (otherlv_35= 'series=' otherlv_36= '{' ( (lv_series_37_0= RULE_STRING ) ) otherlv_38= '}' )? | (otherlv_39= 'volume=' otherlv_40= '{' ( (lv_volume_41_0= RULE_STRING ) ) otherlv_42= '}' )? | (otherlv_43= 'editor=' otherlv_44= '{' ( (lv_editor_45_0= RULE_STRING ) ) otherlv_46= '}' )? | (otherlv_47= 'organization=' otherlv_48= '{' ( (lv_organization_49_0= RULE_STRING ) ) otherlv_50= '}' )? | (otherlv_51= 'note=' otherlv_52= '{' otherlv_53= 'Cited' otherlv_54= 'by:' ( (lv_citationscount_55_0= RULE_INT ) ) otherlv_56= '}' )? )
            int alt19=13;
            alt19 = dfa19.predict(input);
            switch (alt19) {
                case 1 :
                    // InternalArchQualityDef.g:412:4: (otherlv_1= 'author=' otherlv_2= '{' ( (lv_authors_3_0= ruleAuthor ) ) (otherlv_4= 'and' ( (lv_authors_5_0= ruleAuthor ) ) )? otherlv_6= '}' )
                    {
                    // InternalArchQualityDef.g:412:4: (otherlv_1= 'author=' otherlv_2= '{' ( (lv_authors_3_0= ruleAuthor ) ) (otherlv_4= 'and' ( (lv_authors_5_0= ruleAuthor ) ) )? otherlv_6= '}' )
                    // InternalArchQualityDef.g:413:5: otherlv_1= 'author=' otherlv_2= '{' ( (lv_authors_3_0= ruleAuthor ) ) (otherlv_4= 'and' ( (lv_authors_5_0= ruleAuthor ) ) )? otherlv_6= '}'
                    {
                    otherlv_1=(Token)match(input,19,FOLLOW_3); 

                    					newLeafNode(otherlv_1, grammarAccess.getFieldAccess().getAuthorKeyword_1_0_0());
                    				
                    otherlv_2=(Token)match(input,12,FOLLOW_13); 

                    					newLeafNode(otherlv_2, grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_0_1());
                    				
                    // InternalArchQualityDef.g:421:5: ( (lv_authors_3_0= ruleAuthor ) )
                    // InternalArchQualityDef.g:422:6: (lv_authors_3_0= ruleAuthor )
                    {
                    // InternalArchQualityDef.g:422:6: (lv_authors_3_0= ruleAuthor )
                    // InternalArchQualityDef.g:423:7: lv_authors_3_0= ruleAuthor
                    {

                    							newCompositeNode(grammarAccess.getFieldAccess().getAuthorsAuthorParserRuleCall_1_0_2_0());
                    						
                    pushFollow(FOLLOW_14);
                    lv_authors_3_0=ruleAuthor();

                    state._fsp--;


                    							if (current==null) {
                    								current = createModelElementForParent(grammarAccess.getFieldRule());
                    							}
                    							add(
                    								current,
                    								"authors",
                    								lv_authors_3_0,
                    								"it.gssi.cs.archqualitydef.ArchQualityDef.Author");
                    							afterParserOrEnumRuleCall();
                    						

                    }


                    }

                    // InternalArchQualityDef.g:440:5: (otherlv_4= 'and' ( (lv_authors_5_0= ruleAuthor ) ) )?
                    int alt8=2;
                    int LA8_0 = input.LA(1);

                    if ( (LA8_0==20) ) {
                        alt8=1;
                    }
                    switch (alt8) {
                        case 1 :
                            // InternalArchQualityDef.g:441:6: otherlv_4= 'and' ( (lv_authors_5_0= ruleAuthor ) )
                            {
                            otherlv_4=(Token)match(input,20,FOLLOW_13); 

                            						newLeafNode(otherlv_4, grammarAccess.getFieldAccess().getAndKeyword_1_0_3_0());
                            					
                            // InternalArchQualityDef.g:445:6: ( (lv_authors_5_0= ruleAuthor ) )
                            // InternalArchQualityDef.g:446:7: (lv_authors_5_0= ruleAuthor )
                            {
                            // InternalArchQualityDef.g:446:7: (lv_authors_5_0= ruleAuthor )
                            // InternalArchQualityDef.g:447:8: lv_authors_5_0= ruleAuthor
                            {

                            								newCompositeNode(grammarAccess.getFieldAccess().getAuthorsAuthorParserRuleCall_1_0_3_1_0());
                            							
                            pushFollow(FOLLOW_11);
                            lv_authors_5_0=ruleAuthor();

                            state._fsp--;


                            								if (current==null) {
                            									current = createModelElementForParent(grammarAccess.getFieldRule());
                            								}
                            								add(
                            									current,
                            									"authors",
                            									lv_authors_5_0,
                            									"it.gssi.cs.archqualitydef.ArchQualityDef.Author");
                            								afterParserOrEnumRuleCall();
                            							

                            }


                            }


                            }
                            break;

                    }

                    otherlv_6=(Token)match(input,16,FOLLOW_2); 

                    					newLeafNode(otherlv_6, grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_0_4());
                    				

                    }


                    }
                    break;
                case 2 :
                    // InternalArchQualityDef.g:471:4: (otherlv_7= 'title=' otherlv_8= '{' ( (lv_title_9_0= RULE_STRING ) ) otherlv_10= '}' )
                    {
                    // InternalArchQualityDef.g:471:4: (otherlv_7= 'title=' otherlv_8= '{' ( (lv_title_9_0= RULE_STRING ) ) otherlv_10= '}' )
                    // InternalArchQualityDef.g:472:5: otherlv_7= 'title=' otherlv_8= '{' ( (lv_title_9_0= RULE_STRING ) ) otherlv_10= '}'
                    {
                    otherlv_7=(Token)match(input,21,FOLLOW_3); 

                    					newLeafNode(otherlv_7, grammarAccess.getFieldAccess().getTitleKeyword_1_1_0());
                    				
                    otherlv_8=(Token)match(input,12,FOLLOW_12); 

                    					newLeafNode(otherlv_8, grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_1_1());
                    				
                    // InternalArchQualityDef.g:480:5: ( (lv_title_9_0= RULE_STRING ) )
                    // InternalArchQualityDef.g:481:6: (lv_title_9_0= RULE_STRING )
                    {
                    // InternalArchQualityDef.g:481:6: (lv_title_9_0= RULE_STRING )
                    // InternalArchQualityDef.g:482:7: lv_title_9_0= RULE_STRING
                    {
                    lv_title_9_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

                    							newLeafNode(lv_title_9_0, grammarAccess.getFieldAccess().getTitleSTRINGTerminalRuleCall_1_1_2_0());
                    						

                    							if (current==null) {
                    								current = createModelElement(grammarAccess.getFieldRule());
                    							}
                    							setWithLastConsumed(
                    								current,
                    								"title",
                    								lv_title_9_0,
                    								"org.eclipse.xtext.common.Terminals.STRING");
                    						

                    }


                    }

                    otherlv_10=(Token)match(input,16,FOLLOW_2); 

                    					newLeafNode(otherlv_10, grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_1_3());
                    				

                    }


                    }
                    break;
                case 3 :
                    // InternalArchQualityDef.g:504:4: (otherlv_11= 'year=' otherlv_12= '{' ( (lv_year_13_0= RULE_STRING ) ) otherlv_14= '}' )
                    {
                    // InternalArchQualityDef.g:504:4: (otherlv_11= 'year=' otherlv_12= '{' ( (lv_year_13_0= RULE_STRING ) ) otherlv_14= '}' )
                    // InternalArchQualityDef.g:505:5: otherlv_11= 'year=' otherlv_12= '{' ( (lv_year_13_0= RULE_STRING ) ) otherlv_14= '}'
                    {
                    otherlv_11=(Token)match(input,22,FOLLOW_3); 

                    					newLeafNode(otherlv_11, grammarAccess.getFieldAccess().getYearKeyword_1_2_0());
                    				
                    otherlv_12=(Token)match(input,12,FOLLOW_12); 

                    					newLeafNode(otherlv_12, grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_2_1());
                    				
                    // InternalArchQualityDef.g:513:5: ( (lv_year_13_0= RULE_STRING ) )
                    // InternalArchQualityDef.g:514:6: (lv_year_13_0= RULE_STRING )
                    {
                    // InternalArchQualityDef.g:514:6: (lv_year_13_0= RULE_STRING )
                    // InternalArchQualityDef.g:515:7: lv_year_13_0= RULE_STRING
                    {
                    lv_year_13_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

                    							newLeafNode(lv_year_13_0, grammarAccess.getFieldAccess().getYearSTRINGTerminalRuleCall_1_2_2_0());
                    						

                    							if (current==null) {
                    								current = createModelElement(grammarAccess.getFieldRule());
                    							}
                    							setWithLastConsumed(
                    								current,
                    								"year",
                    								lv_year_13_0,
                    								"org.eclipse.xtext.common.Terminals.STRING");
                    						

                    }


                    }

                    otherlv_14=(Token)match(input,16,FOLLOW_2); 

                    					newLeafNode(otherlv_14, grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_2_3());
                    				

                    }


                    }
                    break;
                case 4 :
                    // InternalArchQualityDef.g:537:4: (otherlv_15= 'pages=' otherlv_16= '{' ( (lv_pages_17_0= RULE_STRING ) ) otherlv_18= '}' )?
                    {
                    // InternalArchQualityDef.g:537:4: (otherlv_15= 'pages=' otherlv_16= '{' ( (lv_pages_17_0= RULE_STRING ) ) otherlv_18= '}' )?
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0==23) ) {
                        alt9=1;
                    }
                    switch (alt9) {
                        case 1 :
                            // InternalArchQualityDef.g:538:5: otherlv_15= 'pages=' otherlv_16= '{' ( (lv_pages_17_0= RULE_STRING ) ) otherlv_18= '}'
                            {
                            otherlv_15=(Token)match(input,23,FOLLOW_3); 

                            					newLeafNode(otherlv_15, grammarAccess.getFieldAccess().getPagesKeyword_1_3_0());
                            				
                            otherlv_16=(Token)match(input,12,FOLLOW_12); 

                            					newLeafNode(otherlv_16, grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_3_1());
                            				
                            // InternalArchQualityDef.g:546:5: ( (lv_pages_17_0= RULE_STRING ) )
                            // InternalArchQualityDef.g:547:6: (lv_pages_17_0= RULE_STRING )
                            {
                            // InternalArchQualityDef.g:547:6: (lv_pages_17_0= RULE_STRING )
                            // InternalArchQualityDef.g:548:7: lv_pages_17_0= RULE_STRING
                            {
                            lv_pages_17_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

                            							newLeafNode(lv_pages_17_0, grammarAccess.getFieldAccess().getPagesSTRINGTerminalRuleCall_1_3_2_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getFieldRule());
                            							}
                            							setWithLastConsumed(
                            								current,
                            								"pages",
                            								lv_pages_17_0,
                            								"org.eclipse.xtext.common.Terminals.STRING");
                            						

                            }


                            }

                            otherlv_18=(Token)match(input,16,FOLLOW_2); 

                            					newLeafNode(otherlv_18, grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_3_3());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 5 :
                    // InternalArchQualityDef.g:570:4: (otherlv_19= 'address=' otherlv_20= '{' ( (lv_address_21_0= RULE_STRING ) ) otherlv_22= '}' )?
                    {
                    // InternalArchQualityDef.g:570:4: (otherlv_19= 'address=' otherlv_20= '{' ( (lv_address_21_0= RULE_STRING ) ) otherlv_22= '}' )?
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0==24) ) {
                        alt10=1;
                    }
                    switch (alt10) {
                        case 1 :
                            // InternalArchQualityDef.g:571:5: otherlv_19= 'address=' otherlv_20= '{' ( (lv_address_21_0= RULE_STRING ) ) otherlv_22= '}'
                            {
                            otherlv_19=(Token)match(input,24,FOLLOW_3); 

                            					newLeafNode(otherlv_19, grammarAccess.getFieldAccess().getAddressKeyword_1_4_0());
                            				
                            otherlv_20=(Token)match(input,12,FOLLOW_12); 

                            					newLeafNode(otherlv_20, grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_4_1());
                            				
                            // InternalArchQualityDef.g:579:5: ( (lv_address_21_0= RULE_STRING ) )
                            // InternalArchQualityDef.g:580:6: (lv_address_21_0= RULE_STRING )
                            {
                            // InternalArchQualityDef.g:580:6: (lv_address_21_0= RULE_STRING )
                            // InternalArchQualityDef.g:581:7: lv_address_21_0= RULE_STRING
                            {
                            lv_address_21_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

                            							newLeafNode(lv_address_21_0, grammarAccess.getFieldAccess().getAddressSTRINGTerminalRuleCall_1_4_2_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getFieldRule());
                            							}
                            							setWithLastConsumed(
                            								current,
                            								"address",
                            								lv_address_21_0,
                            								"org.eclipse.xtext.common.Terminals.STRING");
                            						

                            }


                            }

                            otherlv_22=(Token)match(input,16,FOLLOW_2); 

                            					newLeafNode(otherlv_22, grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_4_3());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 6 :
                    // InternalArchQualityDef.g:603:4: (otherlv_23= 'booktitle=' otherlv_24= '{' ( (lv_booktitle_25_0= RULE_STRING ) ) otherlv_26= '}' )?
                    {
                    // InternalArchQualityDef.g:603:4: (otherlv_23= 'booktitle=' otherlv_24= '{' ( (lv_booktitle_25_0= RULE_STRING ) ) otherlv_26= '}' )?
                    int alt11=2;
                    int LA11_0 = input.LA(1);

                    if ( (LA11_0==25) ) {
                        alt11=1;
                    }
                    switch (alt11) {
                        case 1 :
                            // InternalArchQualityDef.g:604:5: otherlv_23= 'booktitle=' otherlv_24= '{' ( (lv_booktitle_25_0= RULE_STRING ) ) otherlv_26= '}'
                            {
                            otherlv_23=(Token)match(input,25,FOLLOW_3); 

                            					newLeafNode(otherlv_23, grammarAccess.getFieldAccess().getBooktitleKeyword_1_5_0());
                            				
                            otherlv_24=(Token)match(input,12,FOLLOW_12); 

                            					newLeafNode(otherlv_24, grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_5_1());
                            				
                            // InternalArchQualityDef.g:612:5: ( (lv_booktitle_25_0= RULE_STRING ) )
                            // InternalArchQualityDef.g:613:6: (lv_booktitle_25_0= RULE_STRING )
                            {
                            // InternalArchQualityDef.g:613:6: (lv_booktitle_25_0= RULE_STRING )
                            // InternalArchQualityDef.g:614:7: lv_booktitle_25_0= RULE_STRING
                            {
                            lv_booktitle_25_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

                            							newLeafNode(lv_booktitle_25_0, grammarAccess.getFieldAccess().getBooktitleSTRINGTerminalRuleCall_1_5_2_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getFieldRule());
                            							}
                            							setWithLastConsumed(
                            								current,
                            								"booktitle",
                            								lv_booktitle_25_0,
                            								"org.eclipse.xtext.common.Terminals.STRING");
                            						

                            }


                            }

                            otherlv_26=(Token)match(input,16,FOLLOW_2); 

                            					newLeafNode(otherlv_26, grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_5_3());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 7 :
                    // InternalArchQualityDef.g:636:4: (otherlv_27= 'journal=' otherlv_28= '{' ( (lv_journal_29_0= RULE_STRING ) ) otherlv_30= '}' )?
                    {
                    // InternalArchQualityDef.g:636:4: (otherlv_27= 'journal=' otherlv_28= '{' ( (lv_journal_29_0= RULE_STRING ) ) otherlv_30= '}' )?
                    int alt12=2;
                    int LA12_0 = input.LA(1);

                    if ( (LA12_0==26) ) {
                        alt12=1;
                    }
                    switch (alt12) {
                        case 1 :
                            // InternalArchQualityDef.g:637:5: otherlv_27= 'journal=' otherlv_28= '{' ( (lv_journal_29_0= RULE_STRING ) ) otherlv_30= '}'
                            {
                            otherlv_27=(Token)match(input,26,FOLLOW_3); 

                            					newLeafNode(otherlv_27, grammarAccess.getFieldAccess().getJournalKeyword_1_6_0());
                            				
                            otherlv_28=(Token)match(input,12,FOLLOW_12); 

                            					newLeafNode(otherlv_28, grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_6_1());
                            				
                            // InternalArchQualityDef.g:645:5: ( (lv_journal_29_0= RULE_STRING ) )
                            // InternalArchQualityDef.g:646:6: (lv_journal_29_0= RULE_STRING )
                            {
                            // InternalArchQualityDef.g:646:6: (lv_journal_29_0= RULE_STRING )
                            // InternalArchQualityDef.g:647:7: lv_journal_29_0= RULE_STRING
                            {
                            lv_journal_29_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

                            							newLeafNode(lv_journal_29_0, grammarAccess.getFieldAccess().getJournalSTRINGTerminalRuleCall_1_6_2_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getFieldRule());
                            							}
                            							setWithLastConsumed(
                            								current,
                            								"journal",
                            								lv_journal_29_0,
                            								"org.eclipse.xtext.common.Terminals.STRING");
                            						

                            }


                            }

                            otherlv_30=(Token)match(input,16,FOLLOW_2); 

                            					newLeafNode(otherlv_30, grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_6_3());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 8 :
                    // InternalArchQualityDef.g:669:4: (otherlv_31= 'chapter=' otherlv_32= '{' ( (lv_chapter_33_0= RULE_STRING ) ) otherlv_34= '}' )?
                    {
                    // InternalArchQualityDef.g:669:4: (otherlv_31= 'chapter=' otherlv_32= '{' ( (lv_chapter_33_0= RULE_STRING ) ) otherlv_34= '}' )?
                    int alt13=2;
                    int LA13_0 = input.LA(1);

                    if ( (LA13_0==27) ) {
                        alt13=1;
                    }
                    switch (alt13) {
                        case 1 :
                            // InternalArchQualityDef.g:670:5: otherlv_31= 'chapter=' otherlv_32= '{' ( (lv_chapter_33_0= RULE_STRING ) ) otherlv_34= '}'
                            {
                            otherlv_31=(Token)match(input,27,FOLLOW_3); 

                            					newLeafNode(otherlv_31, grammarAccess.getFieldAccess().getChapterKeyword_1_7_0());
                            				
                            otherlv_32=(Token)match(input,12,FOLLOW_12); 

                            					newLeafNode(otherlv_32, grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_7_1());
                            				
                            // InternalArchQualityDef.g:678:5: ( (lv_chapter_33_0= RULE_STRING ) )
                            // InternalArchQualityDef.g:679:6: (lv_chapter_33_0= RULE_STRING )
                            {
                            // InternalArchQualityDef.g:679:6: (lv_chapter_33_0= RULE_STRING )
                            // InternalArchQualityDef.g:680:7: lv_chapter_33_0= RULE_STRING
                            {
                            lv_chapter_33_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

                            							newLeafNode(lv_chapter_33_0, grammarAccess.getFieldAccess().getChapterSTRINGTerminalRuleCall_1_7_2_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getFieldRule());
                            							}
                            							setWithLastConsumed(
                            								current,
                            								"chapter",
                            								lv_chapter_33_0,
                            								"org.eclipse.xtext.common.Terminals.STRING");
                            						

                            }


                            }

                            otherlv_34=(Token)match(input,16,FOLLOW_2); 

                            					newLeafNode(otherlv_34, grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_7_3());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 9 :
                    // InternalArchQualityDef.g:702:4: (otherlv_35= 'series=' otherlv_36= '{' ( (lv_series_37_0= RULE_STRING ) ) otherlv_38= '}' )?
                    {
                    // InternalArchQualityDef.g:702:4: (otherlv_35= 'series=' otherlv_36= '{' ( (lv_series_37_0= RULE_STRING ) ) otherlv_38= '}' )?
                    int alt14=2;
                    int LA14_0 = input.LA(1);

                    if ( (LA14_0==28) ) {
                        alt14=1;
                    }
                    switch (alt14) {
                        case 1 :
                            // InternalArchQualityDef.g:703:5: otherlv_35= 'series=' otherlv_36= '{' ( (lv_series_37_0= RULE_STRING ) ) otherlv_38= '}'
                            {
                            otherlv_35=(Token)match(input,28,FOLLOW_3); 

                            					newLeafNode(otherlv_35, grammarAccess.getFieldAccess().getSeriesKeyword_1_8_0());
                            				
                            otherlv_36=(Token)match(input,12,FOLLOW_12); 

                            					newLeafNode(otherlv_36, grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_8_1());
                            				
                            // InternalArchQualityDef.g:711:5: ( (lv_series_37_0= RULE_STRING ) )
                            // InternalArchQualityDef.g:712:6: (lv_series_37_0= RULE_STRING )
                            {
                            // InternalArchQualityDef.g:712:6: (lv_series_37_0= RULE_STRING )
                            // InternalArchQualityDef.g:713:7: lv_series_37_0= RULE_STRING
                            {
                            lv_series_37_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

                            							newLeafNode(lv_series_37_0, grammarAccess.getFieldAccess().getSeriesSTRINGTerminalRuleCall_1_8_2_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getFieldRule());
                            							}
                            							setWithLastConsumed(
                            								current,
                            								"series",
                            								lv_series_37_0,
                            								"org.eclipse.xtext.common.Terminals.STRING");
                            						

                            }


                            }

                            otherlv_38=(Token)match(input,16,FOLLOW_2); 

                            					newLeafNode(otherlv_38, grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_8_3());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 10 :
                    // InternalArchQualityDef.g:735:4: (otherlv_39= 'volume=' otherlv_40= '{' ( (lv_volume_41_0= RULE_STRING ) ) otherlv_42= '}' )?
                    {
                    // InternalArchQualityDef.g:735:4: (otherlv_39= 'volume=' otherlv_40= '{' ( (lv_volume_41_0= RULE_STRING ) ) otherlv_42= '}' )?
                    int alt15=2;
                    int LA15_0 = input.LA(1);

                    if ( (LA15_0==29) ) {
                        alt15=1;
                    }
                    switch (alt15) {
                        case 1 :
                            // InternalArchQualityDef.g:736:5: otherlv_39= 'volume=' otherlv_40= '{' ( (lv_volume_41_0= RULE_STRING ) ) otherlv_42= '}'
                            {
                            otherlv_39=(Token)match(input,29,FOLLOW_3); 

                            					newLeafNode(otherlv_39, grammarAccess.getFieldAccess().getVolumeKeyword_1_9_0());
                            				
                            otherlv_40=(Token)match(input,12,FOLLOW_12); 

                            					newLeafNode(otherlv_40, grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_9_1());
                            				
                            // InternalArchQualityDef.g:744:5: ( (lv_volume_41_0= RULE_STRING ) )
                            // InternalArchQualityDef.g:745:6: (lv_volume_41_0= RULE_STRING )
                            {
                            // InternalArchQualityDef.g:745:6: (lv_volume_41_0= RULE_STRING )
                            // InternalArchQualityDef.g:746:7: lv_volume_41_0= RULE_STRING
                            {
                            lv_volume_41_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

                            							newLeafNode(lv_volume_41_0, grammarAccess.getFieldAccess().getVolumeSTRINGTerminalRuleCall_1_9_2_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getFieldRule());
                            							}
                            							setWithLastConsumed(
                            								current,
                            								"volume",
                            								lv_volume_41_0,
                            								"org.eclipse.xtext.common.Terminals.STRING");
                            						

                            }


                            }

                            otherlv_42=(Token)match(input,16,FOLLOW_2); 

                            					newLeafNode(otherlv_42, grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_9_3());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 11 :
                    // InternalArchQualityDef.g:768:4: (otherlv_43= 'editor=' otherlv_44= '{' ( (lv_editor_45_0= RULE_STRING ) ) otherlv_46= '}' )?
                    {
                    // InternalArchQualityDef.g:768:4: (otherlv_43= 'editor=' otherlv_44= '{' ( (lv_editor_45_0= RULE_STRING ) ) otherlv_46= '}' )?
                    int alt16=2;
                    int LA16_0 = input.LA(1);

                    if ( (LA16_0==30) ) {
                        alt16=1;
                    }
                    switch (alt16) {
                        case 1 :
                            // InternalArchQualityDef.g:769:5: otherlv_43= 'editor=' otherlv_44= '{' ( (lv_editor_45_0= RULE_STRING ) ) otherlv_46= '}'
                            {
                            otherlv_43=(Token)match(input,30,FOLLOW_3); 

                            					newLeafNode(otherlv_43, grammarAccess.getFieldAccess().getEditorKeyword_1_10_0());
                            				
                            otherlv_44=(Token)match(input,12,FOLLOW_12); 

                            					newLeafNode(otherlv_44, grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_10_1());
                            				
                            // InternalArchQualityDef.g:777:5: ( (lv_editor_45_0= RULE_STRING ) )
                            // InternalArchQualityDef.g:778:6: (lv_editor_45_0= RULE_STRING )
                            {
                            // InternalArchQualityDef.g:778:6: (lv_editor_45_0= RULE_STRING )
                            // InternalArchQualityDef.g:779:7: lv_editor_45_0= RULE_STRING
                            {
                            lv_editor_45_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

                            							newLeafNode(lv_editor_45_0, grammarAccess.getFieldAccess().getEditorSTRINGTerminalRuleCall_1_10_2_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getFieldRule());
                            							}
                            							setWithLastConsumed(
                            								current,
                            								"editor",
                            								lv_editor_45_0,
                            								"org.eclipse.xtext.common.Terminals.STRING");
                            						

                            }


                            }

                            otherlv_46=(Token)match(input,16,FOLLOW_2); 

                            					newLeafNode(otherlv_46, grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_10_3());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 12 :
                    // InternalArchQualityDef.g:801:4: (otherlv_47= 'organization=' otherlv_48= '{' ( (lv_organization_49_0= RULE_STRING ) ) otherlv_50= '}' )?
                    {
                    // InternalArchQualityDef.g:801:4: (otherlv_47= 'organization=' otherlv_48= '{' ( (lv_organization_49_0= RULE_STRING ) ) otherlv_50= '}' )?
                    int alt17=2;
                    int LA17_0 = input.LA(1);

                    if ( (LA17_0==31) ) {
                        alt17=1;
                    }
                    switch (alt17) {
                        case 1 :
                            // InternalArchQualityDef.g:802:5: otherlv_47= 'organization=' otherlv_48= '{' ( (lv_organization_49_0= RULE_STRING ) ) otherlv_50= '}'
                            {
                            otherlv_47=(Token)match(input,31,FOLLOW_3); 

                            					newLeafNode(otherlv_47, grammarAccess.getFieldAccess().getOrganizationKeyword_1_11_0());
                            				
                            otherlv_48=(Token)match(input,12,FOLLOW_12); 

                            					newLeafNode(otherlv_48, grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_11_1());
                            				
                            // InternalArchQualityDef.g:810:5: ( (lv_organization_49_0= RULE_STRING ) )
                            // InternalArchQualityDef.g:811:6: (lv_organization_49_0= RULE_STRING )
                            {
                            // InternalArchQualityDef.g:811:6: (lv_organization_49_0= RULE_STRING )
                            // InternalArchQualityDef.g:812:7: lv_organization_49_0= RULE_STRING
                            {
                            lv_organization_49_0=(Token)match(input,RULE_STRING,FOLLOW_11); 

                            							newLeafNode(lv_organization_49_0, grammarAccess.getFieldAccess().getOrganizationSTRINGTerminalRuleCall_1_11_2_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getFieldRule());
                            							}
                            							setWithLastConsumed(
                            								current,
                            								"organization",
                            								lv_organization_49_0,
                            								"org.eclipse.xtext.common.Terminals.STRING");
                            						

                            }


                            }

                            otherlv_50=(Token)match(input,16,FOLLOW_2); 

                            					newLeafNode(otherlv_50, grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_11_3());
                            				

                            }
                            break;

                    }


                    }
                    break;
                case 13 :
                    // InternalArchQualityDef.g:834:4: (otherlv_51= 'note=' otherlv_52= '{' otherlv_53= 'Cited' otherlv_54= 'by:' ( (lv_citationscount_55_0= RULE_INT ) ) otherlv_56= '}' )?
                    {
                    // InternalArchQualityDef.g:834:4: (otherlv_51= 'note=' otherlv_52= '{' otherlv_53= 'Cited' otherlv_54= 'by:' ( (lv_citationscount_55_0= RULE_INT ) ) otherlv_56= '}' )?
                    int alt18=2;
                    int LA18_0 = input.LA(1);

                    if ( (LA18_0==32) ) {
                        alt18=1;
                    }
                    switch (alt18) {
                        case 1 :
                            // InternalArchQualityDef.g:835:5: otherlv_51= 'note=' otherlv_52= '{' otherlv_53= 'Cited' otherlv_54= 'by:' ( (lv_citationscount_55_0= RULE_INT ) ) otherlv_56= '}'
                            {
                            otherlv_51=(Token)match(input,32,FOLLOW_3); 

                            					newLeafNode(otherlv_51, grammarAccess.getFieldAccess().getNoteKeyword_1_12_0());
                            				
                            otherlv_52=(Token)match(input,12,FOLLOW_15); 

                            					newLeafNode(otherlv_52, grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_12_1());
                            				
                            otherlv_53=(Token)match(input,33,FOLLOW_16); 

                            					newLeafNode(otherlv_53, grammarAccess.getFieldAccess().getCitedKeyword_1_12_2());
                            				
                            otherlv_54=(Token)match(input,34,FOLLOW_17); 

                            					newLeafNode(otherlv_54, grammarAccess.getFieldAccess().getByKeyword_1_12_3());
                            				
                            // InternalArchQualityDef.g:851:5: ( (lv_citationscount_55_0= RULE_INT ) )
                            // InternalArchQualityDef.g:852:6: (lv_citationscount_55_0= RULE_INT )
                            {
                            // InternalArchQualityDef.g:852:6: (lv_citationscount_55_0= RULE_INT )
                            // InternalArchQualityDef.g:853:7: lv_citationscount_55_0= RULE_INT
                            {
                            lv_citationscount_55_0=(Token)match(input,RULE_INT,FOLLOW_11); 

                            							newLeafNode(lv_citationscount_55_0, grammarAccess.getFieldAccess().getCitationscountINTTerminalRuleCall_1_12_4_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getFieldRule());
                            							}
                            							setWithLastConsumed(
                            								current,
                            								"citationscount",
                            								lv_citationscount_55_0,
                            								"org.eclipse.xtext.common.Terminals.INT");
                            						

                            }


                            }

                            otherlv_56=(Token)match(input,16,FOLLOW_2); 

                            					newLeafNode(otherlv_56, grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_12_5());
                            				

                            }
                            break;

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleField"


    // $ANTLR start "entryRuleResearchContribution"
    // InternalArchQualityDef.g:879:1: entryRuleResearchContribution returns [EObject current=null] : iv_ruleResearchContribution= ruleResearchContribution EOF ;
    public final EObject entryRuleResearchContribution() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleResearchContribution = null;


        try {
            // InternalArchQualityDef.g:879:61: (iv_ruleResearchContribution= ruleResearchContribution EOF )
            // InternalArchQualityDef.g:880:2: iv_ruleResearchContribution= ruleResearchContribution EOF
            {
             newCompositeNode(grammarAccess.getResearchContributionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleResearchContribution=ruleResearchContribution();

            state._fsp--;

             current =iv_ruleResearchContribution; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleResearchContribution"


    // $ANTLR start "ruleResearchContribution"
    // InternalArchQualityDef.g:886:1: ruleResearchContribution returns [EObject current=null] : ( () otherlv_1= '@' (otherlv_2= 'article' | otherlv_3= 'book' | otherlv_4= 'inbook' | otherlv_5= 'booklet' | otherlv_6= 'misc' | otherlv_7= 'incollection' | otherlv_8= 'inproceedings' ) otherlv_9= '{' ( (lv_name_10_0= RULE_ID ) ) otherlv_11= ',' ( ( (lv_fields_12_0= ruleField ) ) (otherlv_13= ',' ( (lv_fields_14_0= ruleField ) ) )* ) otherlv_15= '}' ) ;
    public final EObject ruleResearchContribution() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token lv_name_10_0=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        EObject lv_fields_12_0 = null;

        EObject lv_fields_14_0 = null;



        	enterRule();

        try {
            // InternalArchQualityDef.g:892:2: ( ( () otherlv_1= '@' (otherlv_2= 'article' | otherlv_3= 'book' | otherlv_4= 'inbook' | otherlv_5= 'booklet' | otherlv_6= 'misc' | otherlv_7= 'incollection' | otherlv_8= 'inproceedings' ) otherlv_9= '{' ( (lv_name_10_0= RULE_ID ) ) otherlv_11= ',' ( ( (lv_fields_12_0= ruleField ) ) (otherlv_13= ',' ( (lv_fields_14_0= ruleField ) ) )* ) otherlv_15= '}' ) )
            // InternalArchQualityDef.g:893:2: ( () otherlv_1= '@' (otherlv_2= 'article' | otherlv_3= 'book' | otherlv_4= 'inbook' | otherlv_5= 'booklet' | otherlv_6= 'misc' | otherlv_7= 'incollection' | otherlv_8= 'inproceedings' ) otherlv_9= '{' ( (lv_name_10_0= RULE_ID ) ) otherlv_11= ',' ( ( (lv_fields_12_0= ruleField ) ) (otherlv_13= ',' ( (lv_fields_14_0= ruleField ) ) )* ) otherlv_15= '}' )
            {
            // InternalArchQualityDef.g:893:2: ( () otherlv_1= '@' (otherlv_2= 'article' | otherlv_3= 'book' | otherlv_4= 'inbook' | otherlv_5= 'booklet' | otherlv_6= 'misc' | otherlv_7= 'incollection' | otherlv_8= 'inproceedings' ) otherlv_9= '{' ( (lv_name_10_0= RULE_ID ) ) otherlv_11= ',' ( ( (lv_fields_12_0= ruleField ) ) (otherlv_13= ',' ( (lv_fields_14_0= ruleField ) ) )* ) otherlv_15= '}' )
            // InternalArchQualityDef.g:894:3: () otherlv_1= '@' (otherlv_2= 'article' | otherlv_3= 'book' | otherlv_4= 'inbook' | otherlv_5= 'booklet' | otherlv_6= 'misc' | otherlv_7= 'incollection' | otherlv_8= 'inproceedings' ) otherlv_9= '{' ( (lv_name_10_0= RULE_ID ) ) otherlv_11= ',' ( ( (lv_fields_12_0= ruleField ) ) (otherlv_13= ',' ( (lv_fields_14_0= ruleField ) ) )* ) otherlv_15= '}'
            {
            // InternalArchQualityDef.g:894:3: ()
            // InternalArchQualityDef.g:895:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getResearchContributionAccess().getResearchContributionAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,35,FOLLOW_18); 

            			newLeafNode(otherlv_1, grammarAccess.getResearchContributionAccess().getCommercialAtKeyword_1());
            		
            // InternalArchQualityDef.g:905:3: (otherlv_2= 'article' | otherlv_3= 'book' | otherlv_4= 'inbook' | otherlv_5= 'booklet' | otherlv_6= 'misc' | otherlv_7= 'incollection' | otherlv_8= 'inproceedings' )
            int alt20=7;
            switch ( input.LA(1) ) {
            case 36:
                {
                alt20=1;
                }
                break;
            case 37:
                {
                alt20=2;
                }
                break;
            case 38:
                {
                alt20=3;
                }
                break;
            case 39:
                {
                alt20=4;
                }
                break;
            case 40:
                {
                alt20=5;
                }
                break;
            case 41:
                {
                alt20=6;
                }
                break;
            case 42:
                {
                alt20=7;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 20, 0, input);

                throw nvae;
            }

            switch (alt20) {
                case 1 :
                    // InternalArchQualityDef.g:906:4: otherlv_2= 'article'
                    {
                    otherlv_2=(Token)match(input,36,FOLLOW_3); 

                    				newLeafNode(otherlv_2, grammarAccess.getResearchContributionAccess().getArticleKeyword_2_0());
                    			

                    }
                    break;
                case 2 :
                    // InternalArchQualityDef.g:911:4: otherlv_3= 'book'
                    {
                    otherlv_3=(Token)match(input,37,FOLLOW_3); 

                    				newLeafNode(otherlv_3, grammarAccess.getResearchContributionAccess().getBookKeyword_2_1());
                    			

                    }
                    break;
                case 3 :
                    // InternalArchQualityDef.g:916:4: otherlv_4= 'inbook'
                    {
                    otherlv_4=(Token)match(input,38,FOLLOW_3); 

                    				newLeafNode(otherlv_4, grammarAccess.getResearchContributionAccess().getInbookKeyword_2_2());
                    			

                    }
                    break;
                case 4 :
                    // InternalArchQualityDef.g:921:4: otherlv_5= 'booklet'
                    {
                    otherlv_5=(Token)match(input,39,FOLLOW_3); 

                    				newLeafNode(otherlv_5, grammarAccess.getResearchContributionAccess().getBookletKeyword_2_3());
                    			

                    }
                    break;
                case 5 :
                    // InternalArchQualityDef.g:926:4: otherlv_6= 'misc'
                    {
                    otherlv_6=(Token)match(input,40,FOLLOW_3); 

                    				newLeafNode(otherlv_6, grammarAccess.getResearchContributionAccess().getMiscKeyword_2_4());
                    			

                    }
                    break;
                case 6 :
                    // InternalArchQualityDef.g:931:4: otherlv_7= 'incollection'
                    {
                    otherlv_7=(Token)match(input,41,FOLLOW_3); 

                    				newLeafNode(otherlv_7, grammarAccess.getResearchContributionAccess().getIncollectionKeyword_2_5());
                    			

                    }
                    break;
                case 7 :
                    // InternalArchQualityDef.g:936:4: otherlv_8= 'inproceedings'
                    {
                    otherlv_8=(Token)match(input,42,FOLLOW_3); 

                    				newLeafNode(otherlv_8, grammarAccess.getResearchContributionAccess().getInproceedingsKeyword_2_6());
                    			

                    }
                    break;

            }

            otherlv_9=(Token)match(input,12,FOLLOW_19); 

            			newLeafNode(otherlv_9, grammarAccess.getResearchContributionAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalArchQualityDef.g:945:3: ( (lv_name_10_0= RULE_ID ) )
            // InternalArchQualityDef.g:946:4: (lv_name_10_0= RULE_ID )
            {
            // InternalArchQualityDef.g:946:4: (lv_name_10_0= RULE_ID )
            // InternalArchQualityDef.g:947:5: lv_name_10_0= RULE_ID
            {
            lv_name_10_0=(Token)match(input,RULE_ID,FOLLOW_20); 

            					newLeafNode(lv_name_10_0, grammarAccess.getResearchContributionAccess().getNameIDTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getResearchContributionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_10_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_11=(Token)match(input,15,FOLLOW_21); 

            			newLeafNode(otherlv_11, grammarAccess.getResearchContributionAccess().getCommaKeyword_5());
            		
            // InternalArchQualityDef.g:967:3: ( ( (lv_fields_12_0= ruleField ) ) (otherlv_13= ',' ( (lv_fields_14_0= ruleField ) ) )* )
            // InternalArchQualityDef.g:968:4: ( (lv_fields_12_0= ruleField ) ) (otherlv_13= ',' ( (lv_fields_14_0= ruleField ) ) )*
            {
            // InternalArchQualityDef.g:968:4: ( (lv_fields_12_0= ruleField ) )
            // InternalArchQualityDef.g:969:5: (lv_fields_12_0= ruleField )
            {
            // InternalArchQualityDef.g:969:5: (lv_fields_12_0= ruleField )
            // InternalArchQualityDef.g:970:6: lv_fields_12_0= ruleField
            {

            						newCompositeNode(grammarAccess.getResearchContributionAccess().getFieldsFieldParserRuleCall_6_0_0());
            					
            pushFollow(FOLLOW_8);
            lv_fields_12_0=ruleField();

            state._fsp--;


            						if (current==null) {
            							current = createModelElementForParent(grammarAccess.getResearchContributionRule());
            						}
            						add(
            							current,
            							"fields",
            							lv_fields_12_0,
            							"it.gssi.cs.archqualitydef.ArchQualityDef.Field");
            						afterParserOrEnumRuleCall();
            					

            }


            }

            // InternalArchQualityDef.g:987:4: (otherlv_13= ',' ( (lv_fields_14_0= ruleField ) ) )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( (LA21_0==15) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // InternalArchQualityDef.g:988:5: otherlv_13= ',' ( (lv_fields_14_0= ruleField ) )
            	    {
            	    otherlv_13=(Token)match(input,15,FOLLOW_21); 

            	    					newLeafNode(otherlv_13, grammarAccess.getResearchContributionAccess().getCommaKeyword_6_1_0());
            	    				
            	    // InternalArchQualityDef.g:992:5: ( (lv_fields_14_0= ruleField ) )
            	    // InternalArchQualityDef.g:993:6: (lv_fields_14_0= ruleField )
            	    {
            	    // InternalArchQualityDef.g:993:6: (lv_fields_14_0= ruleField )
            	    // InternalArchQualityDef.g:994:7: lv_fields_14_0= ruleField
            	    {

            	    							newCompositeNode(grammarAccess.getResearchContributionAccess().getFieldsFieldParserRuleCall_6_1_1_0());
            	    						
            	    pushFollow(FOLLOW_8);
            	    lv_fields_14_0=ruleField();

            	    state._fsp--;


            	    							if (current==null) {
            	    								current = createModelElementForParent(grammarAccess.getResearchContributionRule());
            	    							}
            	    							add(
            	    								current,
            	    								"fields",
            	    								lv_fields_14_0,
            	    								"it.gssi.cs.archqualitydef.ArchQualityDef.Field");
            	    							afterParserOrEnumRuleCall();
            	    						

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);


            }

            otherlv_15=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_15, grammarAccess.getResearchContributionAccess().getRightCurlyBracketKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleResearchContribution"


    // $ANTLR start "entryRuleMetric"
    // InternalArchQualityDef.g:1021:1: entryRuleMetric returns [EObject current=null] : iv_ruleMetric= ruleMetric EOF ;
    public final EObject entryRuleMetric() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMetric = null;


        try {
            // InternalArchQualityDef.g:1021:47: (iv_ruleMetric= ruleMetric EOF )
            // InternalArchQualityDef.g:1022:2: iv_ruleMetric= ruleMetric EOF
            {
             newCompositeNode(grammarAccess.getMetricRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMetric=ruleMetric();

            state._fsp--;

             current =iv_ruleMetric; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMetric"


    // $ANTLR start "ruleMetric"
    // InternalArchQualityDef.g:1028:1: ruleMetric returns [EObject current=null] : (otherlv_0= 'Metric' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) ) )? (otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']' )? ) ;
    public final EObject ruleMetric() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token lv_description_3_0=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token otherlv_8=null;


        	enterRule();

        try {
            // InternalArchQualityDef.g:1034:2: ( (otherlv_0= 'Metric' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) ) )? (otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']' )? ) )
            // InternalArchQualityDef.g:1035:2: (otherlv_0= 'Metric' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) ) )? (otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']' )? )
            {
            // InternalArchQualityDef.g:1035:2: (otherlv_0= 'Metric' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) ) )? (otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']' )? )
            // InternalArchQualityDef.g:1036:3: otherlv_0= 'Metric' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) ) )? (otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']' )?
            {
            otherlv_0=(Token)match(input,43,FOLLOW_19); 

            			newLeafNode(otherlv_0, grammarAccess.getMetricAccess().getMetricKeyword_0());
            		
            // InternalArchQualityDef.g:1040:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalArchQualityDef.g:1041:4: (lv_name_1_0= RULE_ID )
            {
            // InternalArchQualityDef.g:1041:4: (lv_name_1_0= RULE_ID )
            // InternalArchQualityDef.g:1042:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_22); 

            					newLeafNode(lv_name_1_0, grammarAccess.getMetricAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMetricRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalArchQualityDef.g:1058:3: (otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) ) )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==44) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // InternalArchQualityDef.g:1059:4: otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) )
                    {
                    otherlv_2=(Token)match(input,44,FOLLOW_12); 

                    				newLeafNode(otherlv_2, grammarAccess.getMetricAccess().getDescriptionKeyword_2_0());
                    			
                    // InternalArchQualityDef.g:1063:4: ( (lv_description_3_0= RULE_STRING ) )
                    // InternalArchQualityDef.g:1064:5: (lv_description_3_0= RULE_STRING )
                    {
                    // InternalArchQualityDef.g:1064:5: (lv_description_3_0= RULE_STRING )
                    // InternalArchQualityDef.g:1065:6: lv_description_3_0= RULE_STRING
                    {
                    lv_description_3_0=(Token)match(input,RULE_STRING,FOLLOW_23); 

                    						newLeafNode(lv_description_3_0, grammarAccess.getMetricAccess().getDescriptionSTRINGTerminalRuleCall_2_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getMetricRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"description",
                    							lv_description_3_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalArchQualityDef.g:1082:3: (otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']' )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==45) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // InternalArchQualityDef.g:1083:4: otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']'
                    {
                    otherlv_4=(Token)match(input,45,FOLLOW_19); 

                    				newLeafNode(otherlv_4, grammarAccess.getMetricAccess().getLeftSquareBracketKeyword_3_0());
                    			
                    // InternalArchQualityDef.g:1087:4: ( (otherlv_5= RULE_ID ) )
                    // InternalArchQualityDef.g:1088:5: (otherlv_5= RULE_ID )
                    {
                    // InternalArchQualityDef.g:1088:5: (otherlv_5= RULE_ID )
                    // InternalArchQualityDef.g:1089:6: otherlv_5= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getMetricRule());
                    						}
                    					
                    otherlv_5=(Token)match(input,RULE_ID,FOLLOW_24); 

                    						newLeafNode(otherlv_5, grammarAccess.getMetricAccess().getEvidenceResearchContributionCrossReference_3_1_0());
                    					

                    }


                    }

                    // InternalArchQualityDef.g:1100:4: (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )*
                    loop23:
                    do {
                        int alt23=2;
                        int LA23_0 = input.LA(1);

                        if ( (LA23_0==15) ) {
                            alt23=1;
                        }


                        switch (alt23) {
                    	case 1 :
                    	    // InternalArchQualityDef.g:1101:5: otherlv_6= ',' ( (otherlv_7= RULE_ID ) )
                    	    {
                    	    otherlv_6=(Token)match(input,15,FOLLOW_19); 

                    	    					newLeafNode(otherlv_6, grammarAccess.getMetricAccess().getCommaKeyword_3_2_0());
                    	    				
                    	    // InternalArchQualityDef.g:1105:5: ( (otherlv_7= RULE_ID ) )
                    	    // InternalArchQualityDef.g:1106:6: (otherlv_7= RULE_ID )
                    	    {
                    	    // InternalArchQualityDef.g:1106:6: (otherlv_7= RULE_ID )
                    	    // InternalArchQualityDef.g:1107:7: otherlv_7= RULE_ID
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getMetricRule());
                    	    							}
                    	    						
                    	    otherlv_7=(Token)match(input,RULE_ID,FOLLOW_24); 

                    	    							newLeafNode(otherlv_7, grammarAccess.getMetricAccess().getEvidenceResearchContributionCrossReference_3_2_1_0());
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop23;
                        }
                    } while (true);

                    otherlv_8=(Token)match(input,46,FOLLOW_2); 

                    				newLeafNode(otherlv_8, grammarAccess.getMetricAccess().getRightSquareBracketKeyword_3_3());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMetric"


    // $ANTLR start "entryRuleQualityAttribute"
    // InternalArchQualityDef.g:1128:1: entryRuleQualityAttribute returns [EObject current=null] : iv_ruleQualityAttribute= ruleQualityAttribute EOF ;
    public final EObject entryRuleQualityAttribute() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleQualityAttribute = null;


        try {
            // InternalArchQualityDef.g:1128:57: (iv_ruleQualityAttribute= ruleQualityAttribute EOF )
            // InternalArchQualityDef.g:1129:2: iv_ruleQualityAttribute= ruleQualityAttribute EOF
            {
             newCompositeNode(grammarAccess.getQualityAttributeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleQualityAttribute=ruleQualityAttribute();

            state._fsp--;

             current =iv_ruleQualityAttribute; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleQualityAttribute"


    // $ANTLR start "ruleQualityAttribute"
    // InternalArchQualityDef.g:1135:1: ruleQualityAttribute returns [EObject current=null] : (otherlv_0= 'QualityAttribute' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) ) )? (otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']' )? ) ;
    public final EObject ruleQualityAttribute() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token lv_description_3_0=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token otherlv_8=null;


        	enterRule();

        try {
            // InternalArchQualityDef.g:1141:2: ( (otherlv_0= 'QualityAttribute' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) ) )? (otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']' )? ) )
            // InternalArchQualityDef.g:1142:2: (otherlv_0= 'QualityAttribute' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) ) )? (otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']' )? )
            {
            // InternalArchQualityDef.g:1142:2: (otherlv_0= 'QualityAttribute' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) ) )? (otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']' )? )
            // InternalArchQualityDef.g:1143:3: otherlv_0= 'QualityAttribute' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) ) )? (otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']' )?
            {
            otherlv_0=(Token)match(input,47,FOLLOW_19); 

            			newLeafNode(otherlv_0, grammarAccess.getQualityAttributeAccess().getQualityAttributeKeyword_0());
            		
            // InternalArchQualityDef.g:1147:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalArchQualityDef.g:1148:4: (lv_name_1_0= RULE_ID )
            {
            // InternalArchQualityDef.g:1148:4: (lv_name_1_0= RULE_ID )
            // InternalArchQualityDef.g:1149:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_22); 

            					newLeafNode(lv_name_1_0, grammarAccess.getQualityAttributeAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getQualityAttributeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalArchQualityDef.g:1165:3: (otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) ) )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==44) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalArchQualityDef.g:1166:4: otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) )
                    {
                    otherlv_2=(Token)match(input,44,FOLLOW_12); 

                    				newLeafNode(otherlv_2, grammarAccess.getQualityAttributeAccess().getDescriptionKeyword_2_0());
                    			
                    // InternalArchQualityDef.g:1170:4: ( (lv_description_3_0= RULE_STRING ) )
                    // InternalArchQualityDef.g:1171:5: (lv_description_3_0= RULE_STRING )
                    {
                    // InternalArchQualityDef.g:1171:5: (lv_description_3_0= RULE_STRING )
                    // InternalArchQualityDef.g:1172:6: lv_description_3_0= RULE_STRING
                    {
                    lv_description_3_0=(Token)match(input,RULE_STRING,FOLLOW_23); 

                    						newLeafNode(lv_description_3_0, grammarAccess.getQualityAttributeAccess().getDescriptionSTRINGTerminalRuleCall_2_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getQualityAttributeRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"description",
                    							lv_description_3_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalArchQualityDef.g:1189:3: (otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']' )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==45) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalArchQualityDef.g:1190:4: otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']'
                    {
                    otherlv_4=(Token)match(input,45,FOLLOW_19); 

                    				newLeafNode(otherlv_4, grammarAccess.getQualityAttributeAccess().getLeftSquareBracketKeyword_3_0());
                    			
                    // InternalArchQualityDef.g:1194:4: ( (otherlv_5= RULE_ID ) )
                    // InternalArchQualityDef.g:1195:5: (otherlv_5= RULE_ID )
                    {
                    // InternalArchQualityDef.g:1195:5: (otherlv_5= RULE_ID )
                    // InternalArchQualityDef.g:1196:6: otherlv_5= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getQualityAttributeRule());
                    						}
                    					
                    otherlv_5=(Token)match(input,RULE_ID,FOLLOW_24); 

                    						newLeafNode(otherlv_5, grammarAccess.getQualityAttributeAccess().getEvidenceResearchContributionCrossReference_3_1_0());
                    					

                    }


                    }

                    // InternalArchQualityDef.g:1207:4: (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )*
                    loop26:
                    do {
                        int alt26=2;
                        int LA26_0 = input.LA(1);

                        if ( (LA26_0==15) ) {
                            alt26=1;
                        }


                        switch (alt26) {
                    	case 1 :
                    	    // InternalArchQualityDef.g:1208:5: otherlv_6= ',' ( (otherlv_7= RULE_ID ) )
                    	    {
                    	    otherlv_6=(Token)match(input,15,FOLLOW_19); 

                    	    					newLeafNode(otherlv_6, grammarAccess.getQualityAttributeAccess().getCommaKeyword_3_2_0());
                    	    				
                    	    // InternalArchQualityDef.g:1212:5: ( (otherlv_7= RULE_ID ) )
                    	    // InternalArchQualityDef.g:1213:6: (otherlv_7= RULE_ID )
                    	    {
                    	    // InternalArchQualityDef.g:1213:6: (otherlv_7= RULE_ID )
                    	    // InternalArchQualityDef.g:1214:7: otherlv_7= RULE_ID
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getQualityAttributeRule());
                    	    							}
                    	    						
                    	    otherlv_7=(Token)match(input,RULE_ID,FOLLOW_24); 

                    	    							newLeafNode(otherlv_7, grammarAccess.getQualityAttributeAccess().getEvidenceResearchContributionCrossReference_3_2_1_0());
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop26;
                        }
                    } while (true);

                    otherlv_8=(Token)match(input,46,FOLLOW_2); 

                    				newLeafNode(otherlv_8, grammarAccess.getQualityAttributeAccess().getRightSquareBracketKeyword_3_3());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleQualityAttribute"


    // $ANTLR start "entryRuleQualityCharacteristic"
    // InternalArchQualityDef.g:1235:1: entryRuleQualityCharacteristic returns [EObject current=null] : iv_ruleQualityCharacteristic= ruleQualityCharacteristic EOF ;
    public final EObject entryRuleQualityCharacteristic() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleQualityCharacteristic = null;


        try {
            // InternalArchQualityDef.g:1235:62: (iv_ruleQualityCharacteristic= ruleQualityCharacteristic EOF )
            // InternalArchQualityDef.g:1236:2: iv_ruleQualityCharacteristic= ruleQualityCharacteristic EOF
            {
             newCompositeNode(grammarAccess.getQualityCharacteristicRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleQualityCharacteristic=ruleQualityCharacteristic();

            state._fsp--;

             current =iv_ruleQualityCharacteristic; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleQualityCharacteristic"


    // $ANTLR start "ruleQualityCharacteristic"
    // InternalArchQualityDef.g:1242:1: ruleQualityCharacteristic returns [EObject current=null] : (otherlv_0= 'QualityCharacteristic' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) ) )? (otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']' )? ) ;
    public final EObject ruleQualityCharacteristic() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token lv_description_3_0=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token otherlv_8=null;


        	enterRule();

        try {
            // InternalArchQualityDef.g:1248:2: ( (otherlv_0= 'QualityCharacteristic' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) ) )? (otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']' )? ) )
            // InternalArchQualityDef.g:1249:2: (otherlv_0= 'QualityCharacteristic' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) ) )? (otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']' )? )
            {
            // InternalArchQualityDef.g:1249:2: (otherlv_0= 'QualityCharacteristic' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) ) )? (otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']' )? )
            // InternalArchQualityDef.g:1250:3: otherlv_0= 'QualityCharacteristic' ( (lv_name_1_0= RULE_ID ) ) (otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) ) )? (otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']' )?
            {
            otherlv_0=(Token)match(input,48,FOLLOW_19); 

            			newLeafNode(otherlv_0, grammarAccess.getQualityCharacteristicAccess().getQualityCharacteristicKeyword_0());
            		
            // InternalArchQualityDef.g:1254:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalArchQualityDef.g:1255:4: (lv_name_1_0= RULE_ID )
            {
            // InternalArchQualityDef.g:1255:4: (lv_name_1_0= RULE_ID )
            // InternalArchQualityDef.g:1256:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_22); 

            					newLeafNode(lv_name_1_0, grammarAccess.getQualityCharacteristicAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getQualityCharacteristicRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalArchQualityDef.g:1272:3: (otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) ) )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==44) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalArchQualityDef.g:1273:4: otherlv_2= 'description:' ( (lv_description_3_0= RULE_STRING ) )
                    {
                    otherlv_2=(Token)match(input,44,FOLLOW_12); 

                    				newLeafNode(otherlv_2, grammarAccess.getQualityCharacteristicAccess().getDescriptionKeyword_2_0());
                    			
                    // InternalArchQualityDef.g:1277:4: ( (lv_description_3_0= RULE_STRING ) )
                    // InternalArchQualityDef.g:1278:5: (lv_description_3_0= RULE_STRING )
                    {
                    // InternalArchQualityDef.g:1278:5: (lv_description_3_0= RULE_STRING )
                    // InternalArchQualityDef.g:1279:6: lv_description_3_0= RULE_STRING
                    {
                    lv_description_3_0=(Token)match(input,RULE_STRING,FOLLOW_23); 

                    						newLeafNode(lv_description_3_0, grammarAccess.getQualityCharacteristicAccess().getDescriptionSTRINGTerminalRuleCall_2_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getQualityCharacteristicRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"description",
                    							lv_description_3_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalArchQualityDef.g:1296:3: (otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']' )?
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( (LA30_0==45) ) {
                alt30=1;
            }
            switch (alt30) {
                case 1 :
                    // InternalArchQualityDef.g:1297:4: otherlv_4= '[' ( (otherlv_5= RULE_ID ) ) (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )* otherlv_8= ']'
                    {
                    otherlv_4=(Token)match(input,45,FOLLOW_19); 

                    				newLeafNode(otherlv_4, grammarAccess.getQualityCharacteristicAccess().getLeftSquareBracketKeyword_3_0());
                    			
                    // InternalArchQualityDef.g:1301:4: ( (otherlv_5= RULE_ID ) )
                    // InternalArchQualityDef.g:1302:5: (otherlv_5= RULE_ID )
                    {
                    // InternalArchQualityDef.g:1302:5: (otherlv_5= RULE_ID )
                    // InternalArchQualityDef.g:1303:6: otherlv_5= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getQualityCharacteristicRule());
                    						}
                    					
                    otherlv_5=(Token)match(input,RULE_ID,FOLLOW_24); 

                    						newLeafNode(otherlv_5, grammarAccess.getQualityCharacteristicAccess().getEvidenceResearchContributionCrossReference_3_1_0());
                    					

                    }


                    }

                    // InternalArchQualityDef.g:1314:4: (otherlv_6= ',' ( (otherlv_7= RULE_ID ) ) )*
                    loop29:
                    do {
                        int alt29=2;
                        int LA29_0 = input.LA(1);

                        if ( (LA29_0==15) ) {
                            alt29=1;
                        }


                        switch (alt29) {
                    	case 1 :
                    	    // InternalArchQualityDef.g:1315:5: otherlv_6= ',' ( (otherlv_7= RULE_ID ) )
                    	    {
                    	    otherlv_6=(Token)match(input,15,FOLLOW_19); 

                    	    					newLeafNode(otherlv_6, grammarAccess.getQualityCharacteristicAccess().getCommaKeyword_3_2_0());
                    	    				
                    	    // InternalArchQualityDef.g:1319:5: ( (otherlv_7= RULE_ID ) )
                    	    // InternalArchQualityDef.g:1320:6: (otherlv_7= RULE_ID )
                    	    {
                    	    // InternalArchQualityDef.g:1320:6: (otherlv_7= RULE_ID )
                    	    // InternalArchQualityDef.g:1321:7: otherlv_7= RULE_ID
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getQualityCharacteristicRule());
                    	    							}
                    	    						
                    	    otherlv_7=(Token)match(input,RULE_ID,FOLLOW_24); 

                    	    							newLeafNode(otherlv_7, grammarAccess.getQualityCharacteristicAccess().getEvidenceResearchContributionCrossReference_3_2_1_0());
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop29;
                        }
                    } while (true);

                    otherlv_8=(Token)match(input,46,FOLLOW_2); 

                    				newLeafNode(otherlv_8, grammarAccess.getQualityCharacteristicAccess().getRightSquareBracketKeyword_3_3());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleQualityCharacteristic"


    // $ANTLR start "entryRuleQualityRel"
    // InternalArchQualityDef.g:1342:1: entryRuleQualityRel returns [EObject current=null] : iv_ruleQualityRel= ruleQualityRel EOF ;
    public final EObject entryRuleQualityRel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleQualityRel = null;


        try {
            // InternalArchQualityDef.g:1342:51: (iv_ruleQualityRel= ruleQualityRel EOF )
            // InternalArchQualityDef.g:1343:2: iv_ruleQualityRel= ruleQualityRel EOF
            {
             newCompositeNode(grammarAccess.getQualityRelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleQualityRel=ruleQualityRel();

            state._fsp--;

             current =iv_ruleQualityRel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleQualityRel"


    // $ANTLR start "ruleQualityRel"
    // InternalArchQualityDef.g:1349:1: ruleQualityRel returns [EObject current=null] : ( ( (otherlv_0= RULE_ID ) ) otherlv_1= '->' ( (otherlv_2= RULE_ID ) ) (otherlv_3= '[' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* otherlv_7= ']' )? ) ;
    public final EObject ruleQualityRel() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;


        	enterRule();

        try {
            // InternalArchQualityDef.g:1355:2: ( ( ( (otherlv_0= RULE_ID ) ) otherlv_1= '->' ( (otherlv_2= RULE_ID ) ) (otherlv_3= '[' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* otherlv_7= ']' )? ) )
            // InternalArchQualityDef.g:1356:2: ( ( (otherlv_0= RULE_ID ) ) otherlv_1= '->' ( (otherlv_2= RULE_ID ) ) (otherlv_3= '[' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* otherlv_7= ']' )? )
            {
            // InternalArchQualityDef.g:1356:2: ( ( (otherlv_0= RULE_ID ) ) otherlv_1= '->' ( (otherlv_2= RULE_ID ) ) (otherlv_3= '[' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* otherlv_7= ']' )? )
            // InternalArchQualityDef.g:1357:3: ( (otherlv_0= RULE_ID ) ) otherlv_1= '->' ( (otherlv_2= RULE_ID ) ) (otherlv_3= '[' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* otherlv_7= ']' )?
            {
            // InternalArchQualityDef.g:1357:3: ( (otherlv_0= RULE_ID ) )
            // InternalArchQualityDef.g:1358:4: (otherlv_0= RULE_ID )
            {
            // InternalArchQualityDef.g:1358:4: (otherlv_0= RULE_ID )
            // InternalArchQualityDef.g:1359:5: otherlv_0= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getQualityRelRule());
            					}
            				
            otherlv_0=(Token)match(input,RULE_ID,FOLLOW_25); 

            					newLeafNode(otherlv_0, grammarAccess.getQualityRelAccess().getSrcQualityElementCrossReference_0_0());
            				

            }


            }

            otherlv_1=(Token)match(input,49,FOLLOW_19); 

            			newLeafNode(otherlv_1, grammarAccess.getQualityRelAccess().getHyphenMinusGreaterThanSignKeyword_1());
            		
            // InternalArchQualityDef.g:1374:3: ( (otherlv_2= RULE_ID ) )
            // InternalArchQualityDef.g:1375:4: (otherlv_2= RULE_ID )
            {
            // InternalArchQualityDef.g:1375:4: (otherlv_2= RULE_ID )
            // InternalArchQualityDef.g:1376:5: otherlv_2= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getQualityRelRule());
            					}
            				
            otherlv_2=(Token)match(input,RULE_ID,FOLLOW_23); 

            					newLeafNode(otherlv_2, grammarAccess.getQualityRelAccess().getTrgQualityElementCrossReference_2_0());
            				

            }


            }

            // InternalArchQualityDef.g:1387:3: (otherlv_3= '[' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* otherlv_7= ']' )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==45) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // InternalArchQualityDef.g:1388:4: otherlv_3= '[' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* otherlv_7= ']'
                    {
                    otherlv_3=(Token)match(input,45,FOLLOW_19); 

                    				newLeafNode(otherlv_3, grammarAccess.getQualityRelAccess().getLeftSquareBracketKeyword_3_0());
                    			
                    // InternalArchQualityDef.g:1392:4: ( (otherlv_4= RULE_ID ) )
                    // InternalArchQualityDef.g:1393:5: (otherlv_4= RULE_ID )
                    {
                    // InternalArchQualityDef.g:1393:5: (otherlv_4= RULE_ID )
                    // InternalArchQualityDef.g:1394:6: otherlv_4= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getQualityRelRule());
                    						}
                    					
                    otherlv_4=(Token)match(input,RULE_ID,FOLLOW_24); 

                    						newLeafNode(otherlv_4, grammarAccess.getQualityRelAccess().getEvidenceResearchContributionCrossReference_3_1_0());
                    					

                    }


                    }

                    // InternalArchQualityDef.g:1405:4: (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )*
                    loop31:
                    do {
                        int alt31=2;
                        int LA31_0 = input.LA(1);

                        if ( (LA31_0==15) ) {
                            alt31=1;
                        }


                        switch (alt31) {
                    	case 1 :
                    	    // InternalArchQualityDef.g:1406:5: otherlv_5= ',' ( (otherlv_6= RULE_ID ) )
                    	    {
                    	    otherlv_5=(Token)match(input,15,FOLLOW_19); 

                    	    					newLeafNode(otherlv_5, grammarAccess.getQualityRelAccess().getCommaKeyword_3_2_0());
                    	    				
                    	    // InternalArchQualityDef.g:1410:5: ( (otherlv_6= RULE_ID ) )
                    	    // InternalArchQualityDef.g:1411:6: (otherlv_6= RULE_ID )
                    	    {
                    	    // InternalArchQualityDef.g:1411:6: (otherlv_6= RULE_ID )
                    	    // InternalArchQualityDef.g:1412:7: otherlv_6= RULE_ID
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getQualityRelRule());
                    	    							}
                    	    						
                    	    otherlv_6=(Token)match(input,RULE_ID,FOLLOW_24); 

                    	    							newLeafNode(otherlv_6, grammarAccess.getQualityRelAccess().getEvidenceResearchContributionCrossReference_3_2_1_0());
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop31;
                        }
                    } while (true);

                    otherlv_7=(Token)match(input,46,FOLLOW_2); 

                    				newLeafNode(otherlv_7, grammarAccess.getQualityRelAccess().getRightSquareBracketKeyword_3_3());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleQualityRel"

    // Delegated rules


    protected DFA19 dfa19 = new DFA19(this);
    static final String dfa_1s = "\21\uffff";
    static final String dfa_2s = "\1\5\20\uffff";
    static final String dfa_3s = "\1\17\20\uffff";
    static final String dfa_4s = "\1\40\20\uffff";
    static final String dfa_5s = "\1\uffff\1\1\1\2\1\3\4\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1\14\1\15";
    static final String dfa_6s = "\21\uffff}>";
    static final String[] dfa_7s = {
            "\1\6\1\7\2\uffff\1\1\1\uffff\1\2\1\3\1\4\1\10\1\11\1\12\1\13\1\14\1\15\1\16\1\17\1\20",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final short[] dfa_2 = DFA.unpackEncodedString(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final char[] dfa_4 = DFA.unpackEncodedStringToUnsignedChars(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[] dfa_6 = DFA.unpackEncodedString(dfa_6s);
    static final short[][] dfa_7 = unpackEncodedStringArray(dfa_7s);

    class DFA19 extends DFA {

        public DFA19(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 19;
            this.eot = dfa_1;
            this.eof = dfa_2;
            this.min = dfa_3;
            this.max = dfa_4;
            this.accept = dfa_5;
            this.special = dfa_6;
            this.transition = dfa_7;
        }
        public String getDescription() {
            return "411:3: ( (otherlv_1= 'author=' otherlv_2= '{' ( (lv_authors_3_0= ruleAuthor ) ) (otherlv_4= 'and' ( (lv_authors_5_0= ruleAuthor ) ) )? otherlv_6= '}' ) | (otherlv_7= 'title=' otherlv_8= '{' ( (lv_title_9_0= RULE_STRING ) ) otherlv_10= '}' ) | (otherlv_11= 'year=' otherlv_12= '{' ( (lv_year_13_0= RULE_STRING ) ) otherlv_14= '}' ) | (otherlv_15= 'pages=' otherlv_16= '{' ( (lv_pages_17_0= RULE_STRING ) ) otherlv_18= '}' )? | (otherlv_19= 'address=' otherlv_20= '{' ( (lv_address_21_0= RULE_STRING ) ) otherlv_22= '}' )? | (otherlv_23= 'booktitle=' otherlv_24= '{' ( (lv_booktitle_25_0= RULE_STRING ) ) otherlv_26= '}' )? | (otherlv_27= 'journal=' otherlv_28= '{' ( (lv_journal_29_0= RULE_STRING ) ) otherlv_30= '}' )? | (otherlv_31= 'chapter=' otherlv_32= '{' ( (lv_chapter_33_0= RULE_STRING ) ) otherlv_34= '}' )? | (otherlv_35= 'series=' otherlv_36= '{' ( (lv_series_37_0= RULE_STRING ) ) otherlv_38= '}' )? | (otherlv_39= 'volume=' otherlv_40= '{' ( (lv_volume_41_0= RULE_STRING ) ) otherlv_42= '}' )? | (otherlv_43= 'editor=' otherlv_44= '{' ( (lv_editor_45_0= RULE_STRING ) ) otherlv_46= '}' )? | (otherlv_47= 'organization=' otherlv_48= '{' ( (lv_organization_49_0= RULE_STRING ) ) otherlv_50= '}' )? | (otherlv_51= 'note=' otherlv_52= '{' otherlv_53= 'Cited' otherlv_54= 'by:' ( (lv_citationscount_55_0= RULE_INT ) ) otherlv_56= '}' )? )";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000074000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000034000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000018000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000030000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0001880800000020L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000110000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x000007F000000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x00000001FFE98000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000300000000002L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000200000000002L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000400000008000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0002000000000000L});

}