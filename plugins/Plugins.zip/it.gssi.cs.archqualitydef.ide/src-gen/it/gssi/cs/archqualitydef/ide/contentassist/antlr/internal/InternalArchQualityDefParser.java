package it.gssi.cs.archqualitydef.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import it.gssi.cs.archqualitydef.services.ArchQualityDefGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalArchQualityDefParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'article'", "'book'", "'inbook'", "'booklet'", "'misc'", "'incollection'", "'inproceedings'", "'QualityModel'", "'{'", "'}'", "';'", "'bibtex'", "','", "'qualitydef'", "'lastupdate'", "'author='", "'and'", "'title='", "'year='", "'pages='", "'address='", "'booktitle='", "'journal='", "'chapter='", "'series='", "'volume='", "'editor='", "'organization='", "'note='", "'Cited'", "'by:'", "'@'", "'Metric'", "'description:'", "'['", "']'", "'QualityAttribute'", "'QualityCharacteristic'", "'->'"
    };
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int RULE_ID=4;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalArchQualityDefParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalArchQualityDefParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalArchQualityDefParser.tokenNames; }
    public String getGrammarFileName() { return "InternalArchQualityDef.g"; }


    	private ArchQualityDefGrammarAccess grammarAccess;

    	public void setGrammarAccess(ArchQualityDefGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleArchQualityModel"
    // InternalArchQualityDef.g:53:1: entryRuleArchQualityModel : ruleArchQualityModel EOF ;
    public final void entryRuleArchQualityModel() throws RecognitionException {
        try {
            // InternalArchQualityDef.g:54:1: ( ruleArchQualityModel EOF )
            // InternalArchQualityDef.g:55:1: ruleArchQualityModel EOF
            {
             before(grammarAccess.getArchQualityModelRule()); 
            pushFollow(FOLLOW_1);
            ruleArchQualityModel();

            state._fsp--;

             after(grammarAccess.getArchQualityModelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleArchQualityModel"


    // $ANTLR start "ruleArchQualityModel"
    // InternalArchQualityDef.g:62:1: ruleArchQualityModel : ( ( rule__ArchQualityModel__Group__0 ) ) ;
    public final void ruleArchQualityModel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:66:2: ( ( ( rule__ArchQualityModel__Group__0 ) ) )
            // InternalArchQualityDef.g:67:2: ( ( rule__ArchQualityModel__Group__0 ) )
            {
            // InternalArchQualityDef.g:67:2: ( ( rule__ArchQualityModel__Group__0 ) )
            // InternalArchQualityDef.g:68:3: ( rule__ArchQualityModel__Group__0 )
            {
             before(grammarAccess.getArchQualityModelAccess().getGroup()); 
            // InternalArchQualityDef.g:69:3: ( rule__ArchQualityModel__Group__0 )
            // InternalArchQualityDef.g:69:4: rule__ArchQualityModel__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getArchQualityModelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleArchQualityModel"


    // $ANTLR start "entryRuleQualityElement"
    // InternalArchQualityDef.g:78:1: entryRuleQualityElement : ruleQualityElement EOF ;
    public final void entryRuleQualityElement() throws RecognitionException {
        try {
            // InternalArchQualityDef.g:79:1: ( ruleQualityElement EOF )
            // InternalArchQualityDef.g:80:1: ruleQualityElement EOF
            {
             before(grammarAccess.getQualityElementRule()); 
            pushFollow(FOLLOW_1);
            ruleQualityElement();

            state._fsp--;

             after(grammarAccess.getQualityElementRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleQualityElement"


    // $ANTLR start "ruleQualityElement"
    // InternalArchQualityDef.g:87:1: ruleQualityElement : ( ( rule__QualityElement__Alternatives ) ) ;
    public final void ruleQualityElement() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:91:2: ( ( ( rule__QualityElement__Alternatives ) ) )
            // InternalArchQualityDef.g:92:2: ( ( rule__QualityElement__Alternatives ) )
            {
            // InternalArchQualityDef.g:92:2: ( ( rule__QualityElement__Alternatives ) )
            // InternalArchQualityDef.g:93:3: ( rule__QualityElement__Alternatives )
            {
             before(grammarAccess.getQualityElementAccess().getAlternatives()); 
            // InternalArchQualityDef.g:94:3: ( rule__QualityElement__Alternatives )
            // InternalArchQualityDef.g:94:4: rule__QualityElement__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__QualityElement__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getQualityElementAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleQualityElement"


    // $ANTLR start "entryRuleEDate"
    // InternalArchQualityDef.g:103:1: entryRuleEDate : ruleEDate EOF ;
    public final void entryRuleEDate() throws RecognitionException {
        try {
            // InternalArchQualityDef.g:104:1: ( ruleEDate EOF )
            // InternalArchQualityDef.g:105:1: ruleEDate EOF
            {
             before(grammarAccess.getEDateRule()); 
            pushFollow(FOLLOW_1);
            ruleEDate();

            state._fsp--;

             after(grammarAccess.getEDateRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEDate"


    // $ANTLR start "ruleEDate"
    // InternalArchQualityDef.g:112:1: ruleEDate : ( ( rule__EDate__Group__0 ) ) ;
    public final void ruleEDate() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:116:2: ( ( ( rule__EDate__Group__0 ) ) )
            // InternalArchQualityDef.g:117:2: ( ( rule__EDate__Group__0 ) )
            {
            // InternalArchQualityDef.g:117:2: ( ( rule__EDate__Group__0 ) )
            // InternalArchQualityDef.g:118:3: ( rule__EDate__Group__0 )
            {
             before(grammarAccess.getEDateAccess().getGroup()); 
            // InternalArchQualityDef.g:119:3: ( rule__EDate__Group__0 )
            // InternalArchQualityDef.g:119:4: rule__EDate__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__EDate__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEDateAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEDate"


    // $ANTLR start "entryRuleAuthor"
    // InternalArchQualityDef.g:128:1: entryRuleAuthor : ruleAuthor EOF ;
    public final void entryRuleAuthor() throws RecognitionException {
        try {
            // InternalArchQualityDef.g:129:1: ( ruleAuthor EOF )
            // InternalArchQualityDef.g:130:1: ruleAuthor EOF
            {
             before(grammarAccess.getAuthorRule()); 
            pushFollow(FOLLOW_1);
            ruleAuthor();

            state._fsp--;

             after(grammarAccess.getAuthorRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAuthor"


    // $ANTLR start "ruleAuthor"
    // InternalArchQualityDef.g:137:1: ruleAuthor : ( ( rule__Author__NameAssignment ) ) ;
    public final void ruleAuthor() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:141:2: ( ( ( rule__Author__NameAssignment ) ) )
            // InternalArchQualityDef.g:142:2: ( ( rule__Author__NameAssignment ) )
            {
            // InternalArchQualityDef.g:142:2: ( ( rule__Author__NameAssignment ) )
            // InternalArchQualityDef.g:143:3: ( rule__Author__NameAssignment )
            {
             before(grammarAccess.getAuthorAccess().getNameAssignment()); 
            // InternalArchQualityDef.g:144:3: ( rule__Author__NameAssignment )
            // InternalArchQualityDef.g:144:4: rule__Author__NameAssignment
            {
            pushFollow(FOLLOW_2);
            rule__Author__NameAssignment();

            state._fsp--;


            }

             after(grammarAccess.getAuthorAccess().getNameAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAuthor"


    // $ANTLR start "entryRuleField"
    // InternalArchQualityDef.g:153:1: entryRuleField : ruleField EOF ;
    public final void entryRuleField() throws RecognitionException {
        try {
            // InternalArchQualityDef.g:154:1: ( ruleField EOF )
            // InternalArchQualityDef.g:155:1: ruleField EOF
            {
             before(grammarAccess.getFieldRule()); 
            pushFollow(FOLLOW_1);
            ruleField();

            state._fsp--;

             after(grammarAccess.getFieldRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleField"


    // $ANTLR start "ruleField"
    // InternalArchQualityDef.g:162:1: ruleField : ( ( rule__Field__Group__0 ) ) ;
    public final void ruleField() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:166:2: ( ( ( rule__Field__Group__0 ) ) )
            // InternalArchQualityDef.g:167:2: ( ( rule__Field__Group__0 ) )
            {
            // InternalArchQualityDef.g:167:2: ( ( rule__Field__Group__0 ) )
            // InternalArchQualityDef.g:168:3: ( rule__Field__Group__0 )
            {
             before(grammarAccess.getFieldAccess().getGroup()); 
            // InternalArchQualityDef.g:169:3: ( rule__Field__Group__0 )
            // InternalArchQualityDef.g:169:4: rule__Field__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Field__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleField"


    // $ANTLR start "entryRuleResearchContribution"
    // InternalArchQualityDef.g:178:1: entryRuleResearchContribution : ruleResearchContribution EOF ;
    public final void entryRuleResearchContribution() throws RecognitionException {
        try {
            // InternalArchQualityDef.g:179:1: ( ruleResearchContribution EOF )
            // InternalArchQualityDef.g:180:1: ruleResearchContribution EOF
            {
             before(grammarAccess.getResearchContributionRule()); 
            pushFollow(FOLLOW_1);
            ruleResearchContribution();

            state._fsp--;

             after(grammarAccess.getResearchContributionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleResearchContribution"


    // $ANTLR start "ruleResearchContribution"
    // InternalArchQualityDef.g:187:1: ruleResearchContribution : ( ( rule__ResearchContribution__Group__0 ) ) ;
    public final void ruleResearchContribution() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:191:2: ( ( ( rule__ResearchContribution__Group__0 ) ) )
            // InternalArchQualityDef.g:192:2: ( ( rule__ResearchContribution__Group__0 ) )
            {
            // InternalArchQualityDef.g:192:2: ( ( rule__ResearchContribution__Group__0 ) )
            // InternalArchQualityDef.g:193:3: ( rule__ResearchContribution__Group__0 )
            {
             before(grammarAccess.getResearchContributionAccess().getGroup()); 
            // InternalArchQualityDef.g:194:3: ( rule__ResearchContribution__Group__0 )
            // InternalArchQualityDef.g:194:4: rule__ResearchContribution__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ResearchContribution__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getResearchContributionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleResearchContribution"


    // $ANTLR start "entryRuleMetric"
    // InternalArchQualityDef.g:203:1: entryRuleMetric : ruleMetric EOF ;
    public final void entryRuleMetric() throws RecognitionException {
        try {
            // InternalArchQualityDef.g:204:1: ( ruleMetric EOF )
            // InternalArchQualityDef.g:205:1: ruleMetric EOF
            {
             before(grammarAccess.getMetricRule()); 
            pushFollow(FOLLOW_1);
            ruleMetric();

            state._fsp--;

             after(grammarAccess.getMetricRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMetric"


    // $ANTLR start "ruleMetric"
    // InternalArchQualityDef.g:212:1: ruleMetric : ( ( rule__Metric__Group__0 ) ) ;
    public final void ruleMetric() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:216:2: ( ( ( rule__Metric__Group__0 ) ) )
            // InternalArchQualityDef.g:217:2: ( ( rule__Metric__Group__0 ) )
            {
            // InternalArchQualityDef.g:217:2: ( ( rule__Metric__Group__0 ) )
            // InternalArchQualityDef.g:218:3: ( rule__Metric__Group__0 )
            {
             before(grammarAccess.getMetricAccess().getGroup()); 
            // InternalArchQualityDef.g:219:3: ( rule__Metric__Group__0 )
            // InternalArchQualityDef.g:219:4: rule__Metric__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Metric__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getMetricAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMetric"


    // $ANTLR start "entryRuleQualityAttribute"
    // InternalArchQualityDef.g:228:1: entryRuleQualityAttribute : ruleQualityAttribute EOF ;
    public final void entryRuleQualityAttribute() throws RecognitionException {
        try {
            // InternalArchQualityDef.g:229:1: ( ruleQualityAttribute EOF )
            // InternalArchQualityDef.g:230:1: ruleQualityAttribute EOF
            {
             before(grammarAccess.getQualityAttributeRule()); 
            pushFollow(FOLLOW_1);
            ruleQualityAttribute();

            state._fsp--;

             after(grammarAccess.getQualityAttributeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleQualityAttribute"


    // $ANTLR start "ruleQualityAttribute"
    // InternalArchQualityDef.g:237:1: ruleQualityAttribute : ( ( rule__QualityAttribute__Group__0 ) ) ;
    public final void ruleQualityAttribute() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:241:2: ( ( ( rule__QualityAttribute__Group__0 ) ) )
            // InternalArchQualityDef.g:242:2: ( ( rule__QualityAttribute__Group__0 ) )
            {
            // InternalArchQualityDef.g:242:2: ( ( rule__QualityAttribute__Group__0 ) )
            // InternalArchQualityDef.g:243:3: ( rule__QualityAttribute__Group__0 )
            {
             before(grammarAccess.getQualityAttributeAccess().getGroup()); 
            // InternalArchQualityDef.g:244:3: ( rule__QualityAttribute__Group__0 )
            // InternalArchQualityDef.g:244:4: rule__QualityAttribute__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__QualityAttribute__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getQualityAttributeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleQualityAttribute"


    // $ANTLR start "entryRuleQualityCharacteristic"
    // InternalArchQualityDef.g:253:1: entryRuleQualityCharacteristic : ruleQualityCharacteristic EOF ;
    public final void entryRuleQualityCharacteristic() throws RecognitionException {
        try {
            // InternalArchQualityDef.g:254:1: ( ruleQualityCharacteristic EOF )
            // InternalArchQualityDef.g:255:1: ruleQualityCharacteristic EOF
            {
             before(grammarAccess.getQualityCharacteristicRule()); 
            pushFollow(FOLLOW_1);
            ruleQualityCharacteristic();

            state._fsp--;

             after(grammarAccess.getQualityCharacteristicRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleQualityCharacteristic"


    // $ANTLR start "ruleQualityCharacteristic"
    // InternalArchQualityDef.g:262:1: ruleQualityCharacteristic : ( ( rule__QualityCharacteristic__Group__0 ) ) ;
    public final void ruleQualityCharacteristic() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:266:2: ( ( ( rule__QualityCharacteristic__Group__0 ) ) )
            // InternalArchQualityDef.g:267:2: ( ( rule__QualityCharacteristic__Group__0 ) )
            {
            // InternalArchQualityDef.g:267:2: ( ( rule__QualityCharacteristic__Group__0 ) )
            // InternalArchQualityDef.g:268:3: ( rule__QualityCharacteristic__Group__0 )
            {
             before(grammarAccess.getQualityCharacteristicAccess().getGroup()); 
            // InternalArchQualityDef.g:269:3: ( rule__QualityCharacteristic__Group__0 )
            // InternalArchQualityDef.g:269:4: rule__QualityCharacteristic__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__QualityCharacteristic__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getQualityCharacteristicAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleQualityCharacteristic"


    // $ANTLR start "entryRuleQualityRel"
    // InternalArchQualityDef.g:278:1: entryRuleQualityRel : ruleQualityRel EOF ;
    public final void entryRuleQualityRel() throws RecognitionException {
        try {
            // InternalArchQualityDef.g:279:1: ( ruleQualityRel EOF )
            // InternalArchQualityDef.g:280:1: ruleQualityRel EOF
            {
             before(grammarAccess.getQualityRelRule()); 
            pushFollow(FOLLOW_1);
            ruleQualityRel();

            state._fsp--;

             after(grammarAccess.getQualityRelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleQualityRel"


    // $ANTLR start "ruleQualityRel"
    // InternalArchQualityDef.g:287:1: ruleQualityRel : ( ( rule__QualityRel__Group__0 ) ) ;
    public final void ruleQualityRel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:291:2: ( ( ( rule__QualityRel__Group__0 ) ) )
            // InternalArchQualityDef.g:292:2: ( ( rule__QualityRel__Group__0 ) )
            {
            // InternalArchQualityDef.g:292:2: ( ( rule__QualityRel__Group__0 ) )
            // InternalArchQualityDef.g:293:3: ( rule__QualityRel__Group__0 )
            {
             before(grammarAccess.getQualityRelAccess().getGroup()); 
            // InternalArchQualityDef.g:294:3: ( rule__QualityRel__Group__0 )
            // InternalArchQualityDef.g:294:4: rule__QualityRel__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__QualityRel__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getQualityRelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleQualityRel"


    // $ANTLR start "rule__QualityElement__Alternatives"
    // InternalArchQualityDef.g:302:1: rule__QualityElement__Alternatives : ( ( ruleMetric ) | ( ruleQualityAttribute ) | ( ruleQualityCharacteristic ) | ( ruleResearchContribution ) | ( ruleQualityRel ) );
    public final void rule__QualityElement__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:306:1: ( ( ruleMetric ) | ( ruleQualityAttribute ) | ( ruleQualityCharacteristic ) | ( ruleResearchContribution ) | ( ruleQualityRel ) )
            int alt1=5;
            switch ( input.LA(1) ) {
            case 43:
                {
                alt1=1;
                }
                break;
            case 47:
                {
                alt1=2;
                }
                break;
            case 48:
                {
                alt1=3;
                }
                break;
            case 42:
                {
                alt1=4;
                }
                break;
            case RULE_ID:
                {
                alt1=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }

            switch (alt1) {
                case 1 :
                    // InternalArchQualityDef.g:307:2: ( ruleMetric )
                    {
                    // InternalArchQualityDef.g:307:2: ( ruleMetric )
                    // InternalArchQualityDef.g:308:3: ruleMetric
                    {
                     before(grammarAccess.getQualityElementAccess().getMetricParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleMetric();

                    state._fsp--;

                     after(grammarAccess.getQualityElementAccess().getMetricParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalArchQualityDef.g:313:2: ( ruleQualityAttribute )
                    {
                    // InternalArchQualityDef.g:313:2: ( ruleQualityAttribute )
                    // InternalArchQualityDef.g:314:3: ruleQualityAttribute
                    {
                     before(grammarAccess.getQualityElementAccess().getQualityAttributeParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleQualityAttribute();

                    state._fsp--;

                     after(grammarAccess.getQualityElementAccess().getQualityAttributeParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalArchQualityDef.g:319:2: ( ruleQualityCharacteristic )
                    {
                    // InternalArchQualityDef.g:319:2: ( ruleQualityCharacteristic )
                    // InternalArchQualityDef.g:320:3: ruleQualityCharacteristic
                    {
                     before(grammarAccess.getQualityElementAccess().getQualityCharacteristicParserRuleCall_2()); 
                    pushFollow(FOLLOW_2);
                    ruleQualityCharacteristic();

                    state._fsp--;

                     after(grammarAccess.getQualityElementAccess().getQualityCharacteristicParserRuleCall_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalArchQualityDef.g:325:2: ( ruleResearchContribution )
                    {
                    // InternalArchQualityDef.g:325:2: ( ruleResearchContribution )
                    // InternalArchQualityDef.g:326:3: ruleResearchContribution
                    {
                     before(grammarAccess.getQualityElementAccess().getResearchContributionParserRuleCall_3()); 
                    pushFollow(FOLLOW_2);
                    ruleResearchContribution();

                    state._fsp--;

                     after(grammarAccess.getQualityElementAccess().getResearchContributionParserRuleCall_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalArchQualityDef.g:331:2: ( ruleQualityRel )
                    {
                    // InternalArchQualityDef.g:331:2: ( ruleQualityRel )
                    // InternalArchQualityDef.g:332:3: ruleQualityRel
                    {
                     before(grammarAccess.getQualityElementAccess().getQualityRelParserRuleCall_4()); 
                    pushFollow(FOLLOW_2);
                    ruleQualityRel();

                    state._fsp--;

                     after(grammarAccess.getQualityElementAccess().getQualityRelParserRuleCall_4()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityElement__Alternatives"


    // $ANTLR start "rule__Author__NameAlternatives_0"
    // InternalArchQualityDef.g:341:1: rule__Author__NameAlternatives_0 : ( ( RULE_ID ) | ( RULE_STRING ) );
    public final void rule__Author__NameAlternatives_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:345:1: ( ( RULE_ID ) | ( RULE_STRING ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==RULE_ID) ) {
                alt2=1;
            }
            else if ( (LA2_0==RULE_STRING) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalArchQualityDef.g:346:2: ( RULE_ID )
                    {
                    // InternalArchQualityDef.g:346:2: ( RULE_ID )
                    // InternalArchQualityDef.g:347:3: RULE_ID
                    {
                     before(grammarAccess.getAuthorAccess().getNameIDTerminalRuleCall_0_0()); 
                    match(input,RULE_ID,FOLLOW_2); 
                     after(grammarAccess.getAuthorAccess().getNameIDTerminalRuleCall_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalArchQualityDef.g:352:2: ( RULE_STRING )
                    {
                    // InternalArchQualityDef.g:352:2: ( RULE_STRING )
                    // InternalArchQualityDef.g:353:3: RULE_STRING
                    {
                     before(grammarAccess.getAuthorAccess().getNameSTRINGTerminalRuleCall_0_1()); 
                    match(input,RULE_STRING,FOLLOW_2); 
                     after(grammarAccess.getAuthorAccess().getNameSTRINGTerminalRuleCall_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Author__NameAlternatives_0"


    // $ANTLR start "rule__Field__Alternatives_1"
    // InternalArchQualityDef.g:362:1: rule__Field__Alternatives_1 : ( ( ( rule__Field__Group_1_0__0 ) ) | ( ( rule__Field__Group_1_1__0 ) ) | ( ( rule__Field__Group_1_2__0 ) ) | ( ( rule__Field__Group_1_3__0 )? ) | ( ( rule__Field__Group_1_4__0 )? ) | ( ( rule__Field__Group_1_5__0 )? ) | ( ( rule__Field__Group_1_6__0 )? ) | ( ( rule__Field__Group_1_7__0 )? ) | ( ( rule__Field__Group_1_8__0 )? ) | ( ( rule__Field__Group_1_9__0 )? ) | ( ( rule__Field__Group_1_10__0 )? ) | ( ( rule__Field__Group_1_11__0 )? ) | ( ( rule__Field__Group_1_12__0 )? ) );
    public final void rule__Field__Alternatives_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:366:1: ( ( ( rule__Field__Group_1_0__0 ) ) | ( ( rule__Field__Group_1_1__0 ) ) | ( ( rule__Field__Group_1_2__0 ) ) | ( ( rule__Field__Group_1_3__0 )? ) | ( ( rule__Field__Group_1_4__0 )? ) | ( ( rule__Field__Group_1_5__0 )? ) | ( ( rule__Field__Group_1_6__0 )? ) | ( ( rule__Field__Group_1_7__0 )? ) | ( ( rule__Field__Group_1_8__0 )? ) | ( ( rule__Field__Group_1_9__0 )? ) | ( ( rule__Field__Group_1_10__0 )? ) | ( ( rule__Field__Group_1_11__0 )? ) | ( ( rule__Field__Group_1_12__0 )? ) )
            int alt13=13;
            alt13 = dfa13.predict(input);
            switch (alt13) {
                case 1 :
                    // InternalArchQualityDef.g:367:2: ( ( rule__Field__Group_1_0__0 ) )
                    {
                    // InternalArchQualityDef.g:367:2: ( ( rule__Field__Group_1_0__0 ) )
                    // InternalArchQualityDef.g:368:3: ( rule__Field__Group_1_0__0 )
                    {
                     before(grammarAccess.getFieldAccess().getGroup_1_0()); 
                    // InternalArchQualityDef.g:369:3: ( rule__Field__Group_1_0__0 )
                    // InternalArchQualityDef.g:369:4: rule__Field__Group_1_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Field__Group_1_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getFieldAccess().getGroup_1_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalArchQualityDef.g:373:2: ( ( rule__Field__Group_1_1__0 ) )
                    {
                    // InternalArchQualityDef.g:373:2: ( ( rule__Field__Group_1_1__0 ) )
                    // InternalArchQualityDef.g:374:3: ( rule__Field__Group_1_1__0 )
                    {
                     before(grammarAccess.getFieldAccess().getGroup_1_1()); 
                    // InternalArchQualityDef.g:375:3: ( rule__Field__Group_1_1__0 )
                    // InternalArchQualityDef.g:375:4: rule__Field__Group_1_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Field__Group_1_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getFieldAccess().getGroup_1_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalArchQualityDef.g:379:2: ( ( rule__Field__Group_1_2__0 ) )
                    {
                    // InternalArchQualityDef.g:379:2: ( ( rule__Field__Group_1_2__0 ) )
                    // InternalArchQualityDef.g:380:3: ( rule__Field__Group_1_2__0 )
                    {
                     before(grammarAccess.getFieldAccess().getGroup_1_2()); 
                    // InternalArchQualityDef.g:381:3: ( rule__Field__Group_1_2__0 )
                    // InternalArchQualityDef.g:381:4: rule__Field__Group_1_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Field__Group_1_2__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getFieldAccess().getGroup_1_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalArchQualityDef.g:385:2: ( ( rule__Field__Group_1_3__0 )? )
                    {
                    // InternalArchQualityDef.g:385:2: ( ( rule__Field__Group_1_3__0 )? )
                    // InternalArchQualityDef.g:386:3: ( rule__Field__Group_1_3__0 )?
                    {
                     before(grammarAccess.getFieldAccess().getGroup_1_3()); 
                    // InternalArchQualityDef.g:387:3: ( rule__Field__Group_1_3__0 )?
                    int alt3=2;
                    int LA3_0 = input.LA(1);

                    if ( (LA3_0==30) ) {
                        alt3=1;
                    }
                    switch (alt3) {
                        case 1 :
                            // InternalArchQualityDef.g:387:4: rule__Field__Group_1_3__0
                            {
                            pushFollow(FOLLOW_2);
                            rule__Field__Group_1_3__0();

                            state._fsp--;


                            }
                            break;

                    }

                     after(grammarAccess.getFieldAccess().getGroup_1_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalArchQualityDef.g:391:2: ( ( rule__Field__Group_1_4__0 )? )
                    {
                    // InternalArchQualityDef.g:391:2: ( ( rule__Field__Group_1_4__0 )? )
                    // InternalArchQualityDef.g:392:3: ( rule__Field__Group_1_4__0 )?
                    {
                     before(grammarAccess.getFieldAccess().getGroup_1_4()); 
                    // InternalArchQualityDef.g:393:3: ( rule__Field__Group_1_4__0 )?
                    int alt4=2;
                    int LA4_0 = input.LA(1);

                    if ( (LA4_0==31) ) {
                        alt4=1;
                    }
                    switch (alt4) {
                        case 1 :
                            // InternalArchQualityDef.g:393:4: rule__Field__Group_1_4__0
                            {
                            pushFollow(FOLLOW_2);
                            rule__Field__Group_1_4__0();

                            state._fsp--;


                            }
                            break;

                    }

                     after(grammarAccess.getFieldAccess().getGroup_1_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalArchQualityDef.g:397:2: ( ( rule__Field__Group_1_5__0 )? )
                    {
                    // InternalArchQualityDef.g:397:2: ( ( rule__Field__Group_1_5__0 )? )
                    // InternalArchQualityDef.g:398:3: ( rule__Field__Group_1_5__0 )?
                    {
                     before(grammarAccess.getFieldAccess().getGroup_1_5()); 
                    // InternalArchQualityDef.g:399:3: ( rule__Field__Group_1_5__0 )?
                    int alt5=2;
                    int LA5_0 = input.LA(1);

                    if ( (LA5_0==32) ) {
                        alt5=1;
                    }
                    switch (alt5) {
                        case 1 :
                            // InternalArchQualityDef.g:399:4: rule__Field__Group_1_5__0
                            {
                            pushFollow(FOLLOW_2);
                            rule__Field__Group_1_5__0();

                            state._fsp--;


                            }
                            break;

                    }

                     after(grammarAccess.getFieldAccess().getGroup_1_5()); 

                    }


                    }
                    break;
                case 7 :
                    // InternalArchQualityDef.g:403:2: ( ( rule__Field__Group_1_6__0 )? )
                    {
                    // InternalArchQualityDef.g:403:2: ( ( rule__Field__Group_1_6__0 )? )
                    // InternalArchQualityDef.g:404:3: ( rule__Field__Group_1_6__0 )?
                    {
                     before(grammarAccess.getFieldAccess().getGroup_1_6()); 
                    // InternalArchQualityDef.g:405:3: ( rule__Field__Group_1_6__0 )?
                    int alt6=2;
                    int LA6_0 = input.LA(1);

                    if ( (LA6_0==33) ) {
                        alt6=1;
                    }
                    switch (alt6) {
                        case 1 :
                            // InternalArchQualityDef.g:405:4: rule__Field__Group_1_6__0
                            {
                            pushFollow(FOLLOW_2);
                            rule__Field__Group_1_6__0();

                            state._fsp--;


                            }
                            break;

                    }

                     after(grammarAccess.getFieldAccess().getGroup_1_6()); 

                    }


                    }
                    break;
                case 8 :
                    // InternalArchQualityDef.g:409:2: ( ( rule__Field__Group_1_7__0 )? )
                    {
                    // InternalArchQualityDef.g:409:2: ( ( rule__Field__Group_1_7__0 )? )
                    // InternalArchQualityDef.g:410:3: ( rule__Field__Group_1_7__0 )?
                    {
                     before(grammarAccess.getFieldAccess().getGroup_1_7()); 
                    // InternalArchQualityDef.g:411:3: ( rule__Field__Group_1_7__0 )?
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0==34) ) {
                        alt7=1;
                    }
                    switch (alt7) {
                        case 1 :
                            // InternalArchQualityDef.g:411:4: rule__Field__Group_1_7__0
                            {
                            pushFollow(FOLLOW_2);
                            rule__Field__Group_1_7__0();

                            state._fsp--;


                            }
                            break;

                    }

                     after(grammarAccess.getFieldAccess().getGroup_1_7()); 

                    }


                    }
                    break;
                case 9 :
                    // InternalArchQualityDef.g:415:2: ( ( rule__Field__Group_1_8__0 )? )
                    {
                    // InternalArchQualityDef.g:415:2: ( ( rule__Field__Group_1_8__0 )? )
                    // InternalArchQualityDef.g:416:3: ( rule__Field__Group_1_8__0 )?
                    {
                     before(grammarAccess.getFieldAccess().getGroup_1_8()); 
                    // InternalArchQualityDef.g:417:3: ( rule__Field__Group_1_8__0 )?
                    int alt8=2;
                    int LA8_0 = input.LA(1);

                    if ( (LA8_0==35) ) {
                        alt8=1;
                    }
                    switch (alt8) {
                        case 1 :
                            // InternalArchQualityDef.g:417:4: rule__Field__Group_1_8__0
                            {
                            pushFollow(FOLLOW_2);
                            rule__Field__Group_1_8__0();

                            state._fsp--;


                            }
                            break;

                    }

                     after(grammarAccess.getFieldAccess().getGroup_1_8()); 

                    }


                    }
                    break;
                case 10 :
                    // InternalArchQualityDef.g:421:2: ( ( rule__Field__Group_1_9__0 )? )
                    {
                    // InternalArchQualityDef.g:421:2: ( ( rule__Field__Group_1_9__0 )? )
                    // InternalArchQualityDef.g:422:3: ( rule__Field__Group_1_9__0 )?
                    {
                     before(grammarAccess.getFieldAccess().getGroup_1_9()); 
                    // InternalArchQualityDef.g:423:3: ( rule__Field__Group_1_9__0 )?
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0==36) ) {
                        alt9=1;
                    }
                    switch (alt9) {
                        case 1 :
                            // InternalArchQualityDef.g:423:4: rule__Field__Group_1_9__0
                            {
                            pushFollow(FOLLOW_2);
                            rule__Field__Group_1_9__0();

                            state._fsp--;


                            }
                            break;

                    }

                     after(grammarAccess.getFieldAccess().getGroup_1_9()); 

                    }


                    }
                    break;
                case 11 :
                    // InternalArchQualityDef.g:427:2: ( ( rule__Field__Group_1_10__0 )? )
                    {
                    // InternalArchQualityDef.g:427:2: ( ( rule__Field__Group_1_10__0 )? )
                    // InternalArchQualityDef.g:428:3: ( rule__Field__Group_1_10__0 )?
                    {
                     before(grammarAccess.getFieldAccess().getGroup_1_10()); 
                    // InternalArchQualityDef.g:429:3: ( rule__Field__Group_1_10__0 )?
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0==37) ) {
                        alt10=1;
                    }
                    switch (alt10) {
                        case 1 :
                            // InternalArchQualityDef.g:429:4: rule__Field__Group_1_10__0
                            {
                            pushFollow(FOLLOW_2);
                            rule__Field__Group_1_10__0();

                            state._fsp--;


                            }
                            break;

                    }

                     after(grammarAccess.getFieldAccess().getGroup_1_10()); 

                    }


                    }
                    break;
                case 12 :
                    // InternalArchQualityDef.g:433:2: ( ( rule__Field__Group_1_11__0 )? )
                    {
                    // InternalArchQualityDef.g:433:2: ( ( rule__Field__Group_1_11__0 )? )
                    // InternalArchQualityDef.g:434:3: ( rule__Field__Group_1_11__0 )?
                    {
                     before(grammarAccess.getFieldAccess().getGroup_1_11()); 
                    // InternalArchQualityDef.g:435:3: ( rule__Field__Group_1_11__0 )?
                    int alt11=2;
                    int LA11_0 = input.LA(1);

                    if ( (LA11_0==38) ) {
                        alt11=1;
                    }
                    switch (alt11) {
                        case 1 :
                            // InternalArchQualityDef.g:435:4: rule__Field__Group_1_11__0
                            {
                            pushFollow(FOLLOW_2);
                            rule__Field__Group_1_11__0();

                            state._fsp--;


                            }
                            break;

                    }

                     after(grammarAccess.getFieldAccess().getGroup_1_11()); 

                    }


                    }
                    break;
                case 13 :
                    // InternalArchQualityDef.g:439:2: ( ( rule__Field__Group_1_12__0 )? )
                    {
                    // InternalArchQualityDef.g:439:2: ( ( rule__Field__Group_1_12__0 )? )
                    // InternalArchQualityDef.g:440:3: ( rule__Field__Group_1_12__0 )?
                    {
                     before(grammarAccess.getFieldAccess().getGroup_1_12()); 
                    // InternalArchQualityDef.g:441:3: ( rule__Field__Group_1_12__0 )?
                    int alt12=2;
                    int LA12_0 = input.LA(1);

                    if ( (LA12_0==39) ) {
                        alt12=1;
                    }
                    switch (alt12) {
                        case 1 :
                            // InternalArchQualityDef.g:441:4: rule__Field__Group_1_12__0
                            {
                            pushFollow(FOLLOW_2);
                            rule__Field__Group_1_12__0();

                            state._fsp--;


                            }
                            break;

                    }

                     after(grammarAccess.getFieldAccess().getGroup_1_12()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Alternatives_1"


    // $ANTLR start "rule__ResearchContribution__Alternatives_2"
    // InternalArchQualityDef.g:449:1: rule__ResearchContribution__Alternatives_2 : ( ( 'article' ) | ( 'book' ) | ( 'inbook' ) | ( 'booklet' ) | ( 'misc' ) | ( 'incollection' ) | ( 'inproceedings' ) );
    public final void rule__ResearchContribution__Alternatives_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:453:1: ( ( 'article' ) | ( 'book' ) | ( 'inbook' ) | ( 'booklet' ) | ( 'misc' ) | ( 'incollection' ) | ( 'inproceedings' ) )
            int alt14=7;
            switch ( input.LA(1) ) {
            case 11:
                {
                alt14=1;
                }
                break;
            case 12:
                {
                alt14=2;
                }
                break;
            case 13:
                {
                alt14=3;
                }
                break;
            case 14:
                {
                alt14=4;
                }
                break;
            case 15:
                {
                alt14=5;
                }
                break;
            case 16:
                {
                alt14=6;
                }
                break;
            case 17:
                {
                alt14=7;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;
            }

            switch (alt14) {
                case 1 :
                    // InternalArchQualityDef.g:454:2: ( 'article' )
                    {
                    // InternalArchQualityDef.g:454:2: ( 'article' )
                    // InternalArchQualityDef.g:455:3: 'article'
                    {
                     before(grammarAccess.getResearchContributionAccess().getArticleKeyword_2_0()); 
                    match(input,11,FOLLOW_2); 
                     after(grammarAccess.getResearchContributionAccess().getArticleKeyword_2_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalArchQualityDef.g:460:2: ( 'book' )
                    {
                    // InternalArchQualityDef.g:460:2: ( 'book' )
                    // InternalArchQualityDef.g:461:3: 'book'
                    {
                     before(grammarAccess.getResearchContributionAccess().getBookKeyword_2_1()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getResearchContributionAccess().getBookKeyword_2_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalArchQualityDef.g:466:2: ( 'inbook' )
                    {
                    // InternalArchQualityDef.g:466:2: ( 'inbook' )
                    // InternalArchQualityDef.g:467:3: 'inbook'
                    {
                     before(grammarAccess.getResearchContributionAccess().getInbookKeyword_2_2()); 
                    match(input,13,FOLLOW_2); 
                     after(grammarAccess.getResearchContributionAccess().getInbookKeyword_2_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalArchQualityDef.g:472:2: ( 'booklet' )
                    {
                    // InternalArchQualityDef.g:472:2: ( 'booklet' )
                    // InternalArchQualityDef.g:473:3: 'booklet'
                    {
                     before(grammarAccess.getResearchContributionAccess().getBookletKeyword_2_3()); 
                    match(input,14,FOLLOW_2); 
                     after(grammarAccess.getResearchContributionAccess().getBookletKeyword_2_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalArchQualityDef.g:478:2: ( 'misc' )
                    {
                    // InternalArchQualityDef.g:478:2: ( 'misc' )
                    // InternalArchQualityDef.g:479:3: 'misc'
                    {
                     before(grammarAccess.getResearchContributionAccess().getMiscKeyword_2_4()); 
                    match(input,15,FOLLOW_2); 
                     after(grammarAccess.getResearchContributionAccess().getMiscKeyword_2_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalArchQualityDef.g:484:2: ( 'incollection' )
                    {
                    // InternalArchQualityDef.g:484:2: ( 'incollection' )
                    // InternalArchQualityDef.g:485:3: 'incollection'
                    {
                     before(grammarAccess.getResearchContributionAccess().getIncollectionKeyword_2_5()); 
                    match(input,16,FOLLOW_2); 
                     after(grammarAccess.getResearchContributionAccess().getIncollectionKeyword_2_5()); 

                    }


                    }
                    break;
                case 7 :
                    // InternalArchQualityDef.g:490:2: ( 'inproceedings' )
                    {
                    // InternalArchQualityDef.g:490:2: ( 'inproceedings' )
                    // InternalArchQualityDef.g:491:3: 'inproceedings'
                    {
                     before(grammarAccess.getResearchContributionAccess().getInproceedingsKeyword_2_6()); 
                    match(input,17,FOLLOW_2); 
                     after(grammarAccess.getResearchContributionAccess().getInproceedingsKeyword_2_6()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Alternatives_2"


    // $ANTLR start "rule__ArchQualityModel__Group__0"
    // InternalArchQualityDef.g:500:1: rule__ArchQualityModel__Group__0 : rule__ArchQualityModel__Group__0__Impl rule__ArchQualityModel__Group__1 ;
    public final void rule__ArchQualityModel__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:504:1: ( rule__ArchQualityModel__Group__0__Impl rule__ArchQualityModel__Group__1 )
            // InternalArchQualityDef.g:505:2: rule__ArchQualityModel__Group__0__Impl rule__ArchQualityModel__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__ArchQualityModel__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group__0"


    // $ANTLR start "rule__ArchQualityModel__Group__0__Impl"
    // InternalArchQualityDef.g:512:1: rule__ArchQualityModel__Group__0__Impl : ( () ) ;
    public final void rule__ArchQualityModel__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:516:1: ( ( () ) )
            // InternalArchQualityDef.g:517:1: ( () )
            {
            // InternalArchQualityDef.g:517:1: ( () )
            // InternalArchQualityDef.g:518:2: ()
            {
             before(grammarAccess.getArchQualityModelAccess().getArchQualityModelAction_0()); 
            // InternalArchQualityDef.g:519:2: ()
            // InternalArchQualityDef.g:519:3: 
            {
            }

             after(grammarAccess.getArchQualityModelAccess().getArchQualityModelAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group__0__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group__1"
    // InternalArchQualityDef.g:527:1: rule__ArchQualityModel__Group__1 : rule__ArchQualityModel__Group__1__Impl rule__ArchQualityModel__Group__2 ;
    public final void rule__ArchQualityModel__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:531:1: ( rule__ArchQualityModel__Group__1__Impl rule__ArchQualityModel__Group__2 )
            // InternalArchQualityDef.g:532:2: rule__ArchQualityModel__Group__1__Impl rule__ArchQualityModel__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__ArchQualityModel__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group__1"


    // $ANTLR start "rule__ArchQualityModel__Group__1__Impl"
    // InternalArchQualityDef.g:539:1: rule__ArchQualityModel__Group__1__Impl : ( 'QualityModel' ) ;
    public final void rule__ArchQualityModel__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:543:1: ( ( 'QualityModel' ) )
            // InternalArchQualityDef.g:544:1: ( 'QualityModel' )
            {
            // InternalArchQualityDef.g:544:1: ( 'QualityModel' )
            // InternalArchQualityDef.g:545:2: 'QualityModel'
            {
             before(grammarAccess.getArchQualityModelAccess().getQualityModelKeyword_1()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getArchQualityModelAccess().getQualityModelKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group__1__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group__2"
    // InternalArchQualityDef.g:554:1: rule__ArchQualityModel__Group__2 : rule__ArchQualityModel__Group__2__Impl rule__ArchQualityModel__Group__3 ;
    public final void rule__ArchQualityModel__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:558:1: ( rule__ArchQualityModel__Group__2__Impl rule__ArchQualityModel__Group__3 )
            // InternalArchQualityDef.g:559:2: rule__ArchQualityModel__Group__2__Impl rule__ArchQualityModel__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__ArchQualityModel__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group__2"


    // $ANTLR start "rule__ArchQualityModel__Group__2__Impl"
    // InternalArchQualityDef.g:566:1: rule__ArchQualityModel__Group__2__Impl : ( '{' ) ;
    public final void rule__ArchQualityModel__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:570:1: ( ( '{' ) )
            // InternalArchQualityDef.g:571:1: ( '{' )
            {
            // InternalArchQualityDef.g:571:1: ( '{' )
            // InternalArchQualityDef.g:572:2: '{'
            {
             before(grammarAccess.getArchQualityModelAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getArchQualityModelAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group__2__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group__3"
    // InternalArchQualityDef.g:581:1: rule__ArchQualityModel__Group__3 : rule__ArchQualityModel__Group__3__Impl rule__ArchQualityModel__Group__4 ;
    public final void rule__ArchQualityModel__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:585:1: ( rule__ArchQualityModel__Group__3__Impl rule__ArchQualityModel__Group__4 )
            // InternalArchQualityDef.g:586:2: rule__ArchQualityModel__Group__3__Impl rule__ArchQualityModel__Group__4
            {
            pushFollow(FOLLOW_5);
            rule__ArchQualityModel__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group__3"


    // $ANTLR start "rule__ArchQualityModel__Group__3__Impl"
    // InternalArchQualityDef.g:593:1: rule__ArchQualityModel__Group__3__Impl : ( ( rule__ArchQualityModel__Group_3__0 )? ) ;
    public final void rule__ArchQualityModel__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:597:1: ( ( ( rule__ArchQualityModel__Group_3__0 )? ) )
            // InternalArchQualityDef.g:598:1: ( ( rule__ArchQualityModel__Group_3__0 )? )
            {
            // InternalArchQualityDef.g:598:1: ( ( rule__ArchQualityModel__Group_3__0 )? )
            // InternalArchQualityDef.g:599:2: ( rule__ArchQualityModel__Group_3__0 )?
            {
             before(grammarAccess.getArchQualityModelAccess().getGroup_3()); 
            // InternalArchQualityDef.g:600:2: ( rule__ArchQualityModel__Group_3__0 )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==25) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalArchQualityDef.g:600:3: rule__ArchQualityModel__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArchQualityModel__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getArchQualityModelAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group__3__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group__4"
    // InternalArchQualityDef.g:608:1: rule__ArchQualityModel__Group__4 : rule__ArchQualityModel__Group__4__Impl rule__ArchQualityModel__Group__5 ;
    public final void rule__ArchQualityModel__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:612:1: ( rule__ArchQualityModel__Group__4__Impl rule__ArchQualityModel__Group__5 )
            // InternalArchQualityDef.g:613:2: rule__ArchQualityModel__Group__4__Impl rule__ArchQualityModel__Group__5
            {
            pushFollow(FOLLOW_5);
            rule__ArchQualityModel__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group__4"


    // $ANTLR start "rule__ArchQualityModel__Group__4__Impl"
    // InternalArchQualityDef.g:620:1: rule__ArchQualityModel__Group__4__Impl : ( ( rule__ArchQualityModel__Group_4__0 )? ) ;
    public final void rule__ArchQualityModel__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:624:1: ( ( ( rule__ArchQualityModel__Group_4__0 )? ) )
            // InternalArchQualityDef.g:625:1: ( ( rule__ArchQualityModel__Group_4__0 )? )
            {
            // InternalArchQualityDef.g:625:1: ( ( rule__ArchQualityModel__Group_4__0 )? )
            // InternalArchQualityDef.g:626:2: ( rule__ArchQualityModel__Group_4__0 )?
            {
             before(grammarAccess.getArchQualityModelAccess().getGroup_4()); 
            // InternalArchQualityDef.g:627:2: ( rule__ArchQualityModel__Group_4__0 )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==22) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalArchQualityDef.g:627:3: rule__ArchQualityModel__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArchQualityModel__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getArchQualityModelAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group__4__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group__5"
    // InternalArchQualityDef.g:635:1: rule__ArchQualityModel__Group__5 : rule__ArchQualityModel__Group__5__Impl rule__ArchQualityModel__Group__6 ;
    public final void rule__ArchQualityModel__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:639:1: ( rule__ArchQualityModel__Group__5__Impl rule__ArchQualityModel__Group__6 )
            // InternalArchQualityDef.g:640:2: rule__ArchQualityModel__Group__5__Impl rule__ArchQualityModel__Group__6
            {
            pushFollow(FOLLOW_5);
            rule__ArchQualityModel__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group__5"


    // $ANTLR start "rule__ArchQualityModel__Group__5__Impl"
    // InternalArchQualityDef.g:647:1: rule__ArchQualityModel__Group__5__Impl : ( ( rule__ArchQualityModel__Group_5__0 )? ) ;
    public final void rule__ArchQualityModel__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:651:1: ( ( ( rule__ArchQualityModel__Group_5__0 )? ) )
            // InternalArchQualityDef.g:652:1: ( ( rule__ArchQualityModel__Group_5__0 )? )
            {
            // InternalArchQualityDef.g:652:1: ( ( rule__ArchQualityModel__Group_5__0 )? )
            // InternalArchQualityDef.g:653:2: ( rule__ArchQualityModel__Group_5__0 )?
            {
             before(grammarAccess.getArchQualityModelAccess().getGroup_5()); 
            // InternalArchQualityDef.g:654:2: ( rule__ArchQualityModel__Group_5__0 )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==24) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalArchQualityDef.g:654:3: rule__ArchQualityModel__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArchQualityModel__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getArchQualityModelAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group__5__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group__6"
    // InternalArchQualityDef.g:662:1: rule__ArchQualityModel__Group__6 : rule__ArchQualityModel__Group__6__Impl ;
    public final void rule__ArchQualityModel__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:666:1: ( rule__ArchQualityModel__Group__6__Impl )
            // InternalArchQualityDef.g:667:2: rule__ArchQualityModel__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group__6"


    // $ANTLR start "rule__ArchQualityModel__Group__6__Impl"
    // InternalArchQualityDef.g:673:1: rule__ArchQualityModel__Group__6__Impl : ( '}' ) ;
    public final void rule__ArchQualityModel__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:677:1: ( ( '}' ) )
            // InternalArchQualityDef.g:678:1: ( '}' )
            {
            // InternalArchQualityDef.g:678:1: ( '}' )
            // InternalArchQualityDef.g:679:2: '}'
            {
             before(grammarAccess.getArchQualityModelAccess().getRightCurlyBracketKeyword_6()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getArchQualityModelAccess().getRightCurlyBracketKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group__6__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group_3__0"
    // InternalArchQualityDef.g:689:1: rule__ArchQualityModel__Group_3__0 : rule__ArchQualityModel__Group_3__0__Impl rule__ArchQualityModel__Group_3__1 ;
    public final void rule__ArchQualityModel__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:693:1: ( rule__ArchQualityModel__Group_3__0__Impl rule__ArchQualityModel__Group_3__1 )
            // InternalArchQualityDef.g:694:2: rule__ArchQualityModel__Group_3__0__Impl rule__ArchQualityModel__Group_3__1
            {
            pushFollow(FOLLOW_6);
            rule__ArchQualityModel__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_3__0"


    // $ANTLR start "rule__ArchQualityModel__Group_3__0__Impl"
    // InternalArchQualityDef.g:701:1: rule__ArchQualityModel__Group_3__0__Impl : ( ( rule__ArchQualityModel__LastupdateAssignment_3_0 ) ) ;
    public final void rule__ArchQualityModel__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:705:1: ( ( ( rule__ArchQualityModel__LastupdateAssignment_3_0 ) ) )
            // InternalArchQualityDef.g:706:1: ( ( rule__ArchQualityModel__LastupdateAssignment_3_0 ) )
            {
            // InternalArchQualityDef.g:706:1: ( ( rule__ArchQualityModel__LastupdateAssignment_3_0 ) )
            // InternalArchQualityDef.g:707:2: ( rule__ArchQualityModel__LastupdateAssignment_3_0 )
            {
             before(grammarAccess.getArchQualityModelAccess().getLastupdateAssignment_3_0()); 
            // InternalArchQualityDef.g:708:2: ( rule__ArchQualityModel__LastupdateAssignment_3_0 )
            // InternalArchQualityDef.g:708:3: rule__ArchQualityModel__LastupdateAssignment_3_0
            {
            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__LastupdateAssignment_3_0();

            state._fsp--;


            }

             after(grammarAccess.getArchQualityModelAccess().getLastupdateAssignment_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_3__0__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group_3__1"
    // InternalArchQualityDef.g:716:1: rule__ArchQualityModel__Group_3__1 : rule__ArchQualityModel__Group_3__1__Impl ;
    public final void rule__ArchQualityModel__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:720:1: ( rule__ArchQualityModel__Group_3__1__Impl )
            // InternalArchQualityDef.g:721:2: rule__ArchQualityModel__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_3__1"


    // $ANTLR start "rule__ArchQualityModel__Group_3__1__Impl"
    // InternalArchQualityDef.g:727:1: rule__ArchQualityModel__Group_3__1__Impl : ( ';' ) ;
    public final void rule__ArchQualityModel__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:731:1: ( ( ';' ) )
            // InternalArchQualityDef.g:732:1: ( ';' )
            {
            // InternalArchQualityDef.g:732:1: ( ';' )
            // InternalArchQualityDef.g:733:2: ';'
            {
             before(grammarAccess.getArchQualityModelAccess().getSemicolonKeyword_3_1()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getArchQualityModelAccess().getSemicolonKeyword_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_3__1__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group_4__0"
    // InternalArchQualityDef.g:743:1: rule__ArchQualityModel__Group_4__0 : rule__ArchQualityModel__Group_4__0__Impl rule__ArchQualityModel__Group_4__1 ;
    public final void rule__ArchQualityModel__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:747:1: ( rule__ArchQualityModel__Group_4__0__Impl rule__ArchQualityModel__Group_4__1 )
            // InternalArchQualityDef.g:748:2: rule__ArchQualityModel__Group_4__0__Impl rule__ArchQualityModel__Group_4__1
            {
            pushFollow(FOLLOW_4);
            rule__ArchQualityModel__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_4__0"


    // $ANTLR start "rule__ArchQualityModel__Group_4__0__Impl"
    // InternalArchQualityDef.g:755:1: rule__ArchQualityModel__Group_4__0__Impl : ( 'bibtex' ) ;
    public final void rule__ArchQualityModel__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:759:1: ( ( 'bibtex' ) )
            // InternalArchQualityDef.g:760:1: ( 'bibtex' )
            {
            // InternalArchQualityDef.g:760:1: ( 'bibtex' )
            // InternalArchQualityDef.g:761:2: 'bibtex'
            {
             before(grammarAccess.getArchQualityModelAccess().getBibtexKeyword_4_0()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getArchQualityModelAccess().getBibtexKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_4__0__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group_4__1"
    // InternalArchQualityDef.g:770:1: rule__ArchQualityModel__Group_4__1 : rule__ArchQualityModel__Group_4__1__Impl rule__ArchQualityModel__Group_4__2 ;
    public final void rule__ArchQualityModel__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:774:1: ( rule__ArchQualityModel__Group_4__1__Impl rule__ArchQualityModel__Group_4__2 )
            // InternalArchQualityDef.g:775:2: rule__ArchQualityModel__Group_4__1__Impl rule__ArchQualityModel__Group_4__2
            {
            pushFollow(FOLLOW_7);
            rule__ArchQualityModel__Group_4__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group_4__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_4__1"


    // $ANTLR start "rule__ArchQualityModel__Group_4__1__Impl"
    // InternalArchQualityDef.g:782:1: rule__ArchQualityModel__Group_4__1__Impl : ( '{' ) ;
    public final void rule__ArchQualityModel__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:786:1: ( ( '{' ) )
            // InternalArchQualityDef.g:787:1: ( '{' )
            {
            // InternalArchQualityDef.g:787:1: ( '{' )
            // InternalArchQualityDef.g:788:2: '{'
            {
             before(grammarAccess.getArchQualityModelAccess().getLeftCurlyBracketKeyword_4_1()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getArchQualityModelAccess().getLeftCurlyBracketKeyword_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_4__1__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group_4__2"
    // InternalArchQualityDef.g:797:1: rule__ArchQualityModel__Group_4__2 : rule__ArchQualityModel__Group_4__2__Impl rule__ArchQualityModel__Group_4__3 ;
    public final void rule__ArchQualityModel__Group_4__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:801:1: ( rule__ArchQualityModel__Group_4__2__Impl rule__ArchQualityModel__Group_4__3 )
            // InternalArchQualityDef.g:802:2: rule__ArchQualityModel__Group_4__2__Impl rule__ArchQualityModel__Group_4__3
            {
            pushFollow(FOLLOW_8);
            rule__ArchQualityModel__Group_4__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group_4__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_4__2"


    // $ANTLR start "rule__ArchQualityModel__Group_4__2__Impl"
    // InternalArchQualityDef.g:809:1: rule__ArchQualityModel__Group_4__2__Impl : ( ( rule__ArchQualityModel__ResearchAssignment_4_2 ) ) ;
    public final void rule__ArchQualityModel__Group_4__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:813:1: ( ( ( rule__ArchQualityModel__ResearchAssignment_4_2 ) ) )
            // InternalArchQualityDef.g:814:1: ( ( rule__ArchQualityModel__ResearchAssignment_4_2 ) )
            {
            // InternalArchQualityDef.g:814:1: ( ( rule__ArchQualityModel__ResearchAssignment_4_2 ) )
            // InternalArchQualityDef.g:815:2: ( rule__ArchQualityModel__ResearchAssignment_4_2 )
            {
             before(grammarAccess.getArchQualityModelAccess().getResearchAssignment_4_2()); 
            // InternalArchQualityDef.g:816:2: ( rule__ArchQualityModel__ResearchAssignment_4_2 )
            // InternalArchQualityDef.g:816:3: rule__ArchQualityModel__ResearchAssignment_4_2
            {
            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__ResearchAssignment_4_2();

            state._fsp--;


            }

             after(grammarAccess.getArchQualityModelAccess().getResearchAssignment_4_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_4__2__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group_4__3"
    // InternalArchQualityDef.g:824:1: rule__ArchQualityModel__Group_4__3 : rule__ArchQualityModel__Group_4__3__Impl rule__ArchQualityModel__Group_4__4 ;
    public final void rule__ArchQualityModel__Group_4__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:828:1: ( rule__ArchQualityModel__Group_4__3__Impl rule__ArchQualityModel__Group_4__4 )
            // InternalArchQualityDef.g:829:2: rule__ArchQualityModel__Group_4__3__Impl rule__ArchQualityModel__Group_4__4
            {
            pushFollow(FOLLOW_8);
            rule__ArchQualityModel__Group_4__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group_4__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_4__3"


    // $ANTLR start "rule__ArchQualityModel__Group_4__3__Impl"
    // InternalArchQualityDef.g:836:1: rule__ArchQualityModel__Group_4__3__Impl : ( ( rule__ArchQualityModel__Group_4_3__0 )* ) ;
    public final void rule__ArchQualityModel__Group_4__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:840:1: ( ( ( rule__ArchQualityModel__Group_4_3__0 )* ) )
            // InternalArchQualityDef.g:841:1: ( ( rule__ArchQualityModel__Group_4_3__0 )* )
            {
            // InternalArchQualityDef.g:841:1: ( ( rule__ArchQualityModel__Group_4_3__0 )* )
            // InternalArchQualityDef.g:842:2: ( rule__ArchQualityModel__Group_4_3__0 )*
            {
             before(grammarAccess.getArchQualityModelAccess().getGroup_4_3()); 
            // InternalArchQualityDef.g:843:2: ( rule__ArchQualityModel__Group_4_3__0 )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( (LA18_0==23) ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // InternalArchQualityDef.g:843:3: rule__ArchQualityModel__Group_4_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__ArchQualityModel__Group_4_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);

             after(grammarAccess.getArchQualityModelAccess().getGroup_4_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_4__3__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group_4__4"
    // InternalArchQualityDef.g:851:1: rule__ArchQualityModel__Group_4__4 : rule__ArchQualityModel__Group_4__4__Impl ;
    public final void rule__ArchQualityModel__Group_4__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:855:1: ( rule__ArchQualityModel__Group_4__4__Impl )
            // InternalArchQualityDef.g:856:2: rule__ArchQualityModel__Group_4__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group_4__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_4__4"


    // $ANTLR start "rule__ArchQualityModel__Group_4__4__Impl"
    // InternalArchQualityDef.g:862:1: rule__ArchQualityModel__Group_4__4__Impl : ( '}' ) ;
    public final void rule__ArchQualityModel__Group_4__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:866:1: ( ( '}' ) )
            // InternalArchQualityDef.g:867:1: ( '}' )
            {
            // InternalArchQualityDef.g:867:1: ( '}' )
            // InternalArchQualityDef.g:868:2: '}'
            {
             before(grammarAccess.getArchQualityModelAccess().getRightCurlyBracketKeyword_4_4()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getArchQualityModelAccess().getRightCurlyBracketKeyword_4_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_4__4__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group_4_3__0"
    // InternalArchQualityDef.g:878:1: rule__ArchQualityModel__Group_4_3__0 : rule__ArchQualityModel__Group_4_3__0__Impl rule__ArchQualityModel__Group_4_3__1 ;
    public final void rule__ArchQualityModel__Group_4_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:882:1: ( rule__ArchQualityModel__Group_4_3__0__Impl rule__ArchQualityModel__Group_4_3__1 )
            // InternalArchQualityDef.g:883:2: rule__ArchQualityModel__Group_4_3__0__Impl rule__ArchQualityModel__Group_4_3__1
            {
            pushFollow(FOLLOW_7);
            rule__ArchQualityModel__Group_4_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group_4_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_4_3__0"


    // $ANTLR start "rule__ArchQualityModel__Group_4_3__0__Impl"
    // InternalArchQualityDef.g:890:1: rule__ArchQualityModel__Group_4_3__0__Impl : ( ',' ) ;
    public final void rule__ArchQualityModel__Group_4_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:894:1: ( ( ',' ) )
            // InternalArchQualityDef.g:895:1: ( ',' )
            {
            // InternalArchQualityDef.g:895:1: ( ',' )
            // InternalArchQualityDef.g:896:2: ','
            {
             before(grammarAccess.getArchQualityModelAccess().getCommaKeyword_4_3_0()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getArchQualityModelAccess().getCommaKeyword_4_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_4_3__0__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group_4_3__1"
    // InternalArchQualityDef.g:905:1: rule__ArchQualityModel__Group_4_3__1 : rule__ArchQualityModel__Group_4_3__1__Impl ;
    public final void rule__ArchQualityModel__Group_4_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:909:1: ( rule__ArchQualityModel__Group_4_3__1__Impl )
            // InternalArchQualityDef.g:910:2: rule__ArchQualityModel__Group_4_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group_4_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_4_3__1"


    // $ANTLR start "rule__ArchQualityModel__Group_4_3__1__Impl"
    // InternalArchQualityDef.g:916:1: rule__ArchQualityModel__Group_4_3__1__Impl : ( ( rule__ArchQualityModel__ResearchAssignment_4_3_1 ) ) ;
    public final void rule__ArchQualityModel__Group_4_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:920:1: ( ( ( rule__ArchQualityModel__ResearchAssignment_4_3_1 ) ) )
            // InternalArchQualityDef.g:921:1: ( ( rule__ArchQualityModel__ResearchAssignment_4_3_1 ) )
            {
            // InternalArchQualityDef.g:921:1: ( ( rule__ArchQualityModel__ResearchAssignment_4_3_1 ) )
            // InternalArchQualityDef.g:922:2: ( rule__ArchQualityModel__ResearchAssignment_4_3_1 )
            {
             before(grammarAccess.getArchQualityModelAccess().getResearchAssignment_4_3_1()); 
            // InternalArchQualityDef.g:923:2: ( rule__ArchQualityModel__ResearchAssignment_4_3_1 )
            // InternalArchQualityDef.g:923:3: rule__ArchQualityModel__ResearchAssignment_4_3_1
            {
            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__ResearchAssignment_4_3_1();

            state._fsp--;


            }

             after(grammarAccess.getArchQualityModelAccess().getResearchAssignment_4_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_4_3__1__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group_5__0"
    // InternalArchQualityDef.g:932:1: rule__ArchQualityModel__Group_5__0 : rule__ArchQualityModel__Group_5__0__Impl rule__ArchQualityModel__Group_5__1 ;
    public final void rule__ArchQualityModel__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:936:1: ( rule__ArchQualityModel__Group_5__0__Impl rule__ArchQualityModel__Group_5__1 )
            // InternalArchQualityDef.g:937:2: rule__ArchQualityModel__Group_5__0__Impl rule__ArchQualityModel__Group_5__1
            {
            pushFollow(FOLLOW_4);
            rule__ArchQualityModel__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_5__0"


    // $ANTLR start "rule__ArchQualityModel__Group_5__0__Impl"
    // InternalArchQualityDef.g:944:1: rule__ArchQualityModel__Group_5__0__Impl : ( 'qualitydef' ) ;
    public final void rule__ArchQualityModel__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:948:1: ( ( 'qualitydef' ) )
            // InternalArchQualityDef.g:949:1: ( 'qualitydef' )
            {
            // InternalArchQualityDef.g:949:1: ( 'qualitydef' )
            // InternalArchQualityDef.g:950:2: 'qualitydef'
            {
             before(grammarAccess.getArchQualityModelAccess().getQualitydefKeyword_5_0()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getArchQualityModelAccess().getQualitydefKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_5__0__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group_5__1"
    // InternalArchQualityDef.g:959:1: rule__ArchQualityModel__Group_5__1 : rule__ArchQualityModel__Group_5__1__Impl rule__ArchQualityModel__Group_5__2 ;
    public final void rule__ArchQualityModel__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:963:1: ( rule__ArchQualityModel__Group_5__1__Impl rule__ArchQualityModel__Group_5__2 )
            // InternalArchQualityDef.g:964:2: rule__ArchQualityModel__Group_5__1__Impl rule__ArchQualityModel__Group_5__2
            {
            pushFollow(FOLLOW_10);
            rule__ArchQualityModel__Group_5__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group_5__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_5__1"


    // $ANTLR start "rule__ArchQualityModel__Group_5__1__Impl"
    // InternalArchQualityDef.g:971:1: rule__ArchQualityModel__Group_5__1__Impl : ( '{' ) ;
    public final void rule__ArchQualityModel__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:975:1: ( ( '{' ) )
            // InternalArchQualityDef.g:976:1: ( '{' )
            {
            // InternalArchQualityDef.g:976:1: ( '{' )
            // InternalArchQualityDef.g:977:2: '{'
            {
             before(grammarAccess.getArchQualityModelAccess().getLeftCurlyBracketKeyword_5_1()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getArchQualityModelAccess().getLeftCurlyBracketKeyword_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_5__1__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group_5__2"
    // InternalArchQualityDef.g:986:1: rule__ArchQualityModel__Group_5__2 : rule__ArchQualityModel__Group_5__2__Impl rule__ArchQualityModel__Group_5__3 ;
    public final void rule__ArchQualityModel__Group_5__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:990:1: ( rule__ArchQualityModel__Group_5__2__Impl rule__ArchQualityModel__Group_5__3 )
            // InternalArchQualityDef.g:991:2: rule__ArchQualityModel__Group_5__2__Impl rule__ArchQualityModel__Group_5__3
            {
            pushFollow(FOLLOW_8);
            rule__ArchQualityModel__Group_5__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group_5__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_5__2"


    // $ANTLR start "rule__ArchQualityModel__Group_5__2__Impl"
    // InternalArchQualityDef.g:998:1: rule__ArchQualityModel__Group_5__2__Impl : ( ( rule__ArchQualityModel__QualitydefAssignment_5_2 ) ) ;
    public final void rule__ArchQualityModel__Group_5__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1002:1: ( ( ( rule__ArchQualityModel__QualitydefAssignment_5_2 ) ) )
            // InternalArchQualityDef.g:1003:1: ( ( rule__ArchQualityModel__QualitydefAssignment_5_2 ) )
            {
            // InternalArchQualityDef.g:1003:1: ( ( rule__ArchQualityModel__QualitydefAssignment_5_2 ) )
            // InternalArchQualityDef.g:1004:2: ( rule__ArchQualityModel__QualitydefAssignment_5_2 )
            {
             before(grammarAccess.getArchQualityModelAccess().getQualitydefAssignment_5_2()); 
            // InternalArchQualityDef.g:1005:2: ( rule__ArchQualityModel__QualitydefAssignment_5_2 )
            // InternalArchQualityDef.g:1005:3: rule__ArchQualityModel__QualitydefAssignment_5_2
            {
            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__QualitydefAssignment_5_2();

            state._fsp--;


            }

             after(grammarAccess.getArchQualityModelAccess().getQualitydefAssignment_5_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_5__2__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group_5__3"
    // InternalArchQualityDef.g:1013:1: rule__ArchQualityModel__Group_5__3 : rule__ArchQualityModel__Group_5__3__Impl rule__ArchQualityModel__Group_5__4 ;
    public final void rule__ArchQualityModel__Group_5__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1017:1: ( rule__ArchQualityModel__Group_5__3__Impl rule__ArchQualityModel__Group_5__4 )
            // InternalArchQualityDef.g:1018:2: rule__ArchQualityModel__Group_5__3__Impl rule__ArchQualityModel__Group_5__4
            {
            pushFollow(FOLLOW_8);
            rule__ArchQualityModel__Group_5__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group_5__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_5__3"


    // $ANTLR start "rule__ArchQualityModel__Group_5__3__Impl"
    // InternalArchQualityDef.g:1025:1: rule__ArchQualityModel__Group_5__3__Impl : ( ( rule__ArchQualityModel__Group_5_3__0 )* ) ;
    public final void rule__ArchQualityModel__Group_5__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1029:1: ( ( ( rule__ArchQualityModel__Group_5_3__0 )* ) )
            // InternalArchQualityDef.g:1030:1: ( ( rule__ArchQualityModel__Group_5_3__0 )* )
            {
            // InternalArchQualityDef.g:1030:1: ( ( rule__ArchQualityModel__Group_5_3__0 )* )
            // InternalArchQualityDef.g:1031:2: ( rule__ArchQualityModel__Group_5_3__0 )*
            {
             before(grammarAccess.getArchQualityModelAccess().getGroup_5_3()); 
            // InternalArchQualityDef.g:1032:2: ( rule__ArchQualityModel__Group_5_3__0 )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==23) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // InternalArchQualityDef.g:1032:3: rule__ArchQualityModel__Group_5_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__ArchQualityModel__Group_5_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);

             after(grammarAccess.getArchQualityModelAccess().getGroup_5_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_5__3__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group_5__4"
    // InternalArchQualityDef.g:1040:1: rule__ArchQualityModel__Group_5__4 : rule__ArchQualityModel__Group_5__4__Impl ;
    public final void rule__ArchQualityModel__Group_5__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1044:1: ( rule__ArchQualityModel__Group_5__4__Impl )
            // InternalArchQualityDef.g:1045:2: rule__ArchQualityModel__Group_5__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group_5__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_5__4"


    // $ANTLR start "rule__ArchQualityModel__Group_5__4__Impl"
    // InternalArchQualityDef.g:1051:1: rule__ArchQualityModel__Group_5__4__Impl : ( '}' ) ;
    public final void rule__ArchQualityModel__Group_5__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1055:1: ( ( '}' ) )
            // InternalArchQualityDef.g:1056:1: ( '}' )
            {
            // InternalArchQualityDef.g:1056:1: ( '}' )
            // InternalArchQualityDef.g:1057:2: '}'
            {
             before(grammarAccess.getArchQualityModelAccess().getRightCurlyBracketKeyword_5_4()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getArchQualityModelAccess().getRightCurlyBracketKeyword_5_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_5__4__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group_5_3__0"
    // InternalArchQualityDef.g:1067:1: rule__ArchQualityModel__Group_5_3__0 : rule__ArchQualityModel__Group_5_3__0__Impl rule__ArchQualityModel__Group_5_3__1 ;
    public final void rule__ArchQualityModel__Group_5_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1071:1: ( rule__ArchQualityModel__Group_5_3__0__Impl rule__ArchQualityModel__Group_5_3__1 )
            // InternalArchQualityDef.g:1072:2: rule__ArchQualityModel__Group_5_3__0__Impl rule__ArchQualityModel__Group_5_3__1
            {
            pushFollow(FOLLOW_10);
            rule__ArchQualityModel__Group_5_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group_5_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_5_3__0"


    // $ANTLR start "rule__ArchQualityModel__Group_5_3__0__Impl"
    // InternalArchQualityDef.g:1079:1: rule__ArchQualityModel__Group_5_3__0__Impl : ( ',' ) ;
    public final void rule__ArchQualityModel__Group_5_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1083:1: ( ( ',' ) )
            // InternalArchQualityDef.g:1084:1: ( ',' )
            {
            // InternalArchQualityDef.g:1084:1: ( ',' )
            // InternalArchQualityDef.g:1085:2: ','
            {
             before(grammarAccess.getArchQualityModelAccess().getCommaKeyword_5_3_0()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getArchQualityModelAccess().getCommaKeyword_5_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_5_3__0__Impl"


    // $ANTLR start "rule__ArchQualityModel__Group_5_3__1"
    // InternalArchQualityDef.g:1094:1: rule__ArchQualityModel__Group_5_3__1 : rule__ArchQualityModel__Group_5_3__1__Impl ;
    public final void rule__ArchQualityModel__Group_5_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1098:1: ( rule__ArchQualityModel__Group_5_3__1__Impl )
            // InternalArchQualityDef.g:1099:2: rule__ArchQualityModel__Group_5_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__Group_5_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_5_3__1"


    // $ANTLR start "rule__ArchQualityModel__Group_5_3__1__Impl"
    // InternalArchQualityDef.g:1105:1: rule__ArchQualityModel__Group_5_3__1__Impl : ( ( rule__ArchQualityModel__QualitydefAssignment_5_3_1 ) ) ;
    public final void rule__ArchQualityModel__Group_5_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1109:1: ( ( ( rule__ArchQualityModel__QualitydefAssignment_5_3_1 ) ) )
            // InternalArchQualityDef.g:1110:1: ( ( rule__ArchQualityModel__QualitydefAssignment_5_3_1 ) )
            {
            // InternalArchQualityDef.g:1110:1: ( ( rule__ArchQualityModel__QualitydefAssignment_5_3_1 ) )
            // InternalArchQualityDef.g:1111:2: ( rule__ArchQualityModel__QualitydefAssignment_5_3_1 )
            {
             before(grammarAccess.getArchQualityModelAccess().getQualitydefAssignment_5_3_1()); 
            // InternalArchQualityDef.g:1112:2: ( rule__ArchQualityModel__QualitydefAssignment_5_3_1 )
            // InternalArchQualityDef.g:1112:3: rule__ArchQualityModel__QualitydefAssignment_5_3_1
            {
            pushFollow(FOLLOW_2);
            rule__ArchQualityModel__QualitydefAssignment_5_3_1();

            state._fsp--;


            }

             after(grammarAccess.getArchQualityModelAccess().getQualitydefAssignment_5_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__Group_5_3__1__Impl"


    // $ANTLR start "rule__EDate__Group__0"
    // InternalArchQualityDef.g:1121:1: rule__EDate__Group__0 : rule__EDate__Group__0__Impl rule__EDate__Group__1 ;
    public final void rule__EDate__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1125:1: ( rule__EDate__Group__0__Impl rule__EDate__Group__1 )
            // InternalArchQualityDef.g:1126:2: rule__EDate__Group__0__Impl rule__EDate__Group__1
            {
            pushFollow(FOLLOW_11);
            rule__EDate__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EDate__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDate__Group__0"


    // $ANTLR start "rule__EDate__Group__0__Impl"
    // InternalArchQualityDef.g:1133:1: rule__EDate__Group__0__Impl : ( 'lastupdate' ) ;
    public final void rule__EDate__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1137:1: ( ( 'lastupdate' ) )
            // InternalArchQualityDef.g:1138:1: ( 'lastupdate' )
            {
            // InternalArchQualityDef.g:1138:1: ( 'lastupdate' )
            // InternalArchQualityDef.g:1139:2: 'lastupdate'
            {
             before(grammarAccess.getEDateAccess().getLastupdateKeyword_0()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getEDateAccess().getLastupdateKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDate__Group__0__Impl"


    // $ANTLR start "rule__EDate__Group__1"
    // InternalArchQualityDef.g:1148:1: rule__EDate__Group__1 : rule__EDate__Group__1__Impl ;
    public final void rule__EDate__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1152:1: ( rule__EDate__Group__1__Impl )
            // InternalArchQualityDef.g:1153:2: rule__EDate__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EDate__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDate__Group__1"


    // $ANTLR start "rule__EDate__Group__1__Impl"
    // InternalArchQualityDef.g:1159:1: rule__EDate__Group__1__Impl : ( RULE_STRING ) ;
    public final void rule__EDate__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1163:1: ( ( RULE_STRING ) )
            // InternalArchQualityDef.g:1164:1: ( RULE_STRING )
            {
            // InternalArchQualityDef.g:1164:1: ( RULE_STRING )
            // InternalArchQualityDef.g:1165:2: RULE_STRING
            {
             before(grammarAccess.getEDateAccess().getSTRINGTerminalRuleCall_1()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getEDateAccess().getSTRINGTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDate__Group__1__Impl"


    // $ANTLR start "rule__Field__Group__0"
    // InternalArchQualityDef.g:1175:1: rule__Field__Group__0 : rule__Field__Group__0__Impl rule__Field__Group__1 ;
    public final void rule__Field__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1179:1: ( rule__Field__Group__0__Impl rule__Field__Group__1 )
            // InternalArchQualityDef.g:1180:2: rule__Field__Group__0__Impl rule__Field__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__Field__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group__0"


    // $ANTLR start "rule__Field__Group__0__Impl"
    // InternalArchQualityDef.g:1187:1: rule__Field__Group__0__Impl : ( () ) ;
    public final void rule__Field__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1191:1: ( ( () ) )
            // InternalArchQualityDef.g:1192:1: ( () )
            {
            // InternalArchQualityDef.g:1192:1: ( () )
            // InternalArchQualityDef.g:1193:2: ()
            {
             before(grammarAccess.getFieldAccess().getFieldAction_0()); 
            // InternalArchQualityDef.g:1194:2: ()
            // InternalArchQualityDef.g:1194:3: 
            {
            }

             after(grammarAccess.getFieldAccess().getFieldAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group__0__Impl"


    // $ANTLR start "rule__Field__Group__1"
    // InternalArchQualityDef.g:1202:1: rule__Field__Group__1 : rule__Field__Group__1__Impl ;
    public final void rule__Field__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1206:1: ( rule__Field__Group__1__Impl )
            // InternalArchQualityDef.g:1207:2: rule__Field__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Field__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group__1"


    // $ANTLR start "rule__Field__Group__1__Impl"
    // InternalArchQualityDef.g:1213:1: rule__Field__Group__1__Impl : ( ( rule__Field__Alternatives_1 ) ) ;
    public final void rule__Field__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1217:1: ( ( ( rule__Field__Alternatives_1 ) ) )
            // InternalArchQualityDef.g:1218:1: ( ( rule__Field__Alternatives_1 ) )
            {
            // InternalArchQualityDef.g:1218:1: ( ( rule__Field__Alternatives_1 ) )
            // InternalArchQualityDef.g:1219:2: ( rule__Field__Alternatives_1 )
            {
             before(grammarAccess.getFieldAccess().getAlternatives_1()); 
            // InternalArchQualityDef.g:1220:2: ( rule__Field__Alternatives_1 )
            // InternalArchQualityDef.g:1220:3: rule__Field__Alternatives_1
            {
            pushFollow(FOLLOW_2);
            rule__Field__Alternatives_1();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getAlternatives_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group__1__Impl"


    // $ANTLR start "rule__Field__Group_1_0__0"
    // InternalArchQualityDef.g:1229:1: rule__Field__Group_1_0__0 : rule__Field__Group_1_0__0__Impl rule__Field__Group_1_0__1 ;
    public final void rule__Field__Group_1_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1233:1: ( rule__Field__Group_1_0__0__Impl rule__Field__Group_1_0__1 )
            // InternalArchQualityDef.g:1234:2: rule__Field__Group_1_0__0__Impl rule__Field__Group_1_0__1
            {
            pushFollow(FOLLOW_4);
            rule__Field__Group_1_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_0__0"


    // $ANTLR start "rule__Field__Group_1_0__0__Impl"
    // InternalArchQualityDef.g:1241:1: rule__Field__Group_1_0__0__Impl : ( 'author=' ) ;
    public final void rule__Field__Group_1_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1245:1: ( ( 'author=' ) )
            // InternalArchQualityDef.g:1246:1: ( 'author=' )
            {
            // InternalArchQualityDef.g:1246:1: ( 'author=' )
            // InternalArchQualityDef.g:1247:2: 'author='
            {
             before(grammarAccess.getFieldAccess().getAuthorKeyword_1_0_0()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getAuthorKeyword_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_0__0__Impl"


    // $ANTLR start "rule__Field__Group_1_0__1"
    // InternalArchQualityDef.g:1256:1: rule__Field__Group_1_0__1 : rule__Field__Group_1_0__1__Impl rule__Field__Group_1_0__2 ;
    public final void rule__Field__Group_1_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1260:1: ( rule__Field__Group_1_0__1__Impl rule__Field__Group_1_0__2 )
            // InternalArchQualityDef.g:1261:2: rule__Field__Group_1_0__1__Impl rule__Field__Group_1_0__2
            {
            pushFollow(FOLLOW_13);
            rule__Field__Group_1_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_0__1"


    // $ANTLR start "rule__Field__Group_1_0__1__Impl"
    // InternalArchQualityDef.g:1268:1: rule__Field__Group_1_0__1__Impl : ( '{' ) ;
    public final void rule__Field__Group_1_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1272:1: ( ( '{' ) )
            // InternalArchQualityDef.g:1273:1: ( '{' )
            {
            // InternalArchQualityDef.g:1273:1: ( '{' )
            // InternalArchQualityDef.g:1274:2: '{'
            {
             before(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_0_1()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_0__1__Impl"


    // $ANTLR start "rule__Field__Group_1_0__2"
    // InternalArchQualityDef.g:1283:1: rule__Field__Group_1_0__2 : rule__Field__Group_1_0__2__Impl rule__Field__Group_1_0__3 ;
    public final void rule__Field__Group_1_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1287:1: ( rule__Field__Group_1_0__2__Impl rule__Field__Group_1_0__3 )
            // InternalArchQualityDef.g:1288:2: rule__Field__Group_1_0__2__Impl rule__Field__Group_1_0__3
            {
            pushFollow(FOLLOW_14);
            rule__Field__Group_1_0__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_0__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_0__2"


    // $ANTLR start "rule__Field__Group_1_0__2__Impl"
    // InternalArchQualityDef.g:1295:1: rule__Field__Group_1_0__2__Impl : ( ( rule__Field__AuthorsAssignment_1_0_2 ) ) ;
    public final void rule__Field__Group_1_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1299:1: ( ( ( rule__Field__AuthorsAssignment_1_0_2 ) ) )
            // InternalArchQualityDef.g:1300:1: ( ( rule__Field__AuthorsAssignment_1_0_2 ) )
            {
            // InternalArchQualityDef.g:1300:1: ( ( rule__Field__AuthorsAssignment_1_0_2 ) )
            // InternalArchQualityDef.g:1301:2: ( rule__Field__AuthorsAssignment_1_0_2 )
            {
             before(grammarAccess.getFieldAccess().getAuthorsAssignment_1_0_2()); 
            // InternalArchQualityDef.g:1302:2: ( rule__Field__AuthorsAssignment_1_0_2 )
            // InternalArchQualityDef.g:1302:3: rule__Field__AuthorsAssignment_1_0_2
            {
            pushFollow(FOLLOW_2);
            rule__Field__AuthorsAssignment_1_0_2();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getAuthorsAssignment_1_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_0__2__Impl"


    // $ANTLR start "rule__Field__Group_1_0__3"
    // InternalArchQualityDef.g:1310:1: rule__Field__Group_1_0__3 : rule__Field__Group_1_0__3__Impl rule__Field__Group_1_0__4 ;
    public final void rule__Field__Group_1_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1314:1: ( rule__Field__Group_1_0__3__Impl rule__Field__Group_1_0__4 )
            // InternalArchQualityDef.g:1315:2: rule__Field__Group_1_0__3__Impl rule__Field__Group_1_0__4
            {
            pushFollow(FOLLOW_14);
            rule__Field__Group_1_0__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_0__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_0__3"


    // $ANTLR start "rule__Field__Group_1_0__3__Impl"
    // InternalArchQualityDef.g:1322:1: rule__Field__Group_1_0__3__Impl : ( ( rule__Field__Group_1_0_3__0 )? ) ;
    public final void rule__Field__Group_1_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1326:1: ( ( ( rule__Field__Group_1_0_3__0 )? ) )
            // InternalArchQualityDef.g:1327:1: ( ( rule__Field__Group_1_0_3__0 )? )
            {
            // InternalArchQualityDef.g:1327:1: ( ( rule__Field__Group_1_0_3__0 )? )
            // InternalArchQualityDef.g:1328:2: ( rule__Field__Group_1_0_3__0 )?
            {
             before(grammarAccess.getFieldAccess().getGroup_1_0_3()); 
            // InternalArchQualityDef.g:1329:2: ( rule__Field__Group_1_0_3__0 )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==27) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalArchQualityDef.g:1329:3: rule__Field__Group_1_0_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Field__Group_1_0_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getFieldAccess().getGroup_1_0_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_0__3__Impl"


    // $ANTLR start "rule__Field__Group_1_0__4"
    // InternalArchQualityDef.g:1337:1: rule__Field__Group_1_0__4 : rule__Field__Group_1_0__4__Impl ;
    public final void rule__Field__Group_1_0__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1341:1: ( rule__Field__Group_1_0__4__Impl )
            // InternalArchQualityDef.g:1342:2: rule__Field__Group_1_0__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Field__Group_1_0__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_0__4"


    // $ANTLR start "rule__Field__Group_1_0__4__Impl"
    // InternalArchQualityDef.g:1348:1: rule__Field__Group_1_0__4__Impl : ( '}' ) ;
    public final void rule__Field__Group_1_0__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1352:1: ( ( '}' ) )
            // InternalArchQualityDef.g:1353:1: ( '}' )
            {
            // InternalArchQualityDef.g:1353:1: ( '}' )
            // InternalArchQualityDef.g:1354:2: '}'
            {
             before(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_0_4()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_0_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_0__4__Impl"


    // $ANTLR start "rule__Field__Group_1_0_3__0"
    // InternalArchQualityDef.g:1364:1: rule__Field__Group_1_0_3__0 : rule__Field__Group_1_0_3__0__Impl rule__Field__Group_1_0_3__1 ;
    public final void rule__Field__Group_1_0_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1368:1: ( rule__Field__Group_1_0_3__0__Impl rule__Field__Group_1_0_3__1 )
            // InternalArchQualityDef.g:1369:2: rule__Field__Group_1_0_3__0__Impl rule__Field__Group_1_0_3__1
            {
            pushFollow(FOLLOW_13);
            rule__Field__Group_1_0_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_0_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_0_3__0"


    // $ANTLR start "rule__Field__Group_1_0_3__0__Impl"
    // InternalArchQualityDef.g:1376:1: rule__Field__Group_1_0_3__0__Impl : ( 'and' ) ;
    public final void rule__Field__Group_1_0_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1380:1: ( ( 'and' ) )
            // InternalArchQualityDef.g:1381:1: ( 'and' )
            {
            // InternalArchQualityDef.g:1381:1: ( 'and' )
            // InternalArchQualityDef.g:1382:2: 'and'
            {
             before(grammarAccess.getFieldAccess().getAndKeyword_1_0_3_0()); 
            match(input,27,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getAndKeyword_1_0_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_0_3__0__Impl"


    // $ANTLR start "rule__Field__Group_1_0_3__1"
    // InternalArchQualityDef.g:1391:1: rule__Field__Group_1_0_3__1 : rule__Field__Group_1_0_3__1__Impl ;
    public final void rule__Field__Group_1_0_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1395:1: ( rule__Field__Group_1_0_3__1__Impl )
            // InternalArchQualityDef.g:1396:2: rule__Field__Group_1_0_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Field__Group_1_0_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_0_3__1"


    // $ANTLR start "rule__Field__Group_1_0_3__1__Impl"
    // InternalArchQualityDef.g:1402:1: rule__Field__Group_1_0_3__1__Impl : ( ( rule__Field__AuthorsAssignment_1_0_3_1 ) ) ;
    public final void rule__Field__Group_1_0_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1406:1: ( ( ( rule__Field__AuthorsAssignment_1_0_3_1 ) ) )
            // InternalArchQualityDef.g:1407:1: ( ( rule__Field__AuthorsAssignment_1_0_3_1 ) )
            {
            // InternalArchQualityDef.g:1407:1: ( ( rule__Field__AuthorsAssignment_1_0_3_1 ) )
            // InternalArchQualityDef.g:1408:2: ( rule__Field__AuthorsAssignment_1_0_3_1 )
            {
             before(grammarAccess.getFieldAccess().getAuthorsAssignment_1_0_3_1()); 
            // InternalArchQualityDef.g:1409:2: ( rule__Field__AuthorsAssignment_1_0_3_1 )
            // InternalArchQualityDef.g:1409:3: rule__Field__AuthorsAssignment_1_0_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Field__AuthorsAssignment_1_0_3_1();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getAuthorsAssignment_1_0_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_0_3__1__Impl"


    // $ANTLR start "rule__Field__Group_1_1__0"
    // InternalArchQualityDef.g:1418:1: rule__Field__Group_1_1__0 : rule__Field__Group_1_1__0__Impl rule__Field__Group_1_1__1 ;
    public final void rule__Field__Group_1_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1422:1: ( rule__Field__Group_1_1__0__Impl rule__Field__Group_1_1__1 )
            // InternalArchQualityDef.g:1423:2: rule__Field__Group_1_1__0__Impl rule__Field__Group_1_1__1
            {
            pushFollow(FOLLOW_4);
            rule__Field__Group_1_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_1__0"


    // $ANTLR start "rule__Field__Group_1_1__0__Impl"
    // InternalArchQualityDef.g:1430:1: rule__Field__Group_1_1__0__Impl : ( 'title=' ) ;
    public final void rule__Field__Group_1_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1434:1: ( ( 'title=' ) )
            // InternalArchQualityDef.g:1435:1: ( 'title=' )
            {
            // InternalArchQualityDef.g:1435:1: ( 'title=' )
            // InternalArchQualityDef.g:1436:2: 'title='
            {
             before(grammarAccess.getFieldAccess().getTitleKeyword_1_1_0()); 
            match(input,28,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getTitleKeyword_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_1__0__Impl"


    // $ANTLR start "rule__Field__Group_1_1__1"
    // InternalArchQualityDef.g:1445:1: rule__Field__Group_1_1__1 : rule__Field__Group_1_1__1__Impl rule__Field__Group_1_1__2 ;
    public final void rule__Field__Group_1_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1449:1: ( rule__Field__Group_1_1__1__Impl rule__Field__Group_1_1__2 )
            // InternalArchQualityDef.g:1450:2: rule__Field__Group_1_1__1__Impl rule__Field__Group_1_1__2
            {
            pushFollow(FOLLOW_11);
            rule__Field__Group_1_1__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_1__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_1__1"


    // $ANTLR start "rule__Field__Group_1_1__1__Impl"
    // InternalArchQualityDef.g:1457:1: rule__Field__Group_1_1__1__Impl : ( '{' ) ;
    public final void rule__Field__Group_1_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1461:1: ( ( '{' ) )
            // InternalArchQualityDef.g:1462:1: ( '{' )
            {
            // InternalArchQualityDef.g:1462:1: ( '{' )
            // InternalArchQualityDef.g:1463:2: '{'
            {
             before(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_1_1()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_1__1__Impl"


    // $ANTLR start "rule__Field__Group_1_1__2"
    // InternalArchQualityDef.g:1472:1: rule__Field__Group_1_1__2 : rule__Field__Group_1_1__2__Impl rule__Field__Group_1_1__3 ;
    public final void rule__Field__Group_1_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1476:1: ( rule__Field__Group_1_1__2__Impl rule__Field__Group_1_1__3 )
            // InternalArchQualityDef.g:1477:2: rule__Field__Group_1_1__2__Impl rule__Field__Group_1_1__3
            {
            pushFollow(FOLLOW_15);
            rule__Field__Group_1_1__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_1__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_1__2"


    // $ANTLR start "rule__Field__Group_1_1__2__Impl"
    // InternalArchQualityDef.g:1484:1: rule__Field__Group_1_1__2__Impl : ( ( rule__Field__TitleAssignment_1_1_2 ) ) ;
    public final void rule__Field__Group_1_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1488:1: ( ( ( rule__Field__TitleAssignment_1_1_2 ) ) )
            // InternalArchQualityDef.g:1489:1: ( ( rule__Field__TitleAssignment_1_1_2 ) )
            {
            // InternalArchQualityDef.g:1489:1: ( ( rule__Field__TitleAssignment_1_1_2 ) )
            // InternalArchQualityDef.g:1490:2: ( rule__Field__TitleAssignment_1_1_2 )
            {
             before(grammarAccess.getFieldAccess().getTitleAssignment_1_1_2()); 
            // InternalArchQualityDef.g:1491:2: ( rule__Field__TitleAssignment_1_1_2 )
            // InternalArchQualityDef.g:1491:3: rule__Field__TitleAssignment_1_1_2
            {
            pushFollow(FOLLOW_2);
            rule__Field__TitleAssignment_1_1_2();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getTitleAssignment_1_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_1__2__Impl"


    // $ANTLR start "rule__Field__Group_1_1__3"
    // InternalArchQualityDef.g:1499:1: rule__Field__Group_1_1__3 : rule__Field__Group_1_1__3__Impl ;
    public final void rule__Field__Group_1_1__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1503:1: ( rule__Field__Group_1_1__3__Impl )
            // InternalArchQualityDef.g:1504:2: rule__Field__Group_1_1__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Field__Group_1_1__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_1__3"


    // $ANTLR start "rule__Field__Group_1_1__3__Impl"
    // InternalArchQualityDef.g:1510:1: rule__Field__Group_1_1__3__Impl : ( '}' ) ;
    public final void rule__Field__Group_1_1__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1514:1: ( ( '}' ) )
            // InternalArchQualityDef.g:1515:1: ( '}' )
            {
            // InternalArchQualityDef.g:1515:1: ( '}' )
            // InternalArchQualityDef.g:1516:2: '}'
            {
             before(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_1_3()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_1_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_1__3__Impl"


    // $ANTLR start "rule__Field__Group_1_2__0"
    // InternalArchQualityDef.g:1526:1: rule__Field__Group_1_2__0 : rule__Field__Group_1_2__0__Impl rule__Field__Group_1_2__1 ;
    public final void rule__Field__Group_1_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1530:1: ( rule__Field__Group_1_2__0__Impl rule__Field__Group_1_2__1 )
            // InternalArchQualityDef.g:1531:2: rule__Field__Group_1_2__0__Impl rule__Field__Group_1_2__1
            {
            pushFollow(FOLLOW_4);
            rule__Field__Group_1_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_2__0"


    // $ANTLR start "rule__Field__Group_1_2__0__Impl"
    // InternalArchQualityDef.g:1538:1: rule__Field__Group_1_2__0__Impl : ( 'year=' ) ;
    public final void rule__Field__Group_1_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1542:1: ( ( 'year=' ) )
            // InternalArchQualityDef.g:1543:1: ( 'year=' )
            {
            // InternalArchQualityDef.g:1543:1: ( 'year=' )
            // InternalArchQualityDef.g:1544:2: 'year='
            {
             before(grammarAccess.getFieldAccess().getYearKeyword_1_2_0()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getYearKeyword_1_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_2__0__Impl"


    // $ANTLR start "rule__Field__Group_1_2__1"
    // InternalArchQualityDef.g:1553:1: rule__Field__Group_1_2__1 : rule__Field__Group_1_2__1__Impl rule__Field__Group_1_2__2 ;
    public final void rule__Field__Group_1_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1557:1: ( rule__Field__Group_1_2__1__Impl rule__Field__Group_1_2__2 )
            // InternalArchQualityDef.g:1558:2: rule__Field__Group_1_2__1__Impl rule__Field__Group_1_2__2
            {
            pushFollow(FOLLOW_11);
            rule__Field__Group_1_2__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_2__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_2__1"


    // $ANTLR start "rule__Field__Group_1_2__1__Impl"
    // InternalArchQualityDef.g:1565:1: rule__Field__Group_1_2__1__Impl : ( '{' ) ;
    public final void rule__Field__Group_1_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1569:1: ( ( '{' ) )
            // InternalArchQualityDef.g:1570:1: ( '{' )
            {
            // InternalArchQualityDef.g:1570:1: ( '{' )
            // InternalArchQualityDef.g:1571:2: '{'
            {
             before(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_2_1()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_2__1__Impl"


    // $ANTLR start "rule__Field__Group_1_2__2"
    // InternalArchQualityDef.g:1580:1: rule__Field__Group_1_2__2 : rule__Field__Group_1_2__2__Impl rule__Field__Group_1_2__3 ;
    public final void rule__Field__Group_1_2__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1584:1: ( rule__Field__Group_1_2__2__Impl rule__Field__Group_1_2__3 )
            // InternalArchQualityDef.g:1585:2: rule__Field__Group_1_2__2__Impl rule__Field__Group_1_2__3
            {
            pushFollow(FOLLOW_15);
            rule__Field__Group_1_2__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_2__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_2__2"


    // $ANTLR start "rule__Field__Group_1_2__2__Impl"
    // InternalArchQualityDef.g:1592:1: rule__Field__Group_1_2__2__Impl : ( ( rule__Field__YearAssignment_1_2_2 ) ) ;
    public final void rule__Field__Group_1_2__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1596:1: ( ( ( rule__Field__YearAssignment_1_2_2 ) ) )
            // InternalArchQualityDef.g:1597:1: ( ( rule__Field__YearAssignment_1_2_2 ) )
            {
            // InternalArchQualityDef.g:1597:1: ( ( rule__Field__YearAssignment_1_2_2 ) )
            // InternalArchQualityDef.g:1598:2: ( rule__Field__YearAssignment_1_2_2 )
            {
             before(grammarAccess.getFieldAccess().getYearAssignment_1_2_2()); 
            // InternalArchQualityDef.g:1599:2: ( rule__Field__YearAssignment_1_2_2 )
            // InternalArchQualityDef.g:1599:3: rule__Field__YearAssignment_1_2_2
            {
            pushFollow(FOLLOW_2);
            rule__Field__YearAssignment_1_2_2();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getYearAssignment_1_2_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_2__2__Impl"


    // $ANTLR start "rule__Field__Group_1_2__3"
    // InternalArchQualityDef.g:1607:1: rule__Field__Group_1_2__3 : rule__Field__Group_1_2__3__Impl ;
    public final void rule__Field__Group_1_2__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1611:1: ( rule__Field__Group_1_2__3__Impl )
            // InternalArchQualityDef.g:1612:2: rule__Field__Group_1_2__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Field__Group_1_2__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_2__3"


    // $ANTLR start "rule__Field__Group_1_2__3__Impl"
    // InternalArchQualityDef.g:1618:1: rule__Field__Group_1_2__3__Impl : ( '}' ) ;
    public final void rule__Field__Group_1_2__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1622:1: ( ( '}' ) )
            // InternalArchQualityDef.g:1623:1: ( '}' )
            {
            // InternalArchQualityDef.g:1623:1: ( '}' )
            // InternalArchQualityDef.g:1624:2: '}'
            {
             before(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_2_3()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_2_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_2__3__Impl"


    // $ANTLR start "rule__Field__Group_1_3__0"
    // InternalArchQualityDef.g:1634:1: rule__Field__Group_1_3__0 : rule__Field__Group_1_3__0__Impl rule__Field__Group_1_3__1 ;
    public final void rule__Field__Group_1_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1638:1: ( rule__Field__Group_1_3__0__Impl rule__Field__Group_1_3__1 )
            // InternalArchQualityDef.g:1639:2: rule__Field__Group_1_3__0__Impl rule__Field__Group_1_3__1
            {
            pushFollow(FOLLOW_4);
            rule__Field__Group_1_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_3__0"


    // $ANTLR start "rule__Field__Group_1_3__0__Impl"
    // InternalArchQualityDef.g:1646:1: rule__Field__Group_1_3__0__Impl : ( 'pages=' ) ;
    public final void rule__Field__Group_1_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1650:1: ( ( 'pages=' ) )
            // InternalArchQualityDef.g:1651:1: ( 'pages=' )
            {
            // InternalArchQualityDef.g:1651:1: ( 'pages=' )
            // InternalArchQualityDef.g:1652:2: 'pages='
            {
             before(grammarAccess.getFieldAccess().getPagesKeyword_1_3_0()); 
            match(input,30,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getPagesKeyword_1_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_3__0__Impl"


    // $ANTLR start "rule__Field__Group_1_3__1"
    // InternalArchQualityDef.g:1661:1: rule__Field__Group_1_3__1 : rule__Field__Group_1_3__1__Impl rule__Field__Group_1_3__2 ;
    public final void rule__Field__Group_1_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1665:1: ( rule__Field__Group_1_3__1__Impl rule__Field__Group_1_3__2 )
            // InternalArchQualityDef.g:1666:2: rule__Field__Group_1_3__1__Impl rule__Field__Group_1_3__2
            {
            pushFollow(FOLLOW_11);
            rule__Field__Group_1_3__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_3__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_3__1"


    // $ANTLR start "rule__Field__Group_1_3__1__Impl"
    // InternalArchQualityDef.g:1673:1: rule__Field__Group_1_3__1__Impl : ( '{' ) ;
    public final void rule__Field__Group_1_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1677:1: ( ( '{' ) )
            // InternalArchQualityDef.g:1678:1: ( '{' )
            {
            // InternalArchQualityDef.g:1678:1: ( '{' )
            // InternalArchQualityDef.g:1679:2: '{'
            {
             before(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_3_1()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_3__1__Impl"


    // $ANTLR start "rule__Field__Group_1_3__2"
    // InternalArchQualityDef.g:1688:1: rule__Field__Group_1_3__2 : rule__Field__Group_1_3__2__Impl rule__Field__Group_1_3__3 ;
    public final void rule__Field__Group_1_3__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1692:1: ( rule__Field__Group_1_3__2__Impl rule__Field__Group_1_3__3 )
            // InternalArchQualityDef.g:1693:2: rule__Field__Group_1_3__2__Impl rule__Field__Group_1_3__3
            {
            pushFollow(FOLLOW_15);
            rule__Field__Group_1_3__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_3__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_3__2"


    // $ANTLR start "rule__Field__Group_1_3__2__Impl"
    // InternalArchQualityDef.g:1700:1: rule__Field__Group_1_3__2__Impl : ( ( rule__Field__PagesAssignment_1_3_2 ) ) ;
    public final void rule__Field__Group_1_3__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1704:1: ( ( ( rule__Field__PagesAssignment_1_3_2 ) ) )
            // InternalArchQualityDef.g:1705:1: ( ( rule__Field__PagesAssignment_1_3_2 ) )
            {
            // InternalArchQualityDef.g:1705:1: ( ( rule__Field__PagesAssignment_1_3_2 ) )
            // InternalArchQualityDef.g:1706:2: ( rule__Field__PagesAssignment_1_3_2 )
            {
             before(grammarAccess.getFieldAccess().getPagesAssignment_1_3_2()); 
            // InternalArchQualityDef.g:1707:2: ( rule__Field__PagesAssignment_1_3_2 )
            // InternalArchQualityDef.g:1707:3: rule__Field__PagesAssignment_1_3_2
            {
            pushFollow(FOLLOW_2);
            rule__Field__PagesAssignment_1_3_2();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getPagesAssignment_1_3_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_3__2__Impl"


    // $ANTLR start "rule__Field__Group_1_3__3"
    // InternalArchQualityDef.g:1715:1: rule__Field__Group_1_3__3 : rule__Field__Group_1_3__3__Impl ;
    public final void rule__Field__Group_1_3__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1719:1: ( rule__Field__Group_1_3__3__Impl )
            // InternalArchQualityDef.g:1720:2: rule__Field__Group_1_3__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Field__Group_1_3__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_3__3"


    // $ANTLR start "rule__Field__Group_1_3__3__Impl"
    // InternalArchQualityDef.g:1726:1: rule__Field__Group_1_3__3__Impl : ( '}' ) ;
    public final void rule__Field__Group_1_3__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1730:1: ( ( '}' ) )
            // InternalArchQualityDef.g:1731:1: ( '}' )
            {
            // InternalArchQualityDef.g:1731:1: ( '}' )
            // InternalArchQualityDef.g:1732:2: '}'
            {
             before(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_3_3()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_3_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_3__3__Impl"


    // $ANTLR start "rule__Field__Group_1_4__0"
    // InternalArchQualityDef.g:1742:1: rule__Field__Group_1_4__0 : rule__Field__Group_1_4__0__Impl rule__Field__Group_1_4__1 ;
    public final void rule__Field__Group_1_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1746:1: ( rule__Field__Group_1_4__0__Impl rule__Field__Group_1_4__1 )
            // InternalArchQualityDef.g:1747:2: rule__Field__Group_1_4__0__Impl rule__Field__Group_1_4__1
            {
            pushFollow(FOLLOW_4);
            rule__Field__Group_1_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_4__0"


    // $ANTLR start "rule__Field__Group_1_4__0__Impl"
    // InternalArchQualityDef.g:1754:1: rule__Field__Group_1_4__0__Impl : ( 'address=' ) ;
    public final void rule__Field__Group_1_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1758:1: ( ( 'address=' ) )
            // InternalArchQualityDef.g:1759:1: ( 'address=' )
            {
            // InternalArchQualityDef.g:1759:1: ( 'address=' )
            // InternalArchQualityDef.g:1760:2: 'address='
            {
             before(grammarAccess.getFieldAccess().getAddressKeyword_1_4_0()); 
            match(input,31,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getAddressKeyword_1_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_4__0__Impl"


    // $ANTLR start "rule__Field__Group_1_4__1"
    // InternalArchQualityDef.g:1769:1: rule__Field__Group_1_4__1 : rule__Field__Group_1_4__1__Impl rule__Field__Group_1_4__2 ;
    public final void rule__Field__Group_1_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1773:1: ( rule__Field__Group_1_4__1__Impl rule__Field__Group_1_4__2 )
            // InternalArchQualityDef.g:1774:2: rule__Field__Group_1_4__1__Impl rule__Field__Group_1_4__2
            {
            pushFollow(FOLLOW_11);
            rule__Field__Group_1_4__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_4__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_4__1"


    // $ANTLR start "rule__Field__Group_1_4__1__Impl"
    // InternalArchQualityDef.g:1781:1: rule__Field__Group_1_4__1__Impl : ( '{' ) ;
    public final void rule__Field__Group_1_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1785:1: ( ( '{' ) )
            // InternalArchQualityDef.g:1786:1: ( '{' )
            {
            // InternalArchQualityDef.g:1786:1: ( '{' )
            // InternalArchQualityDef.g:1787:2: '{'
            {
             before(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_4_1()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_4__1__Impl"


    // $ANTLR start "rule__Field__Group_1_4__2"
    // InternalArchQualityDef.g:1796:1: rule__Field__Group_1_4__2 : rule__Field__Group_1_4__2__Impl rule__Field__Group_1_4__3 ;
    public final void rule__Field__Group_1_4__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1800:1: ( rule__Field__Group_1_4__2__Impl rule__Field__Group_1_4__3 )
            // InternalArchQualityDef.g:1801:2: rule__Field__Group_1_4__2__Impl rule__Field__Group_1_4__3
            {
            pushFollow(FOLLOW_15);
            rule__Field__Group_1_4__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_4__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_4__2"


    // $ANTLR start "rule__Field__Group_1_4__2__Impl"
    // InternalArchQualityDef.g:1808:1: rule__Field__Group_1_4__2__Impl : ( ( rule__Field__AddressAssignment_1_4_2 ) ) ;
    public final void rule__Field__Group_1_4__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1812:1: ( ( ( rule__Field__AddressAssignment_1_4_2 ) ) )
            // InternalArchQualityDef.g:1813:1: ( ( rule__Field__AddressAssignment_1_4_2 ) )
            {
            // InternalArchQualityDef.g:1813:1: ( ( rule__Field__AddressAssignment_1_4_2 ) )
            // InternalArchQualityDef.g:1814:2: ( rule__Field__AddressAssignment_1_4_2 )
            {
             before(grammarAccess.getFieldAccess().getAddressAssignment_1_4_2()); 
            // InternalArchQualityDef.g:1815:2: ( rule__Field__AddressAssignment_1_4_2 )
            // InternalArchQualityDef.g:1815:3: rule__Field__AddressAssignment_1_4_2
            {
            pushFollow(FOLLOW_2);
            rule__Field__AddressAssignment_1_4_2();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getAddressAssignment_1_4_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_4__2__Impl"


    // $ANTLR start "rule__Field__Group_1_4__3"
    // InternalArchQualityDef.g:1823:1: rule__Field__Group_1_4__3 : rule__Field__Group_1_4__3__Impl ;
    public final void rule__Field__Group_1_4__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1827:1: ( rule__Field__Group_1_4__3__Impl )
            // InternalArchQualityDef.g:1828:2: rule__Field__Group_1_4__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Field__Group_1_4__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_4__3"


    // $ANTLR start "rule__Field__Group_1_4__3__Impl"
    // InternalArchQualityDef.g:1834:1: rule__Field__Group_1_4__3__Impl : ( '}' ) ;
    public final void rule__Field__Group_1_4__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1838:1: ( ( '}' ) )
            // InternalArchQualityDef.g:1839:1: ( '}' )
            {
            // InternalArchQualityDef.g:1839:1: ( '}' )
            // InternalArchQualityDef.g:1840:2: '}'
            {
             before(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_4_3()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_4_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_4__3__Impl"


    // $ANTLR start "rule__Field__Group_1_5__0"
    // InternalArchQualityDef.g:1850:1: rule__Field__Group_1_5__0 : rule__Field__Group_1_5__0__Impl rule__Field__Group_1_5__1 ;
    public final void rule__Field__Group_1_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1854:1: ( rule__Field__Group_1_5__0__Impl rule__Field__Group_1_5__1 )
            // InternalArchQualityDef.g:1855:2: rule__Field__Group_1_5__0__Impl rule__Field__Group_1_5__1
            {
            pushFollow(FOLLOW_4);
            rule__Field__Group_1_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_5__0"


    // $ANTLR start "rule__Field__Group_1_5__0__Impl"
    // InternalArchQualityDef.g:1862:1: rule__Field__Group_1_5__0__Impl : ( 'booktitle=' ) ;
    public final void rule__Field__Group_1_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1866:1: ( ( 'booktitle=' ) )
            // InternalArchQualityDef.g:1867:1: ( 'booktitle=' )
            {
            // InternalArchQualityDef.g:1867:1: ( 'booktitle=' )
            // InternalArchQualityDef.g:1868:2: 'booktitle='
            {
             before(grammarAccess.getFieldAccess().getBooktitleKeyword_1_5_0()); 
            match(input,32,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getBooktitleKeyword_1_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_5__0__Impl"


    // $ANTLR start "rule__Field__Group_1_5__1"
    // InternalArchQualityDef.g:1877:1: rule__Field__Group_1_5__1 : rule__Field__Group_1_5__1__Impl rule__Field__Group_1_5__2 ;
    public final void rule__Field__Group_1_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1881:1: ( rule__Field__Group_1_5__1__Impl rule__Field__Group_1_5__2 )
            // InternalArchQualityDef.g:1882:2: rule__Field__Group_1_5__1__Impl rule__Field__Group_1_5__2
            {
            pushFollow(FOLLOW_11);
            rule__Field__Group_1_5__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_5__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_5__1"


    // $ANTLR start "rule__Field__Group_1_5__1__Impl"
    // InternalArchQualityDef.g:1889:1: rule__Field__Group_1_5__1__Impl : ( '{' ) ;
    public final void rule__Field__Group_1_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1893:1: ( ( '{' ) )
            // InternalArchQualityDef.g:1894:1: ( '{' )
            {
            // InternalArchQualityDef.g:1894:1: ( '{' )
            // InternalArchQualityDef.g:1895:2: '{'
            {
             before(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_5_1()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_5__1__Impl"


    // $ANTLR start "rule__Field__Group_1_5__2"
    // InternalArchQualityDef.g:1904:1: rule__Field__Group_1_5__2 : rule__Field__Group_1_5__2__Impl rule__Field__Group_1_5__3 ;
    public final void rule__Field__Group_1_5__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1908:1: ( rule__Field__Group_1_5__2__Impl rule__Field__Group_1_5__3 )
            // InternalArchQualityDef.g:1909:2: rule__Field__Group_1_5__2__Impl rule__Field__Group_1_5__3
            {
            pushFollow(FOLLOW_15);
            rule__Field__Group_1_5__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_5__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_5__2"


    // $ANTLR start "rule__Field__Group_1_5__2__Impl"
    // InternalArchQualityDef.g:1916:1: rule__Field__Group_1_5__2__Impl : ( ( rule__Field__BooktitleAssignment_1_5_2 ) ) ;
    public final void rule__Field__Group_1_5__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1920:1: ( ( ( rule__Field__BooktitleAssignment_1_5_2 ) ) )
            // InternalArchQualityDef.g:1921:1: ( ( rule__Field__BooktitleAssignment_1_5_2 ) )
            {
            // InternalArchQualityDef.g:1921:1: ( ( rule__Field__BooktitleAssignment_1_5_2 ) )
            // InternalArchQualityDef.g:1922:2: ( rule__Field__BooktitleAssignment_1_5_2 )
            {
             before(grammarAccess.getFieldAccess().getBooktitleAssignment_1_5_2()); 
            // InternalArchQualityDef.g:1923:2: ( rule__Field__BooktitleAssignment_1_5_2 )
            // InternalArchQualityDef.g:1923:3: rule__Field__BooktitleAssignment_1_5_2
            {
            pushFollow(FOLLOW_2);
            rule__Field__BooktitleAssignment_1_5_2();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getBooktitleAssignment_1_5_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_5__2__Impl"


    // $ANTLR start "rule__Field__Group_1_5__3"
    // InternalArchQualityDef.g:1931:1: rule__Field__Group_1_5__3 : rule__Field__Group_1_5__3__Impl ;
    public final void rule__Field__Group_1_5__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1935:1: ( rule__Field__Group_1_5__3__Impl )
            // InternalArchQualityDef.g:1936:2: rule__Field__Group_1_5__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Field__Group_1_5__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_5__3"


    // $ANTLR start "rule__Field__Group_1_5__3__Impl"
    // InternalArchQualityDef.g:1942:1: rule__Field__Group_1_5__3__Impl : ( '}' ) ;
    public final void rule__Field__Group_1_5__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1946:1: ( ( '}' ) )
            // InternalArchQualityDef.g:1947:1: ( '}' )
            {
            // InternalArchQualityDef.g:1947:1: ( '}' )
            // InternalArchQualityDef.g:1948:2: '}'
            {
             before(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_5_3()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_5_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_5__3__Impl"


    // $ANTLR start "rule__Field__Group_1_6__0"
    // InternalArchQualityDef.g:1958:1: rule__Field__Group_1_6__0 : rule__Field__Group_1_6__0__Impl rule__Field__Group_1_6__1 ;
    public final void rule__Field__Group_1_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1962:1: ( rule__Field__Group_1_6__0__Impl rule__Field__Group_1_6__1 )
            // InternalArchQualityDef.g:1963:2: rule__Field__Group_1_6__0__Impl rule__Field__Group_1_6__1
            {
            pushFollow(FOLLOW_4);
            rule__Field__Group_1_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_6__0"


    // $ANTLR start "rule__Field__Group_1_6__0__Impl"
    // InternalArchQualityDef.g:1970:1: rule__Field__Group_1_6__0__Impl : ( 'journal=' ) ;
    public final void rule__Field__Group_1_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1974:1: ( ( 'journal=' ) )
            // InternalArchQualityDef.g:1975:1: ( 'journal=' )
            {
            // InternalArchQualityDef.g:1975:1: ( 'journal=' )
            // InternalArchQualityDef.g:1976:2: 'journal='
            {
             before(grammarAccess.getFieldAccess().getJournalKeyword_1_6_0()); 
            match(input,33,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getJournalKeyword_1_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_6__0__Impl"


    // $ANTLR start "rule__Field__Group_1_6__1"
    // InternalArchQualityDef.g:1985:1: rule__Field__Group_1_6__1 : rule__Field__Group_1_6__1__Impl rule__Field__Group_1_6__2 ;
    public final void rule__Field__Group_1_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:1989:1: ( rule__Field__Group_1_6__1__Impl rule__Field__Group_1_6__2 )
            // InternalArchQualityDef.g:1990:2: rule__Field__Group_1_6__1__Impl rule__Field__Group_1_6__2
            {
            pushFollow(FOLLOW_11);
            rule__Field__Group_1_6__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_6__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_6__1"


    // $ANTLR start "rule__Field__Group_1_6__1__Impl"
    // InternalArchQualityDef.g:1997:1: rule__Field__Group_1_6__1__Impl : ( '{' ) ;
    public final void rule__Field__Group_1_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2001:1: ( ( '{' ) )
            // InternalArchQualityDef.g:2002:1: ( '{' )
            {
            // InternalArchQualityDef.g:2002:1: ( '{' )
            // InternalArchQualityDef.g:2003:2: '{'
            {
             before(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_6_1()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_6__1__Impl"


    // $ANTLR start "rule__Field__Group_1_6__2"
    // InternalArchQualityDef.g:2012:1: rule__Field__Group_1_6__2 : rule__Field__Group_1_6__2__Impl rule__Field__Group_1_6__3 ;
    public final void rule__Field__Group_1_6__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2016:1: ( rule__Field__Group_1_6__2__Impl rule__Field__Group_1_6__3 )
            // InternalArchQualityDef.g:2017:2: rule__Field__Group_1_6__2__Impl rule__Field__Group_1_6__3
            {
            pushFollow(FOLLOW_15);
            rule__Field__Group_1_6__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_6__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_6__2"


    // $ANTLR start "rule__Field__Group_1_6__2__Impl"
    // InternalArchQualityDef.g:2024:1: rule__Field__Group_1_6__2__Impl : ( ( rule__Field__JournalAssignment_1_6_2 ) ) ;
    public final void rule__Field__Group_1_6__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2028:1: ( ( ( rule__Field__JournalAssignment_1_6_2 ) ) )
            // InternalArchQualityDef.g:2029:1: ( ( rule__Field__JournalAssignment_1_6_2 ) )
            {
            // InternalArchQualityDef.g:2029:1: ( ( rule__Field__JournalAssignment_1_6_2 ) )
            // InternalArchQualityDef.g:2030:2: ( rule__Field__JournalAssignment_1_6_2 )
            {
             before(grammarAccess.getFieldAccess().getJournalAssignment_1_6_2()); 
            // InternalArchQualityDef.g:2031:2: ( rule__Field__JournalAssignment_1_6_2 )
            // InternalArchQualityDef.g:2031:3: rule__Field__JournalAssignment_1_6_2
            {
            pushFollow(FOLLOW_2);
            rule__Field__JournalAssignment_1_6_2();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getJournalAssignment_1_6_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_6__2__Impl"


    // $ANTLR start "rule__Field__Group_1_6__3"
    // InternalArchQualityDef.g:2039:1: rule__Field__Group_1_6__3 : rule__Field__Group_1_6__3__Impl ;
    public final void rule__Field__Group_1_6__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2043:1: ( rule__Field__Group_1_6__3__Impl )
            // InternalArchQualityDef.g:2044:2: rule__Field__Group_1_6__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Field__Group_1_6__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_6__3"


    // $ANTLR start "rule__Field__Group_1_6__3__Impl"
    // InternalArchQualityDef.g:2050:1: rule__Field__Group_1_6__3__Impl : ( '}' ) ;
    public final void rule__Field__Group_1_6__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2054:1: ( ( '}' ) )
            // InternalArchQualityDef.g:2055:1: ( '}' )
            {
            // InternalArchQualityDef.g:2055:1: ( '}' )
            // InternalArchQualityDef.g:2056:2: '}'
            {
             before(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_6_3()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_6_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_6__3__Impl"


    // $ANTLR start "rule__Field__Group_1_7__0"
    // InternalArchQualityDef.g:2066:1: rule__Field__Group_1_7__0 : rule__Field__Group_1_7__0__Impl rule__Field__Group_1_7__1 ;
    public final void rule__Field__Group_1_7__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2070:1: ( rule__Field__Group_1_7__0__Impl rule__Field__Group_1_7__1 )
            // InternalArchQualityDef.g:2071:2: rule__Field__Group_1_7__0__Impl rule__Field__Group_1_7__1
            {
            pushFollow(FOLLOW_4);
            rule__Field__Group_1_7__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_7__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_7__0"


    // $ANTLR start "rule__Field__Group_1_7__0__Impl"
    // InternalArchQualityDef.g:2078:1: rule__Field__Group_1_7__0__Impl : ( 'chapter=' ) ;
    public final void rule__Field__Group_1_7__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2082:1: ( ( 'chapter=' ) )
            // InternalArchQualityDef.g:2083:1: ( 'chapter=' )
            {
            // InternalArchQualityDef.g:2083:1: ( 'chapter=' )
            // InternalArchQualityDef.g:2084:2: 'chapter='
            {
             before(grammarAccess.getFieldAccess().getChapterKeyword_1_7_0()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getChapterKeyword_1_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_7__0__Impl"


    // $ANTLR start "rule__Field__Group_1_7__1"
    // InternalArchQualityDef.g:2093:1: rule__Field__Group_1_7__1 : rule__Field__Group_1_7__1__Impl rule__Field__Group_1_7__2 ;
    public final void rule__Field__Group_1_7__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2097:1: ( rule__Field__Group_1_7__1__Impl rule__Field__Group_1_7__2 )
            // InternalArchQualityDef.g:2098:2: rule__Field__Group_1_7__1__Impl rule__Field__Group_1_7__2
            {
            pushFollow(FOLLOW_11);
            rule__Field__Group_1_7__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_7__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_7__1"


    // $ANTLR start "rule__Field__Group_1_7__1__Impl"
    // InternalArchQualityDef.g:2105:1: rule__Field__Group_1_7__1__Impl : ( '{' ) ;
    public final void rule__Field__Group_1_7__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2109:1: ( ( '{' ) )
            // InternalArchQualityDef.g:2110:1: ( '{' )
            {
            // InternalArchQualityDef.g:2110:1: ( '{' )
            // InternalArchQualityDef.g:2111:2: '{'
            {
             before(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_7_1()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_7_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_7__1__Impl"


    // $ANTLR start "rule__Field__Group_1_7__2"
    // InternalArchQualityDef.g:2120:1: rule__Field__Group_1_7__2 : rule__Field__Group_1_7__2__Impl rule__Field__Group_1_7__3 ;
    public final void rule__Field__Group_1_7__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2124:1: ( rule__Field__Group_1_7__2__Impl rule__Field__Group_1_7__3 )
            // InternalArchQualityDef.g:2125:2: rule__Field__Group_1_7__2__Impl rule__Field__Group_1_7__3
            {
            pushFollow(FOLLOW_15);
            rule__Field__Group_1_7__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_7__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_7__2"


    // $ANTLR start "rule__Field__Group_1_7__2__Impl"
    // InternalArchQualityDef.g:2132:1: rule__Field__Group_1_7__2__Impl : ( ( rule__Field__ChapterAssignment_1_7_2 ) ) ;
    public final void rule__Field__Group_1_7__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2136:1: ( ( ( rule__Field__ChapterAssignment_1_7_2 ) ) )
            // InternalArchQualityDef.g:2137:1: ( ( rule__Field__ChapterAssignment_1_7_2 ) )
            {
            // InternalArchQualityDef.g:2137:1: ( ( rule__Field__ChapterAssignment_1_7_2 ) )
            // InternalArchQualityDef.g:2138:2: ( rule__Field__ChapterAssignment_1_7_2 )
            {
             before(grammarAccess.getFieldAccess().getChapterAssignment_1_7_2()); 
            // InternalArchQualityDef.g:2139:2: ( rule__Field__ChapterAssignment_1_7_2 )
            // InternalArchQualityDef.g:2139:3: rule__Field__ChapterAssignment_1_7_2
            {
            pushFollow(FOLLOW_2);
            rule__Field__ChapterAssignment_1_7_2();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getChapterAssignment_1_7_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_7__2__Impl"


    // $ANTLR start "rule__Field__Group_1_7__3"
    // InternalArchQualityDef.g:2147:1: rule__Field__Group_1_7__3 : rule__Field__Group_1_7__3__Impl ;
    public final void rule__Field__Group_1_7__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2151:1: ( rule__Field__Group_1_7__3__Impl )
            // InternalArchQualityDef.g:2152:2: rule__Field__Group_1_7__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Field__Group_1_7__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_7__3"


    // $ANTLR start "rule__Field__Group_1_7__3__Impl"
    // InternalArchQualityDef.g:2158:1: rule__Field__Group_1_7__3__Impl : ( '}' ) ;
    public final void rule__Field__Group_1_7__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2162:1: ( ( '}' ) )
            // InternalArchQualityDef.g:2163:1: ( '}' )
            {
            // InternalArchQualityDef.g:2163:1: ( '}' )
            // InternalArchQualityDef.g:2164:2: '}'
            {
             before(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_7_3()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_7_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_7__3__Impl"


    // $ANTLR start "rule__Field__Group_1_8__0"
    // InternalArchQualityDef.g:2174:1: rule__Field__Group_1_8__0 : rule__Field__Group_1_8__0__Impl rule__Field__Group_1_8__1 ;
    public final void rule__Field__Group_1_8__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2178:1: ( rule__Field__Group_1_8__0__Impl rule__Field__Group_1_8__1 )
            // InternalArchQualityDef.g:2179:2: rule__Field__Group_1_8__0__Impl rule__Field__Group_1_8__1
            {
            pushFollow(FOLLOW_4);
            rule__Field__Group_1_8__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_8__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_8__0"


    // $ANTLR start "rule__Field__Group_1_8__0__Impl"
    // InternalArchQualityDef.g:2186:1: rule__Field__Group_1_8__0__Impl : ( 'series=' ) ;
    public final void rule__Field__Group_1_8__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2190:1: ( ( 'series=' ) )
            // InternalArchQualityDef.g:2191:1: ( 'series=' )
            {
            // InternalArchQualityDef.g:2191:1: ( 'series=' )
            // InternalArchQualityDef.g:2192:2: 'series='
            {
             before(grammarAccess.getFieldAccess().getSeriesKeyword_1_8_0()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getSeriesKeyword_1_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_8__0__Impl"


    // $ANTLR start "rule__Field__Group_1_8__1"
    // InternalArchQualityDef.g:2201:1: rule__Field__Group_1_8__1 : rule__Field__Group_1_8__1__Impl rule__Field__Group_1_8__2 ;
    public final void rule__Field__Group_1_8__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2205:1: ( rule__Field__Group_1_8__1__Impl rule__Field__Group_1_8__2 )
            // InternalArchQualityDef.g:2206:2: rule__Field__Group_1_8__1__Impl rule__Field__Group_1_8__2
            {
            pushFollow(FOLLOW_11);
            rule__Field__Group_1_8__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_8__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_8__1"


    // $ANTLR start "rule__Field__Group_1_8__1__Impl"
    // InternalArchQualityDef.g:2213:1: rule__Field__Group_1_8__1__Impl : ( '{' ) ;
    public final void rule__Field__Group_1_8__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2217:1: ( ( '{' ) )
            // InternalArchQualityDef.g:2218:1: ( '{' )
            {
            // InternalArchQualityDef.g:2218:1: ( '{' )
            // InternalArchQualityDef.g:2219:2: '{'
            {
             before(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_8_1()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_8_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_8__1__Impl"


    // $ANTLR start "rule__Field__Group_1_8__2"
    // InternalArchQualityDef.g:2228:1: rule__Field__Group_1_8__2 : rule__Field__Group_1_8__2__Impl rule__Field__Group_1_8__3 ;
    public final void rule__Field__Group_1_8__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2232:1: ( rule__Field__Group_1_8__2__Impl rule__Field__Group_1_8__3 )
            // InternalArchQualityDef.g:2233:2: rule__Field__Group_1_8__2__Impl rule__Field__Group_1_8__3
            {
            pushFollow(FOLLOW_15);
            rule__Field__Group_1_8__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_8__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_8__2"


    // $ANTLR start "rule__Field__Group_1_8__2__Impl"
    // InternalArchQualityDef.g:2240:1: rule__Field__Group_1_8__2__Impl : ( ( rule__Field__SeriesAssignment_1_8_2 ) ) ;
    public final void rule__Field__Group_1_8__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2244:1: ( ( ( rule__Field__SeriesAssignment_1_8_2 ) ) )
            // InternalArchQualityDef.g:2245:1: ( ( rule__Field__SeriesAssignment_1_8_2 ) )
            {
            // InternalArchQualityDef.g:2245:1: ( ( rule__Field__SeriesAssignment_1_8_2 ) )
            // InternalArchQualityDef.g:2246:2: ( rule__Field__SeriesAssignment_1_8_2 )
            {
             before(grammarAccess.getFieldAccess().getSeriesAssignment_1_8_2()); 
            // InternalArchQualityDef.g:2247:2: ( rule__Field__SeriesAssignment_1_8_2 )
            // InternalArchQualityDef.g:2247:3: rule__Field__SeriesAssignment_1_8_2
            {
            pushFollow(FOLLOW_2);
            rule__Field__SeriesAssignment_1_8_2();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getSeriesAssignment_1_8_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_8__2__Impl"


    // $ANTLR start "rule__Field__Group_1_8__3"
    // InternalArchQualityDef.g:2255:1: rule__Field__Group_1_8__3 : rule__Field__Group_1_8__3__Impl ;
    public final void rule__Field__Group_1_8__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2259:1: ( rule__Field__Group_1_8__3__Impl )
            // InternalArchQualityDef.g:2260:2: rule__Field__Group_1_8__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Field__Group_1_8__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_8__3"


    // $ANTLR start "rule__Field__Group_1_8__3__Impl"
    // InternalArchQualityDef.g:2266:1: rule__Field__Group_1_8__3__Impl : ( '}' ) ;
    public final void rule__Field__Group_1_8__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2270:1: ( ( '}' ) )
            // InternalArchQualityDef.g:2271:1: ( '}' )
            {
            // InternalArchQualityDef.g:2271:1: ( '}' )
            // InternalArchQualityDef.g:2272:2: '}'
            {
             before(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_8_3()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_8_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_8__3__Impl"


    // $ANTLR start "rule__Field__Group_1_9__0"
    // InternalArchQualityDef.g:2282:1: rule__Field__Group_1_9__0 : rule__Field__Group_1_9__0__Impl rule__Field__Group_1_9__1 ;
    public final void rule__Field__Group_1_9__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2286:1: ( rule__Field__Group_1_9__0__Impl rule__Field__Group_1_9__1 )
            // InternalArchQualityDef.g:2287:2: rule__Field__Group_1_9__0__Impl rule__Field__Group_1_9__1
            {
            pushFollow(FOLLOW_4);
            rule__Field__Group_1_9__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_9__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_9__0"


    // $ANTLR start "rule__Field__Group_1_9__0__Impl"
    // InternalArchQualityDef.g:2294:1: rule__Field__Group_1_9__0__Impl : ( 'volume=' ) ;
    public final void rule__Field__Group_1_9__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2298:1: ( ( 'volume=' ) )
            // InternalArchQualityDef.g:2299:1: ( 'volume=' )
            {
            // InternalArchQualityDef.g:2299:1: ( 'volume=' )
            // InternalArchQualityDef.g:2300:2: 'volume='
            {
             before(grammarAccess.getFieldAccess().getVolumeKeyword_1_9_0()); 
            match(input,36,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getVolumeKeyword_1_9_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_9__0__Impl"


    // $ANTLR start "rule__Field__Group_1_9__1"
    // InternalArchQualityDef.g:2309:1: rule__Field__Group_1_9__1 : rule__Field__Group_1_9__1__Impl rule__Field__Group_1_9__2 ;
    public final void rule__Field__Group_1_9__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2313:1: ( rule__Field__Group_1_9__1__Impl rule__Field__Group_1_9__2 )
            // InternalArchQualityDef.g:2314:2: rule__Field__Group_1_9__1__Impl rule__Field__Group_1_9__2
            {
            pushFollow(FOLLOW_11);
            rule__Field__Group_1_9__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_9__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_9__1"


    // $ANTLR start "rule__Field__Group_1_9__1__Impl"
    // InternalArchQualityDef.g:2321:1: rule__Field__Group_1_9__1__Impl : ( '{' ) ;
    public final void rule__Field__Group_1_9__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2325:1: ( ( '{' ) )
            // InternalArchQualityDef.g:2326:1: ( '{' )
            {
            // InternalArchQualityDef.g:2326:1: ( '{' )
            // InternalArchQualityDef.g:2327:2: '{'
            {
             before(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_9_1()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_9_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_9__1__Impl"


    // $ANTLR start "rule__Field__Group_1_9__2"
    // InternalArchQualityDef.g:2336:1: rule__Field__Group_1_9__2 : rule__Field__Group_1_9__2__Impl rule__Field__Group_1_9__3 ;
    public final void rule__Field__Group_1_9__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2340:1: ( rule__Field__Group_1_9__2__Impl rule__Field__Group_1_9__3 )
            // InternalArchQualityDef.g:2341:2: rule__Field__Group_1_9__2__Impl rule__Field__Group_1_9__3
            {
            pushFollow(FOLLOW_15);
            rule__Field__Group_1_9__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_9__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_9__2"


    // $ANTLR start "rule__Field__Group_1_9__2__Impl"
    // InternalArchQualityDef.g:2348:1: rule__Field__Group_1_9__2__Impl : ( ( rule__Field__VolumeAssignment_1_9_2 ) ) ;
    public final void rule__Field__Group_1_9__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2352:1: ( ( ( rule__Field__VolumeAssignment_1_9_2 ) ) )
            // InternalArchQualityDef.g:2353:1: ( ( rule__Field__VolumeAssignment_1_9_2 ) )
            {
            // InternalArchQualityDef.g:2353:1: ( ( rule__Field__VolumeAssignment_1_9_2 ) )
            // InternalArchQualityDef.g:2354:2: ( rule__Field__VolumeAssignment_1_9_2 )
            {
             before(grammarAccess.getFieldAccess().getVolumeAssignment_1_9_2()); 
            // InternalArchQualityDef.g:2355:2: ( rule__Field__VolumeAssignment_1_9_2 )
            // InternalArchQualityDef.g:2355:3: rule__Field__VolumeAssignment_1_9_2
            {
            pushFollow(FOLLOW_2);
            rule__Field__VolumeAssignment_1_9_2();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getVolumeAssignment_1_9_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_9__2__Impl"


    // $ANTLR start "rule__Field__Group_1_9__3"
    // InternalArchQualityDef.g:2363:1: rule__Field__Group_1_9__3 : rule__Field__Group_1_9__3__Impl ;
    public final void rule__Field__Group_1_9__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2367:1: ( rule__Field__Group_1_9__3__Impl )
            // InternalArchQualityDef.g:2368:2: rule__Field__Group_1_9__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Field__Group_1_9__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_9__3"


    // $ANTLR start "rule__Field__Group_1_9__3__Impl"
    // InternalArchQualityDef.g:2374:1: rule__Field__Group_1_9__3__Impl : ( '}' ) ;
    public final void rule__Field__Group_1_9__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2378:1: ( ( '}' ) )
            // InternalArchQualityDef.g:2379:1: ( '}' )
            {
            // InternalArchQualityDef.g:2379:1: ( '}' )
            // InternalArchQualityDef.g:2380:2: '}'
            {
             before(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_9_3()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_9_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_9__3__Impl"


    // $ANTLR start "rule__Field__Group_1_10__0"
    // InternalArchQualityDef.g:2390:1: rule__Field__Group_1_10__0 : rule__Field__Group_1_10__0__Impl rule__Field__Group_1_10__1 ;
    public final void rule__Field__Group_1_10__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2394:1: ( rule__Field__Group_1_10__0__Impl rule__Field__Group_1_10__1 )
            // InternalArchQualityDef.g:2395:2: rule__Field__Group_1_10__0__Impl rule__Field__Group_1_10__1
            {
            pushFollow(FOLLOW_4);
            rule__Field__Group_1_10__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_10__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_10__0"


    // $ANTLR start "rule__Field__Group_1_10__0__Impl"
    // InternalArchQualityDef.g:2402:1: rule__Field__Group_1_10__0__Impl : ( 'editor=' ) ;
    public final void rule__Field__Group_1_10__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2406:1: ( ( 'editor=' ) )
            // InternalArchQualityDef.g:2407:1: ( 'editor=' )
            {
            // InternalArchQualityDef.g:2407:1: ( 'editor=' )
            // InternalArchQualityDef.g:2408:2: 'editor='
            {
             before(grammarAccess.getFieldAccess().getEditorKeyword_1_10_0()); 
            match(input,37,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getEditorKeyword_1_10_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_10__0__Impl"


    // $ANTLR start "rule__Field__Group_1_10__1"
    // InternalArchQualityDef.g:2417:1: rule__Field__Group_1_10__1 : rule__Field__Group_1_10__1__Impl rule__Field__Group_1_10__2 ;
    public final void rule__Field__Group_1_10__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2421:1: ( rule__Field__Group_1_10__1__Impl rule__Field__Group_1_10__2 )
            // InternalArchQualityDef.g:2422:2: rule__Field__Group_1_10__1__Impl rule__Field__Group_1_10__2
            {
            pushFollow(FOLLOW_11);
            rule__Field__Group_1_10__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_10__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_10__1"


    // $ANTLR start "rule__Field__Group_1_10__1__Impl"
    // InternalArchQualityDef.g:2429:1: rule__Field__Group_1_10__1__Impl : ( '{' ) ;
    public final void rule__Field__Group_1_10__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2433:1: ( ( '{' ) )
            // InternalArchQualityDef.g:2434:1: ( '{' )
            {
            // InternalArchQualityDef.g:2434:1: ( '{' )
            // InternalArchQualityDef.g:2435:2: '{'
            {
             before(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_10_1()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_10_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_10__1__Impl"


    // $ANTLR start "rule__Field__Group_1_10__2"
    // InternalArchQualityDef.g:2444:1: rule__Field__Group_1_10__2 : rule__Field__Group_1_10__2__Impl rule__Field__Group_1_10__3 ;
    public final void rule__Field__Group_1_10__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2448:1: ( rule__Field__Group_1_10__2__Impl rule__Field__Group_1_10__3 )
            // InternalArchQualityDef.g:2449:2: rule__Field__Group_1_10__2__Impl rule__Field__Group_1_10__3
            {
            pushFollow(FOLLOW_15);
            rule__Field__Group_1_10__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_10__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_10__2"


    // $ANTLR start "rule__Field__Group_1_10__2__Impl"
    // InternalArchQualityDef.g:2456:1: rule__Field__Group_1_10__2__Impl : ( ( rule__Field__EditorAssignment_1_10_2 ) ) ;
    public final void rule__Field__Group_1_10__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2460:1: ( ( ( rule__Field__EditorAssignment_1_10_2 ) ) )
            // InternalArchQualityDef.g:2461:1: ( ( rule__Field__EditorAssignment_1_10_2 ) )
            {
            // InternalArchQualityDef.g:2461:1: ( ( rule__Field__EditorAssignment_1_10_2 ) )
            // InternalArchQualityDef.g:2462:2: ( rule__Field__EditorAssignment_1_10_2 )
            {
             before(grammarAccess.getFieldAccess().getEditorAssignment_1_10_2()); 
            // InternalArchQualityDef.g:2463:2: ( rule__Field__EditorAssignment_1_10_2 )
            // InternalArchQualityDef.g:2463:3: rule__Field__EditorAssignment_1_10_2
            {
            pushFollow(FOLLOW_2);
            rule__Field__EditorAssignment_1_10_2();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getEditorAssignment_1_10_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_10__2__Impl"


    // $ANTLR start "rule__Field__Group_1_10__3"
    // InternalArchQualityDef.g:2471:1: rule__Field__Group_1_10__3 : rule__Field__Group_1_10__3__Impl ;
    public final void rule__Field__Group_1_10__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2475:1: ( rule__Field__Group_1_10__3__Impl )
            // InternalArchQualityDef.g:2476:2: rule__Field__Group_1_10__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Field__Group_1_10__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_10__3"


    // $ANTLR start "rule__Field__Group_1_10__3__Impl"
    // InternalArchQualityDef.g:2482:1: rule__Field__Group_1_10__3__Impl : ( '}' ) ;
    public final void rule__Field__Group_1_10__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2486:1: ( ( '}' ) )
            // InternalArchQualityDef.g:2487:1: ( '}' )
            {
            // InternalArchQualityDef.g:2487:1: ( '}' )
            // InternalArchQualityDef.g:2488:2: '}'
            {
             before(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_10_3()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_10_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_10__3__Impl"


    // $ANTLR start "rule__Field__Group_1_11__0"
    // InternalArchQualityDef.g:2498:1: rule__Field__Group_1_11__0 : rule__Field__Group_1_11__0__Impl rule__Field__Group_1_11__1 ;
    public final void rule__Field__Group_1_11__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2502:1: ( rule__Field__Group_1_11__0__Impl rule__Field__Group_1_11__1 )
            // InternalArchQualityDef.g:2503:2: rule__Field__Group_1_11__0__Impl rule__Field__Group_1_11__1
            {
            pushFollow(FOLLOW_4);
            rule__Field__Group_1_11__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_11__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_11__0"


    // $ANTLR start "rule__Field__Group_1_11__0__Impl"
    // InternalArchQualityDef.g:2510:1: rule__Field__Group_1_11__0__Impl : ( 'organization=' ) ;
    public final void rule__Field__Group_1_11__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2514:1: ( ( 'organization=' ) )
            // InternalArchQualityDef.g:2515:1: ( 'organization=' )
            {
            // InternalArchQualityDef.g:2515:1: ( 'organization=' )
            // InternalArchQualityDef.g:2516:2: 'organization='
            {
             before(grammarAccess.getFieldAccess().getOrganizationKeyword_1_11_0()); 
            match(input,38,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getOrganizationKeyword_1_11_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_11__0__Impl"


    // $ANTLR start "rule__Field__Group_1_11__1"
    // InternalArchQualityDef.g:2525:1: rule__Field__Group_1_11__1 : rule__Field__Group_1_11__1__Impl rule__Field__Group_1_11__2 ;
    public final void rule__Field__Group_1_11__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2529:1: ( rule__Field__Group_1_11__1__Impl rule__Field__Group_1_11__2 )
            // InternalArchQualityDef.g:2530:2: rule__Field__Group_1_11__1__Impl rule__Field__Group_1_11__2
            {
            pushFollow(FOLLOW_11);
            rule__Field__Group_1_11__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_11__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_11__1"


    // $ANTLR start "rule__Field__Group_1_11__1__Impl"
    // InternalArchQualityDef.g:2537:1: rule__Field__Group_1_11__1__Impl : ( '{' ) ;
    public final void rule__Field__Group_1_11__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2541:1: ( ( '{' ) )
            // InternalArchQualityDef.g:2542:1: ( '{' )
            {
            // InternalArchQualityDef.g:2542:1: ( '{' )
            // InternalArchQualityDef.g:2543:2: '{'
            {
             before(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_11_1()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_11_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_11__1__Impl"


    // $ANTLR start "rule__Field__Group_1_11__2"
    // InternalArchQualityDef.g:2552:1: rule__Field__Group_1_11__2 : rule__Field__Group_1_11__2__Impl rule__Field__Group_1_11__3 ;
    public final void rule__Field__Group_1_11__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2556:1: ( rule__Field__Group_1_11__2__Impl rule__Field__Group_1_11__3 )
            // InternalArchQualityDef.g:2557:2: rule__Field__Group_1_11__2__Impl rule__Field__Group_1_11__3
            {
            pushFollow(FOLLOW_15);
            rule__Field__Group_1_11__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_11__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_11__2"


    // $ANTLR start "rule__Field__Group_1_11__2__Impl"
    // InternalArchQualityDef.g:2564:1: rule__Field__Group_1_11__2__Impl : ( ( rule__Field__OrganizationAssignment_1_11_2 ) ) ;
    public final void rule__Field__Group_1_11__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2568:1: ( ( ( rule__Field__OrganizationAssignment_1_11_2 ) ) )
            // InternalArchQualityDef.g:2569:1: ( ( rule__Field__OrganizationAssignment_1_11_2 ) )
            {
            // InternalArchQualityDef.g:2569:1: ( ( rule__Field__OrganizationAssignment_1_11_2 ) )
            // InternalArchQualityDef.g:2570:2: ( rule__Field__OrganizationAssignment_1_11_2 )
            {
             before(grammarAccess.getFieldAccess().getOrganizationAssignment_1_11_2()); 
            // InternalArchQualityDef.g:2571:2: ( rule__Field__OrganizationAssignment_1_11_2 )
            // InternalArchQualityDef.g:2571:3: rule__Field__OrganizationAssignment_1_11_2
            {
            pushFollow(FOLLOW_2);
            rule__Field__OrganizationAssignment_1_11_2();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getOrganizationAssignment_1_11_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_11__2__Impl"


    // $ANTLR start "rule__Field__Group_1_11__3"
    // InternalArchQualityDef.g:2579:1: rule__Field__Group_1_11__3 : rule__Field__Group_1_11__3__Impl ;
    public final void rule__Field__Group_1_11__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2583:1: ( rule__Field__Group_1_11__3__Impl )
            // InternalArchQualityDef.g:2584:2: rule__Field__Group_1_11__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Field__Group_1_11__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_11__3"


    // $ANTLR start "rule__Field__Group_1_11__3__Impl"
    // InternalArchQualityDef.g:2590:1: rule__Field__Group_1_11__3__Impl : ( '}' ) ;
    public final void rule__Field__Group_1_11__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2594:1: ( ( '}' ) )
            // InternalArchQualityDef.g:2595:1: ( '}' )
            {
            // InternalArchQualityDef.g:2595:1: ( '}' )
            // InternalArchQualityDef.g:2596:2: '}'
            {
             before(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_11_3()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_11_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_11__3__Impl"


    // $ANTLR start "rule__Field__Group_1_12__0"
    // InternalArchQualityDef.g:2606:1: rule__Field__Group_1_12__0 : rule__Field__Group_1_12__0__Impl rule__Field__Group_1_12__1 ;
    public final void rule__Field__Group_1_12__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2610:1: ( rule__Field__Group_1_12__0__Impl rule__Field__Group_1_12__1 )
            // InternalArchQualityDef.g:2611:2: rule__Field__Group_1_12__0__Impl rule__Field__Group_1_12__1
            {
            pushFollow(FOLLOW_4);
            rule__Field__Group_1_12__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_12__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_12__0"


    // $ANTLR start "rule__Field__Group_1_12__0__Impl"
    // InternalArchQualityDef.g:2618:1: rule__Field__Group_1_12__0__Impl : ( 'note=' ) ;
    public final void rule__Field__Group_1_12__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2622:1: ( ( 'note=' ) )
            // InternalArchQualityDef.g:2623:1: ( 'note=' )
            {
            // InternalArchQualityDef.g:2623:1: ( 'note=' )
            // InternalArchQualityDef.g:2624:2: 'note='
            {
             before(grammarAccess.getFieldAccess().getNoteKeyword_1_12_0()); 
            match(input,39,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getNoteKeyword_1_12_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_12__0__Impl"


    // $ANTLR start "rule__Field__Group_1_12__1"
    // InternalArchQualityDef.g:2633:1: rule__Field__Group_1_12__1 : rule__Field__Group_1_12__1__Impl rule__Field__Group_1_12__2 ;
    public final void rule__Field__Group_1_12__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2637:1: ( rule__Field__Group_1_12__1__Impl rule__Field__Group_1_12__2 )
            // InternalArchQualityDef.g:2638:2: rule__Field__Group_1_12__1__Impl rule__Field__Group_1_12__2
            {
            pushFollow(FOLLOW_16);
            rule__Field__Group_1_12__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_12__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_12__1"


    // $ANTLR start "rule__Field__Group_1_12__1__Impl"
    // InternalArchQualityDef.g:2645:1: rule__Field__Group_1_12__1__Impl : ( '{' ) ;
    public final void rule__Field__Group_1_12__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2649:1: ( ( '{' ) )
            // InternalArchQualityDef.g:2650:1: ( '{' )
            {
            // InternalArchQualityDef.g:2650:1: ( '{' )
            // InternalArchQualityDef.g:2651:2: '{'
            {
             before(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_12_1()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getLeftCurlyBracketKeyword_1_12_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_12__1__Impl"


    // $ANTLR start "rule__Field__Group_1_12__2"
    // InternalArchQualityDef.g:2660:1: rule__Field__Group_1_12__2 : rule__Field__Group_1_12__2__Impl rule__Field__Group_1_12__3 ;
    public final void rule__Field__Group_1_12__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2664:1: ( rule__Field__Group_1_12__2__Impl rule__Field__Group_1_12__3 )
            // InternalArchQualityDef.g:2665:2: rule__Field__Group_1_12__2__Impl rule__Field__Group_1_12__3
            {
            pushFollow(FOLLOW_17);
            rule__Field__Group_1_12__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_12__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_12__2"


    // $ANTLR start "rule__Field__Group_1_12__2__Impl"
    // InternalArchQualityDef.g:2672:1: rule__Field__Group_1_12__2__Impl : ( 'Cited' ) ;
    public final void rule__Field__Group_1_12__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2676:1: ( ( 'Cited' ) )
            // InternalArchQualityDef.g:2677:1: ( 'Cited' )
            {
            // InternalArchQualityDef.g:2677:1: ( 'Cited' )
            // InternalArchQualityDef.g:2678:2: 'Cited'
            {
             before(grammarAccess.getFieldAccess().getCitedKeyword_1_12_2()); 
            match(input,40,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getCitedKeyword_1_12_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_12__2__Impl"


    // $ANTLR start "rule__Field__Group_1_12__3"
    // InternalArchQualityDef.g:2687:1: rule__Field__Group_1_12__3 : rule__Field__Group_1_12__3__Impl rule__Field__Group_1_12__4 ;
    public final void rule__Field__Group_1_12__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2691:1: ( rule__Field__Group_1_12__3__Impl rule__Field__Group_1_12__4 )
            // InternalArchQualityDef.g:2692:2: rule__Field__Group_1_12__3__Impl rule__Field__Group_1_12__4
            {
            pushFollow(FOLLOW_18);
            rule__Field__Group_1_12__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_12__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_12__3"


    // $ANTLR start "rule__Field__Group_1_12__3__Impl"
    // InternalArchQualityDef.g:2699:1: rule__Field__Group_1_12__3__Impl : ( 'by:' ) ;
    public final void rule__Field__Group_1_12__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2703:1: ( ( 'by:' ) )
            // InternalArchQualityDef.g:2704:1: ( 'by:' )
            {
            // InternalArchQualityDef.g:2704:1: ( 'by:' )
            // InternalArchQualityDef.g:2705:2: 'by:'
            {
             before(grammarAccess.getFieldAccess().getByKeyword_1_12_3()); 
            match(input,41,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getByKeyword_1_12_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_12__3__Impl"


    // $ANTLR start "rule__Field__Group_1_12__4"
    // InternalArchQualityDef.g:2714:1: rule__Field__Group_1_12__4 : rule__Field__Group_1_12__4__Impl rule__Field__Group_1_12__5 ;
    public final void rule__Field__Group_1_12__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2718:1: ( rule__Field__Group_1_12__4__Impl rule__Field__Group_1_12__5 )
            // InternalArchQualityDef.g:2719:2: rule__Field__Group_1_12__4__Impl rule__Field__Group_1_12__5
            {
            pushFollow(FOLLOW_15);
            rule__Field__Group_1_12__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Field__Group_1_12__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_12__4"


    // $ANTLR start "rule__Field__Group_1_12__4__Impl"
    // InternalArchQualityDef.g:2726:1: rule__Field__Group_1_12__4__Impl : ( ( rule__Field__CitationscountAssignment_1_12_4 ) ) ;
    public final void rule__Field__Group_1_12__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2730:1: ( ( ( rule__Field__CitationscountAssignment_1_12_4 ) ) )
            // InternalArchQualityDef.g:2731:1: ( ( rule__Field__CitationscountAssignment_1_12_4 ) )
            {
            // InternalArchQualityDef.g:2731:1: ( ( rule__Field__CitationscountAssignment_1_12_4 ) )
            // InternalArchQualityDef.g:2732:2: ( rule__Field__CitationscountAssignment_1_12_4 )
            {
             before(grammarAccess.getFieldAccess().getCitationscountAssignment_1_12_4()); 
            // InternalArchQualityDef.g:2733:2: ( rule__Field__CitationscountAssignment_1_12_4 )
            // InternalArchQualityDef.g:2733:3: rule__Field__CitationscountAssignment_1_12_4
            {
            pushFollow(FOLLOW_2);
            rule__Field__CitationscountAssignment_1_12_4();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getCitationscountAssignment_1_12_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_12__4__Impl"


    // $ANTLR start "rule__Field__Group_1_12__5"
    // InternalArchQualityDef.g:2741:1: rule__Field__Group_1_12__5 : rule__Field__Group_1_12__5__Impl ;
    public final void rule__Field__Group_1_12__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2745:1: ( rule__Field__Group_1_12__5__Impl )
            // InternalArchQualityDef.g:2746:2: rule__Field__Group_1_12__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Field__Group_1_12__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_12__5"


    // $ANTLR start "rule__Field__Group_1_12__5__Impl"
    // InternalArchQualityDef.g:2752:1: rule__Field__Group_1_12__5__Impl : ( '}' ) ;
    public final void rule__Field__Group_1_12__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2756:1: ( ( '}' ) )
            // InternalArchQualityDef.g:2757:1: ( '}' )
            {
            // InternalArchQualityDef.g:2757:1: ( '}' )
            // InternalArchQualityDef.g:2758:2: '}'
            {
             before(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_12_5()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getRightCurlyBracketKeyword_1_12_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Group_1_12__5__Impl"


    // $ANTLR start "rule__ResearchContribution__Group__0"
    // InternalArchQualityDef.g:2768:1: rule__ResearchContribution__Group__0 : rule__ResearchContribution__Group__0__Impl rule__ResearchContribution__Group__1 ;
    public final void rule__ResearchContribution__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2772:1: ( rule__ResearchContribution__Group__0__Impl rule__ResearchContribution__Group__1 )
            // InternalArchQualityDef.g:2773:2: rule__ResearchContribution__Group__0__Impl rule__ResearchContribution__Group__1
            {
            pushFollow(FOLLOW_7);
            rule__ResearchContribution__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ResearchContribution__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group__0"


    // $ANTLR start "rule__ResearchContribution__Group__0__Impl"
    // InternalArchQualityDef.g:2780:1: rule__ResearchContribution__Group__0__Impl : ( () ) ;
    public final void rule__ResearchContribution__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2784:1: ( ( () ) )
            // InternalArchQualityDef.g:2785:1: ( () )
            {
            // InternalArchQualityDef.g:2785:1: ( () )
            // InternalArchQualityDef.g:2786:2: ()
            {
             before(grammarAccess.getResearchContributionAccess().getResearchContributionAction_0()); 
            // InternalArchQualityDef.g:2787:2: ()
            // InternalArchQualityDef.g:2787:3: 
            {
            }

             after(grammarAccess.getResearchContributionAccess().getResearchContributionAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group__0__Impl"


    // $ANTLR start "rule__ResearchContribution__Group__1"
    // InternalArchQualityDef.g:2795:1: rule__ResearchContribution__Group__1 : rule__ResearchContribution__Group__1__Impl rule__ResearchContribution__Group__2 ;
    public final void rule__ResearchContribution__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2799:1: ( rule__ResearchContribution__Group__1__Impl rule__ResearchContribution__Group__2 )
            // InternalArchQualityDef.g:2800:2: rule__ResearchContribution__Group__1__Impl rule__ResearchContribution__Group__2
            {
            pushFollow(FOLLOW_19);
            rule__ResearchContribution__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ResearchContribution__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group__1"


    // $ANTLR start "rule__ResearchContribution__Group__1__Impl"
    // InternalArchQualityDef.g:2807:1: rule__ResearchContribution__Group__1__Impl : ( '@' ) ;
    public final void rule__ResearchContribution__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2811:1: ( ( '@' ) )
            // InternalArchQualityDef.g:2812:1: ( '@' )
            {
            // InternalArchQualityDef.g:2812:1: ( '@' )
            // InternalArchQualityDef.g:2813:2: '@'
            {
             before(grammarAccess.getResearchContributionAccess().getCommercialAtKeyword_1()); 
            match(input,42,FOLLOW_2); 
             after(grammarAccess.getResearchContributionAccess().getCommercialAtKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group__1__Impl"


    // $ANTLR start "rule__ResearchContribution__Group__2"
    // InternalArchQualityDef.g:2822:1: rule__ResearchContribution__Group__2 : rule__ResearchContribution__Group__2__Impl rule__ResearchContribution__Group__3 ;
    public final void rule__ResearchContribution__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2826:1: ( rule__ResearchContribution__Group__2__Impl rule__ResearchContribution__Group__3 )
            // InternalArchQualityDef.g:2827:2: rule__ResearchContribution__Group__2__Impl rule__ResearchContribution__Group__3
            {
            pushFollow(FOLLOW_4);
            rule__ResearchContribution__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ResearchContribution__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group__2"


    // $ANTLR start "rule__ResearchContribution__Group__2__Impl"
    // InternalArchQualityDef.g:2834:1: rule__ResearchContribution__Group__2__Impl : ( ( rule__ResearchContribution__Alternatives_2 ) ) ;
    public final void rule__ResearchContribution__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2838:1: ( ( ( rule__ResearchContribution__Alternatives_2 ) ) )
            // InternalArchQualityDef.g:2839:1: ( ( rule__ResearchContribution__Alternatives_2 ) )
            {
            // InternalArchQualityDef.g:2839:1: ( ( rule__ResearchContribution__Alternatives_2 ) )
            // InternalArchQualityDef.g:2840:2: ( rule__ResearchContribution__Alternatives_2 )
            {
             before(grammarAccess.getResearchContributionAccess().getAlternatives_2()); 
            // InternalArchQualityDef.g:2841:2: ( rule__ResearchContribution__Alternatives_2 )
            // InternalArchQualityDef.g:2841:3: rule__ResearchContribution__Alternatives_2
            {
            pushFollow(FOLLOW_2);
            rule__ResearchContribution__Alternatives_2();

            state._fsp--;


            }

             after(grammarAccess.getResearchContributionAccess().getAlternatives_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group__2__Impl"


    // $ANTLR start "rule__ResearchContribution__Group__3"
    // InternalArchQualityDef.g:2849:1: rule__ResearchContribution__Group__3 : rule__ResearchContribution__Group__3__Impl rule__ResearchContribution__Group__4 ;
    public final void rule__ResearchContribution__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2853:1: ( rule__ResearchContribution__Group__3__Impl rule__ResearchContribution__Group__4 )
            // InternalArchQualityDef.g:2854:2: rule__ResearchContribution__Group__3__Impl rule__ResearchContribution__Group__4
            {
            pushFollow(FOLLOW_20);
            rule__ResearchContribution__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ResearchContribution__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group__3"


    // $ANTLR start "rule__ResearchContribution__Group__3__Impl"
    // InternalArchQualityDef.g:2861:1: rule__ResearchContribution__Group__3__Impl : ( '{' ) ;
    public final void rule__ResearchContribution__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2865:1: ( ( '{' ) )
            // InternalArchQualityDef.g:2866:1: ( '{' )
            {
            // InternalArchQualityDef.g:2866:1: ( '{' )
            // InternalArchQualityDef.g:2867:2: '{'
            {
             before(grammarAccess.getResearchContributionAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getResearchContributionAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group__3__Impl"


    // $ANTLR start "rule__ResearchContribution__Group__4"
    // InternalArchQualityDef.g:2876:1: rule__ResearchContribution__Group__4 : rule__ResearchContribution__Group__4__Impl rule__ResearchContribution__Group__5 ;
    public final void rule__ResearchContribution__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2880:1: ( rule__ResearchContribution__Group__4__Impl rule__ResearchContribution__Group__5 )
            // InternalArchQualityDef.g:2881:2: rule__ResearchContribution__Group__4__Impl rule__ResearchContribution__Group__5
            {
            pushFollow(FOLLOW_21);
            rule__ResearchContribution__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ResearchContribution__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group__4"


    // $ANTLR start "rule__ResearchContribution__Group__4__Impl"
    // InternalArchQualityDef.g:2888:1: rule__ResearchContribution__Group__4__Impl : ( ( rule__ResearchContribution__NameAssignment_4 ) ) ;
    public final void rule__ResearchContribution__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2892:1: ( ( ( rule__ResearchContribution__NameAssignment_4 ) ) )
            // InternalArchQualityDef.g:2893:1: ( ( rule__ResearchContribution__NameAssignment_4 ) )
            {
            // InternalArchQualityDef.g:2893:1: ( ( rule__ResearchContribution__NameAssignment_4 ) )
            // InternalArchQualityDef.g:2894:2: ( rule__ResearchContribution__NameAssignment_4 )
            {
             before(grammarAccess.getResearchContributionAccess().getNameAssignment_4()); 
            // InternalArchQualityDef.g:2895:2: ( rule__ResearchContribution__NameAssignment_4 )
            // InternalArchQualityDef.g:2895:3: rule__ResearchContribution__NameAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__ResearchContribution__NameAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getResearchContributionAccess().getNameAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group__4__Impl"


    // $ANTLR start "rule__ResearchContribution__Group__5"
    // InternalArchQualityDef.g:2903:1: rule__ResearchContribution__Group__5 : rule__ResearchContribution__Group__5__Impl rule__ResearchContribution__Group__6 ;
    public final void rule__ResearchContribution__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2907:1: ( rule__ResearchContribution__Group__5__Impl rule__ResearchContribution__Group__6 )
            // InternalArchQualityDef.g:2908:2: rule__ResearchContribution__Group__5__Impl rule__ResearchContribution__Group__6
            {
            pushFollow(FOLLOW_12);
            rule__ResearchContribution__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ResearchContribution__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group__5"


    // $ANTLR start "rule__ResearchContribution__Group__5__Impl"
    // InternalArchQualityDef.g:2915:1: rule__ResearchContribution__Group__5__Impl : ( ',' ) ;
    public final void rule__ResearchContribution__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2919:1: ( ( ',' ) )
            // InternalArchQualityDef.g:2920:1: ( ',' )
            {
            // InternalArchQualityDef.g:2920:1: ( ',' )
            // InternalArchQualityDef.g:2921:2: ','
            {
             before(grammarAccess.getResearchContributionAccess().getCommaKeyword_5()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getResearchContributionAccess().getCommaKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group__5__Impl"


    // $ANTLR start "rule__ResearchContribution__Group__6"
    // InternalArchQualityDef.g:2930:1: rule__ResearchContribution__Group__6 : rule__ResearchContribution__Group__6__Impl rule__ResearchContribution__Group__7 ;
    public final void rule__ResearchContribution__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2934:1: ( rule__ResearchContribution__Group__6__Impl rule__ResearchContribution__Group__7 )
            // InternalArchQualityDef.g:2935:2: rule__ResearchContribution__Group__6__Impl rule__ResearchContribution__Group__7
            {
            pushFollow(FOLLOW_15);
            rule__ResearchContribution__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ResearchContribution__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group__6"


    // $ANTLR start "rule__ResearchContribution__Group__6__Impl"
    // InternalArchQualityDef.g:2942:1: rule__ResearchContribution__Group__6__Impl : ( ( rule__ResearchContribution__Group_6__0 ) ) ;
    public final void rule__ResearchContribution__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2946:1: ( ( ( rule__ResearchContribution__Group_6__0 ) ) )
            // InternalArchQualityDef.g:2947:1: ( ( rule__ResearchContribution__Group_6__0 ) )
            {
            // InternalArchQualityDef.g:2947:1: ( ( rule__ResearchContribution__Group_6__0 ) )
            // InternalArchQualityDef.g:2948:2: ( rule__ResearchContribution__Group_6__0 )
            {
             before(grammarAccess.getResearchContributionAccess().getGroup_6()); 
            // InternalArchQualityDef.g:2949:2: ( rule__ResearchContribution__Group_6__0 )
            // InternalArchQualityDef.g:2949:3: rule__ResearchContribution__Group_6__0
            {
            pushFollow(FOLLOW_2);
            rule__ResearchContribution__Group_6__0();

            state._fsp--;


            }

             after(grammarAccess.getResearchContributionAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group__6__Impl"


    // $ANTLR start "rule__ResearchContribution__Group__7"
    // InternalArchQualityDef.g:2957:1: rule__ResearchContribution__Group__7 : rule__ResearchContribution__Group__7__Impl ;
    public final void rule__ResearchContribution__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2961:1: ( rule__ResearchContribution__Group__7__Impl )
            // InternalArchQualityDef.g:2962:2: rule__ResearchContribution__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ResearchContribution__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group__7"


    // $ANTLR start "rule__ResearchContribution__Group__7__Impl"
    // InternalArchQualityDef.g:2968:1: rule__ResearchContribution__Group__7__Impl : ( '}' ) ;
    public final void rule__ResearchContribution__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2972:1: ( ( '}' ) )
            // InternalArchQualityDef.g:2973:1: ( '}' )
            {
            // InternalArchQualityDef.g:2973:1: ( '}' )
            // InternalArchQualityDef.g:2974:2: '}'
            {
             before(grammarAccess.getResearchContributionAccess().getRightCurlyBracketKeyword_7()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getResearchContributionAccess().getRightCurlyBracketKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group__7__Impl"


    // $ANTLR start "rule__ResearchContribution__Group_6__0"
    // InternalArchQualityDef.g:2984:1: rule__ResearchContribution__Group_6__0 : rule__ResearchContribution__Group_6__0__Impl rule__ResearchContribution__Group_6__1 ;
    public final void rule__ResearchContribution__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:2988:1: ( rule__ResearchContribution__Group_6__0__Impl rule__ResearchContribution__Group_6__1 )
            // InternalArchQualityDef.g:2989:2: rule__ResearchContribution__Group_6__0__Impl rule__ResearchContribution__Group_6__1
            {
            pushFollow(FOLLOW_21);
            rule__ResearchContribution__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ResearchContribution__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group_6__0"


    // $ANTLR start "rule__ResearchContribution__Group_6__0__Impl"
    // InternalArchQualityDef.g:2996:1: rule__ResearchContribution__Group_6__0__Impl : ( ( rule__ResearchContribution__FieldsAssignment_6_0 ) ) ;
    public final void rule__ResearchContribution__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3000:1: ( ( ( rule__ResearchContribution__FieldsAssignment_6_0 ) ) )
            // InternalArchQualityDef.g:3001:1: ( ( rule__ResearchContribution__FieldsAssignment_6_0 ) )
            {
            // InternalArchQualityDef.g:3001:1: ( ( rule__ResearchContribution__FieldsAssignment_6_0 ) )
            // InternalArchQualityDef.g:3002:2: ( rule__ResearchContribution__FieldsAssignment_6_0 )
            {
             before(grammarAccess.getResearchContributionAccess().getFieldsAssignment_6_0()); 
            // InternalArchQualityDef.g:3003:2: ( rule__ResearchContribution__FieldsAssignment_6_0 )
            // InternalArchQualityDef.g:3003:3: rule__ResearchContribution__FieldsAssignment_6_0
            {
            pushFollow(FOLLOW_2);
            rule__ResearchContribution__FieldsAssignment_6_0();

            state._fsp--;


            }

             after(grammarAccess.getResearchContributionAccess().getFieldsAssignment_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group_6__0__Impl"


    // $ANTLR start "rule__ResearchContribution__Group_6__1"
    // InternalArchQualityDef.g:3011:1: rule__ResearchContribution__Group_6__1 : rule__ResearchContribution__Group_6__1__Impl ;
    public final void rule__ResearchContribution__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3015:1: ( rule__ResearchContribution__Group_6__1__Impl )
            // InternalArchQualityDef.g:3016:2: rule__ResearchContribution__Group_6__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ResearchContribution__Group_6__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group_6__1"


    // $ANTLR start "rule__ResearchContribution__Group_6__1__Impl"
    // InternalArchQualityDef.g:3022:1: rule__ResearchContribution__Group_6__1__Impl : ( ( rule__ResearchContribution__Group_6_1__0 )* ) ;
    public final void rule__ResearchContribution__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3026:1: ( ( ( rule__ResearchContribution__Group_6_1__0 )* ) )
            // InternalArchQualityDef.g:3027:1: ( ( rule__ResearchContribution__Group_6_1__0 )* )
            {
            // InternalArchQualityDef.g:3027:1: ( ( rule__ResearchContribution__Group_6_1__0 )* )
            // InternalArchQualityDef.g:3028:2: ( rule__ResearchContribution__Group_6_1__0 )*
            {
             before(grammarAccess.getResearchContributionAccess().getGroup_6_1()); 
            // InternalArchQualityDef.g:3029:2: ( rule__ResearchContribution__Group_6_1__0 )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( (LA21_0==23) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // InternalArchQualityDef.g:3029:3: rule__ResearchContribution__Group_6_1__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__ResearchContribution__Group_6_1__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);

             after(grammarAccess.getResearchContributionAccess().getGroup_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group_6__1__Impl"


    // $ANTLR start "rule__ResearchContribution__Group_6_1__0"
    // InternalArchQualityDef.g:3038:1: rule__ResearchContribution__Group_6_1__0 : rule__ResearchContribution__Group_6_1__0__Impl rule__ResearchContribution__Group_6_1__1 ;
    public final void rule__ResearchContribution__Group_6_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3042:1: ( rule__ResearchContribution__Group_6_1__0__Impl rule__ResearchContribution__Group_6_1__1 )
            // InternalArchQualityDef.g:3043:2: rule__ResearchContribution__Group_6_1__0__Impl rule__ResearchContribution__Group_6_1__1
            {
            pushFollow(FOLLOW_12);
            rule__ResearchContribution__Group_6_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ResearchContribution__Group_6_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group_6_1__0"


    // $ANTLR start "rule__ResearchContribution__Group_6_1__0__Impl"
    // InternalArchQualityDef.g:3050:1: rule__ResearchContribution__Group_6_1__0__Impl : ( ',' ) ;
    public final void rule__ResearchContribution__Group_6_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3054:1: ( ( ',' ) )
            // InternalArchQualityDef.g:3055:1: ( ',' )
            {
            // InternalArchQualityDef.g:3055:1: ( ',' )
            // InternalArchQualityDef.g:3056:2: ','
            {
             before(grammarAccess.getResearchContributionAccess().getCommaKeyword_6_1_0()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getResearchContributionAccess().getCommaKeyword_6_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group_6_1__0__Impl"


    // $ANTLR start "rule__ResearchContribution__Group_6_1__1"
    // InternalArchQualityDef.g:3065:1: rule__ResearchContribution__Group_6_1__1 : rule__ResearchContribution__Group_6_1__1__Impl ;
    public final void rule__ResearchContribution__Group_6_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3069:1: ( rule__ResearchContribution__Group_6_1__1__Impl )
            // InternalArchQualityDef.g:3070:2: rule__ResearchContribution__Group_6_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ResearchContribution__Group_6_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group_6_1__1"


    // $ANTLR start "rule__ResearchContribution__Group_6_1__1__Impl"
    // InternalArchQualityDef.g:3076:1: rule__ResearchContribution__Group_6_1__1__Impl : ( ( rule__ResearchContribution__FieldsAssignment_6_1_1 ) ) ;
    public final void rule__ResearchContribution__Group_6_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3080:1: ( ( ( rule__ResearchContribution__FieldsAssignment_6_1_1 ) ) )
            // InternalArchQualityDef.g:3081:1: ( ( rule__ResearchContribution__FieldsAssignment_6_1_1 ) )
            {
            // InternalArchQualityDef.g:3081:1: ( ( rule__ResearchContribution__FieldsAssignment_6_1_1 ) )
            // InternalArchQualityDef.g:3082:2: ( rule__ResearchContribution__FieldsAssignment_6_1_1 )
            {
             before(grammarAccess.getResearchContributionAccess().getFieldsAssignment_6_1_1()); 
            // InternalArchQualityDef.g:3083:2: ( rule__ResearchContribution__FieldsAssignment_6_1_1 )
            // InternalArchQualityDef.g:3083:3: rule__ResearchContribution__FieldsAssignment_6_1_1
            {
            pushFollow(FOLLOW_2);
            rule__ResearchContribution__FieldsAssignment_6_1_1();

            state._fsp--;


            }

             after(grammarAccess.getResearchContributionAccess().getFieldsAssignment_6_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__Group_6_1__1__Impl"


    // $ANTLR start "rule__Metric__Group__0"
    // InternalArchQualityDef.g:3092:1: rule__Metric__Group__0 : rule__Metric__Group__0__Impl rule__Metric__Group__1 ;
    public final void rule__Metric__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3096:1: ( rule__Metric__Group__0__Impl rule__Metric__Group__1 )
            // InternalArchQualityDef.g:3097:2: rule__Metric__Group__0__Impl rule__Metric__Group__1
            {
            pushFollow(FOLLOW_20);
            rule__Metric__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Metric__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group__0"


    // $ANTLR start "rule__Metric__Group__0__Impl"
    // InternalArchQualityDef.g:3104:1: rule__Metric__Group__0__Impl : ( 'Metric' ) ;
    public final void rule__Metric__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3108:1: ( ( 'Metric' ) )
            // InternalArchQualityDef.g:3109:1: ( 'Metric' )
            {
            // InternalArchQualityDef.g:3109:1: ( 'Metric' )
            // InternalArchQualityDef.g:3110:2: 'Metric'
            {
             before(grammarAccess.getMetricAccess().getMetricKeyword_0()); 
            match(input,43,FOLLOW_2); 
             after(grammarAccess.getMetricAccess().getMetricKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group__0__Impl"


    // $ANTLR start "rule__Metric__Group__1"
    // InternalArchQualityDef.g:3119:1: rule__Metric__Group__1 : rule__Metric__Group__1__Impl rule__Metric__Group__2 ;
    public final void rule__Metric__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3123:1: ( rule__Metric__Group__1__Impl rule__Metric__Group__2 )
            // InternalArchQualityDef.g:3124:2: rule__Metric__Group__1__Impl rule__Metric__Group__2
            {
            pushFollow(FOLLOW_22);
            rule__Metric__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Metric__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group__1"


    // $ANTLR start "rule__Metric__Group__1__Impl"
    // InternalArchQualityDef.g:3131:1: rule__Metric__Group__1__Impl : ( ( rule__Metric__NameAssignment_1 ) ) ;
    public final void rule__Metric__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3135:1: ( ( ( rule__Metric__NameAssignment_1 ) ) )
            // InternalArchQualityDef.g:3136:1: ( ( rule__Metric__NameAssignment_1 ) )
            {
            // InternalArchQualityDef.g:3136:1: ( ( rule__Metric__NameAssignment_1 ) )
            // InternalArchQualityDef.g:3137:2: ( rule__Metric__NameAssignment_1 )
            {
             before(grammarAccess.getMetricAccess().getNameAssignment_1()); 
            // InternalArchQualityDef.g:3138:2: ( rule__Metric__NameAssignment_1 )
            // InternalArchQualityDef.g:3138:3: rule__Metric__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Metric__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getMetricAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group__1__Impl"


    // $ANTLR start "rule__Metric__Group__2"
    // InternalArchQualityDef.g:3146:1: rule__Metric__Group__2 : rule__Metric__Group__2__Impl rule__Metric__Group__3 ;
    public final void rule__Metric__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3150:1: ( rule__Metric__Group__2__Impl rule__Metric__Group__3 )
            // InternalArchQualityDef.g:3151:2: rule__Metric__Group__2__Impl rule__Metric__Group__3
            {
            pushFollow(FOLLOW_22);
            rule__Metric__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Metric__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group__2"


    // $ANTLR start "rule__Metric__Group__2__Impl"
    // InternalArchQualityDef.g:3158:1: rule__Metric__Group__2__Impl : ( ( rule__Metric__Group_2__0 )? ) ;
    public final void rule__Metric__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3162:1: ( ( ( rule__Metric__Group_2__0 )? ) )
            // InternalArchQualityDef.g:3163:1: ( ( rule__Metric__Group_2__0 )? )
            {
            // InternalArchQualityDef.g:3163:1: ( ( rule__Metric__Group_2__0 )? )
            // InternalArchQualityDef.g:3164:2: ( rule__Metric__Group_2__0 )?
            {
             before(grammarAccess.getMetricAccess().getGroup_2()); 
            // InternalArchQualityDef.g:3165:2: ( rule__Metric__Group_2__0 )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==44) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // InternalArchQualityDef.g:3165:3: rule__Metric__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Metric__Group_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMetricAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group__2__Impl"


    // $ANTLR start "rule__Metric__Group__3"
    // InternalArchQualityDef.g:3173:1: rule__Metric__Group__3 : rule__Metric__Group__3__Impl ;
    public final void rule__Metric__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3177:1: ( rule__Metric__Group__3__Impl )
            // InternalArchQualityDef.g:3178:2: rule__Metric__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Metric__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group__3"


    // $ANTLR start "rule__Metric__Group__3__Impl"
    // InternalArchQualityDef.g:3184:1: rule__Metric__Group__3__Impl : ( ( rule__Metric__Group_3__0 )? ) ;
    public final void rule__Metric__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3188:1: ( ( ( rule__Metric__Group_3__0 )? ) )
            // InternalArchQualityDef.g:3189:1: ( ( rule__Metric__Group_3__0 )? )
            {
            // InternalArchQualityDef.g:3189:1: ( ( rule__Metric__Group_3__0 )? )
            // InternalArchQualityDef.g:3190:2: ( rule__Metric__Group_3__0 )?
            {
             before(grammarAccess.getMetricAccess().getGroup_3()); 
            // InternalArchQualityDef.g:3191:2: ( rule__Metric__Group_3__0 )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==45) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalArchQualityDef.g:3191:3: rule__Metric__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Metric__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMetricAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group__3__Impl"


    // $ANTLR start "rule__Metric__Group_2__0"
    // InternalArchQualityDef.g:3200:1: rule__Metric__Group_2__0 : rule__Metric__Group_2__0__Impl rule__Metric__Group_2__1 ;
    public final void rule__Metric__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3204:1: ( rule__Metric__Group_2__0__Impl rule__Metric__Group_2__1 )
            // InternalArchQualityDef.g:3205:2: rule__Metric__Group_2__0__Impl rule__Metric__Group_2__1
            {
            pushFollow(FOLLOW_11);
            rule__Metric__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Metric__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group_2__0"


    // $ANTLR start "rule__Metric__Group_2__0__Impl"
    // InternalArchQualityDef.g:3212:1: rule__Metric__Group_2__0__Impl : ( 'description:' ) ;
    public final void rule__Metric__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3216:1: ( ( 'description:' ) )
            // InternalArchQualityDef.g:3217:1: ( 'description:' )
            {
            // InternalArchQualityDef.g:3217:1: ( 'description:' )
            // InternalArchQualityDef.g:3218:2: 'description:'
            {
             before(grammarAccess.getMetricAccess().getDescriptionKeyword_2_0()); 
            match(input,44,FOLLOW_2); 
             after(grammarAccess.getMetricAccess().getDescriptionKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group_2__0__Impl"


    // $ANTLR start "rule__Metric__Group_2__1"
    // InternalArchQualityDef.g:3227:1: rule__Metric__Group_2__1 : rule__Metric__Group_2__1__Impl ;
    public final void rule__Metric__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3231:1: ( rule__Metric__Group_2__1__Impl )
            // InternalArchQualityDef.g:3232:2: rule__Metric__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Metric__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group_2__1"


    // $ANTLR start "rule__Metric__Group_2__1__Impl"
    // InternalArchQualityDef.g:3238:1: rule__Metric__Group_2__1__Impl : ( ( rule__Metric__DescriptionAssignment_2_1 ) ) ;
    public final void rule__Metric__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3242:1: ( ( ( rule__Metric__DescriptionAssignment_2_1 ) ) )
            // InternalArchQualityDef.g:3243:1: ( ( rule__Metric__DescriptionAssignment_2_1 ) )
            {
            // InternalArchQualityDef.g:3243:1: ( ( rule__Metric__DescriptionAssignment_2_1 ) )
            // InternalArchQualityDef.g:3244:2: ( rule__Metric__DescriptionAssignment_2_1 )
            {
             before(grammarAccess.getMetricAccess().getDescriptionAssignment_2_1()); 
            // InternalArchQualityDef.g:3245:2: ( rule__Metric__DescriptionAssignment_2_1 )
            // InternalArchQualityDef.g:3245:3: rule__Metric__DescriptionAssignment_2_1
            {
            pushFollow(FOLLOW_2);
            rule__Metric__DescriptionAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getMetricAccess().getDescriptionAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group_2__1__Impl"


    // $ANTLR start "rule__Metric__Group_3__0"
    // InternalArchQualityDef.g:3254:1: rule__Metric__Group_3__0 : rule__Metric__Group_3__0__Impl rule__Metric__Group_3__1 ;
    public final void rule__Metric__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3258:1: ( rule__Metric__Group_3__0__Impl rule__Metric__Group_3__1 )
            // InternalArchQualityDef.g:3259:2: rule__Metric__Group_3__0__Impl rule__Metric__Group_3__1
            {
            pushFollow(FOLLOW_20);
            rule__Metric__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Metric__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group_3__0"


    // $ANTLR start "rule__Metric__Group_3__0__Impl"
    // InternalArchQualityDef.g:3266:1: rule__Metric__Group_3__0__Impl : ( '[' ) ;
    public final void rule__Metric__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3270:1: ( ( '[' ) )
            // InternalArchQualityDef.g:3271:1: ( '[' )
            {
            // InternalArchQualityDef.g:3271:1: ( '[' )
            // InternalArchQualityDef.g:3272:2: '['
            {
             before(grammarAccess.getMetricAccess().getLeftSquareBracketKeyword_3_0()); 
            match(input,45,FOLLOW_2); 
             after(grammarAccess.getMetricAccess().getLeftSquareBracketKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group_3__0__Impl"


    // $ANTLR start "rule__Metric__Group_3__1"
    // InternalArchQualityDef.g:3281:1: rule__Metric__Group_3__1 : rule__Metric__Group_3__1__Impl rule__Metric__Group_3__2 ;
    public final void rule__Metric__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3285:1: ( rule__Metric__Group_3__1__Impl rule__Metric__Group_3__2 )
            // InternalArchQualityDef.g:3286:2: rule__Metric__Group_3__1__Impl rule__Metric__Group_3__2
            {
            pushFollow(FOLLOW_23);
            rule__Metric__Group_3__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Metric__Group_3__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group_3__1"


    // $ANTLR start "rule__Metric__Group_3__1__Impl"
    // InternalArchQualityDef.g:3293:1: rule__Metric__Group_3__1__Impl : ( ( rule__Metric__EvidenceAssignment_3_1 ) ) ;
    public final void rule__Metric__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3297:1: ( ( ( rule__Metric__EvidenceAssignment_3_1 ) ) )
            // InternalArchQualityDef.g:3298:1: ( ( rule__Metric__EvidenceAssignment_3_1 ) )
            {
            // InternalArchQualityDef.g:3298:1: ( ( rule__Metric__EvidenceAssignment_3_1 ) )
            // InternalArchQualityDef.g:3299:2: ( rule__Metric__EvidenceAssignment_3_1 )
            {
             before(grammarAccess.getMetricAccess().getEvidenceAssignment_3_1()); 
            // InternalArchQualityDef.g:3300:2: ( rule__Metric__EvidenceAssignment_3_1 )
            // InternalArchQualityDef.g:3300:3: rule__Metric__EvidenceAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Metric__EvidenceAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getMetricAccess().getEvidenceAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group_3__1__Impl"


    // $ANTLR start "rule__Metric__Group_3__2"
    // InternalArchQualityDef.g:3308:1: rule__Metric__Group_3__2 : rule__Metric__Group_3__2__Impl rule__Metric__Group_3__3 ;
    public final void rule__Metric__Group_3__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3312:1: ( rule__Metric__Group_3__2__Impl rule__Metric__Group_3__3 )
            // InternalArchQualityDef.g:3313:2: rule__Metric__Group_3__2__Impl rule__Metric__Group_3__3
            {
            pushFollow(FOLLOW_23);
            rule__Metric__Group_3__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Metric__Group_3__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group_3__2"


    // $ANTLR start "rule__Metric__Group_3__2__Impl"
    // InternalArchQualityDef.g:3320:1: rule__Metric__Group_3__2__Impl : ( ( rule__Metric__Group_3_2__0 )* ) ;
    public final void rule__Metric__Group_3__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3324:1: ( ( ( rule__Metric__Group_3_2__0 )* ) )
            // InternalArchQualityDef.g:3325:1: ( ( rule__Metric__Group_3_2__0 )* )
            {
            // InternalArchQualityDef.g:3325:1: ( ( rule__Metric__Group_3_2__0 )* )
            // InternalArchQualityDef.g:3326:2: ( rule__Metric__Group_3_2__0 )*
            {
             before(grammarAccess.getMetricAccess().getGroup_3_2()); 
            // InternalArchQualityDef.g:3327:2: ( rule__Metric__Group_3_2__0 )*
            loop24:
            do {
                int alt24=2;
                int LA24_0 = input.LA(1);

                if ( (LA24_0==23) ) {
                    alt24=1;
                }


                switch (alt24) {
            	case 1 :
            	    // InternalArchQualityDef.g:3327:3: rule__Metric__Group_3_2__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__Metric__Group_3_2__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop24;
                }
            } while (true);

             after(grammarAccess.getMetricAccess().getGroup_3_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group_3__2__Impl"


    // $ANTLR start "rule__Metric__Group_3__3"
    // InternalArchQualityDef.g:3335:1: rule__Metric__Group_3__3 : rule__Metric__Group_3__3__Impl ;
    public final void rule__Metric__Group_3__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3339:1: ( rule__Metric__Group_3__3__Impl )
            // InternalArchQualityDef.g:3340:2: rule__Metric__Group_3__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Metric__Group_3__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group_3__3"


    // $ANTLR start "rule__Metric__Group_3__3__Impl"
    // InternalArchQualityDef.g:3346:1: rule__Metric__Group_3__3__Impl : ( ']' ) ;
    public final void rule__Metric__Group_3__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3350:1: ( ( ']' ) )
            // InternalArchQualityDef.g:3351:1: ( ']' )
            {
            // InternalArchQualityDef.g:3351:1: ( ']' )
            // InternalArchQualityDef.g:3352:2: ']'
            {
             before(grammarAccess.getMetricAccess().getRightSquareBracketKeyword_3_3()); 
            match(input,46,FOLLOW_2); 
             after(grammarAccess.getMetricAccess().getRightSquareBracketKeyword_3_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group_3__3__Impl"


    // $ANTLR start "rule__Metric__Group_3_2__0"
    // InternalArchQualityDef.g:3362:1: rule__Metric__Group_3_2__0 : rule__Metric__Group_3_2__0__Impl rule__Metric__Group_3_2__1 ;
    public final void rule__Metric__Group_3_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3366:1: ( rule__Metric__Group_3_2__0__Impl rule__Metric__Group_3_2__1 )
            // InternalArchQualityDef.g:3367:2: rule__Metric__Group_3_2__0__Impl rule__Metric__Group_3_2__1
            {
            pushFollow(FOLLOW_20);
            rule__Metric__Group_3_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Metric__Group_3_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group_3_2__0"


    // $ANTLR start "rule__Metric__Group_3_2__0__Impl"
    // InternalArchQualityDef.g:3374:1: rule__Metric__Group_3_2__0__Impl : ( ',' ) ;
    public final void rule__Metric__Group_3_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3378:1: ( ( ',' ) )
            // InternalArchQualityDef.g:3379:1: ( ',' )
            {
            // InternalArchQualityDef.g:3379:1: ( ',' )
            // InternalArchQualityDef.g:3380:2: ','
            {
             before(grammarAccess.getMetricAccess().getCommaKeyword_3_2_0()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getMetricAccess().getCommaKeyword_3_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group_3_2__0__Impl"


    // $ANTLR start "rule__Metric__Group_3_2__1"
    // InternalArchQualityDef.g:3389:1: rule__Metric__Group_3_2__1 : rule__Metric__Group_3_2__1__Impl ;
    public final void rule__Metric__Group_3_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3393:1: ( rule__Metric__Group_3_2__1__Impl )
            // InternalArchQualityDef.g:3394:2: rule__Metric__Group_3_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Metric__Group_3_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group_3_2__1"


    // $ANTLR start "rule__Metric__Group_3_2__1__Impl"
    // InternalArchQualityDef.g:3400:1: rule__Metric__Group_3_2__1__Impl : ( ( rule__Metric__EvidenceAssignment_3_2_1 ) ) ;
    public final void rule__Metric__Group_3_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3404:1: ( ( ( rule__Metric__EvidenceAssignment_3_2_1 ) ) )
            // InternalArchQualityDef.g:3405:1: ( ( rule__Metric__EvidenceAssignment_3_2_1 ) )
            {
            // InternalArchQualityDef.g:3405:1: ( ( rule__Metric__EvidenceAssignment_3_2_1 ) )
            // InternalArchQualityDef.g:3406:2: ( rule__Metric__EvidenceAssignment_3_2_1 )
            {
             before(grammarAccess.getMetricAccess().getEvidenceAssignment_3_2_1()); 
            // InternalArchQualityDef.g:3407:2: ( rule__Metric__EvidenceAssignment_3_2_1 )
            // InternalArchQualityDef.g:3407:3: rule__Metric__EvidenceAssignment_3_2_1
            {
            pushFollow(FOLLOW_2);
            rule__Metric__EvidenceAssignment_3_2_1();

            state._fsp--;


            }

             after(grammarAccess.getMetricAccess().getEvidenceAssignment_3_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__Group_3_2__1__Impl"


    // $ANTLR start "rule__QualityAttribute__Group__0"
    // InternalArchQualityDef.g:3416:1: rule__QualityAttribute__Group__0 : rule__QualityAttribute__Group__0__Impl rule__QualityAttribute__Group__1 ;
    public final void rule__QualityAttribute__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3420:1: ( rule__QualityAttribute__Group__0__Impl rule__QualityAttribute__Group__1 )
            // InternalArchQualityDef.g:3421:2: rule__QualityAttribute__Group__0__Impl rule__QualityAttribute__Group__1
            {
            pushFollow(FOLLOW_20);
            rule__QualityAttribute__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityAttribute__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group__0"


    // $ANTLR start "rule__QualityAttribute__Group__0__Impl"
    // InternalArchQualityDef.g:3428:1: rule__QualityAttribute__Group__0__Impl : ( 'QualityAttribute' ) ;
    public final void rule__QualityAttribute__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3432:1: ( ( 'QualityAttribute' ) )
            // InternalArchQualityDef.g:3433:1: ( 'QualityAttribute' )
            {
            // InternalArchQualityDef.g:3433:1: ( 'QualityAttribute' )
            // InternalArchQualityDef.g:3434:2: 'QualityAttribute'
            {
             before(grammarAccess.getQualityAttributeAccess().getQualityAttributeKeyword_0()); 
            match(input,47,FOLLOW_2); 
             after(grammarAccess.getQualityAttributeAccess().getQualityAttributeKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group__0__Impl"


    // $ANTLR start "rule__QualityAttribute__Group__1"
    // InternalArchQualityDef.g:3443:1: rule__QualityAttribute__Group__1 : rule__QualityAttribute__Group__1__Impl rule__QualityAttribute__Group__2 ;
    public final void rule__QualityAttribute__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3447:1: ( rule__QualityAttribute__Group__1__Impl rule__QualityAttribute__Group__2 )
            // InternalArchQualityDef.g:3448:2: rule__QualityAttribute__Group__1__Impl rule__QualityAttribute__Group__2
            {
            pushFollow(FOLLOW_22);
            rule__QualityAttribute__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityAttribute__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group__1"


    // $ANTLR start "rule__QualityAttribute__Group__1__Impl"
    // InternalArchQualityDef.g:3455:1: rule__QualityAttribute__Group__1__Impl : ( ( rule__QualityAttribute__NameAssignment_1 ) ) ;
    public final void rule__QualityAttribute__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3459:1: ( ( ( rule__QualityAttribute__NameAssignment_1 ) ) )
            // InternalArchQualityDef.g:3460:1: ( ( rule__QualityAttribute__NameAssignment_1 ) )
            {
            // InternalArchQualityDef.g:3460:1: ( ( rule__QualityAttribute__NameAssignment_1 ) )
            // InternalArchQualityDef.g:3461:2: ( rule__QualityAttribute__NameAssignment_1 )
            {
             before(grammarAccess.getQualityAttributeAccess().getNameAssignment_1()); 
            // InternalArchQualityDef.g:3462:2: ( rule__QualityAttribute__NameAssignment_1 )
            // InternalArchQualityDef.g:3462:3: rule__QualityAttribute__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__QualityAttribute__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getQualityAttributeAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group__1__Impl"


    // $ANTLR start "rule__QualityAttribute__Group__2"
    // InternalArchQualityDef.g:3470:1: rule__QualityAttribute__Group__2 : rule__QualityAttribute__Group__2__Impl rule__QualityAttribute__Group__3 ;
    public final void rule__QualityAttribute__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3474:1: ( rule__QualityAttribute__Group__2__Impl rule__QualityAttribute__Group__3 )
            // InternalArchQualityDef.g:3475:2: rule__QualityAttribute__Group__2__Impl rule__QualityAttribute__Group__3
            {
            pushFollow(FOLLOW_22);
            rule__QualityAttribute__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityAttribute__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group__2"


    // $ANTLR start "rule__QualityAttribute__Group__2__Impl"
    // InternalArchQualityDef.g:3482:1: rule__QualityAttribute__Group__2__Impl : ( ( rule__QualityAttribute__Group_2__0 )? ) ;
    public final void rule__QualityAttribute__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3486:1: ( ( ( rule__QualityAttribute__Group_2__0 )? ) )
            // InternalArchQualityDef.g:3487:1: ( ( rule__QualityAttribute__Group_2__0 )? )
            {
            // InternalArchQualityDef.g:3487:1: ( ( rule__QualityAttribute__Group_2__0 )? )
            // InternalArchQualityDef.g:3488:2: ( rule__QualityAttribute__Group_2__0 )?
            {
             before(grammarAccess.getQualityAttributeAccess().getGroup_2()); 
            // InternalArchQualityDef.g:3489:2: ( rule__QualityAttribute__Group_2__0 )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==44) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalArchQualityDef.g:3489:3: rule__QualityAttribute__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__QualityAttribute__Group_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getQualityAttributeAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group__2__Impl"


    // $ANTLR start "rule__QualityAttribute__Group__3"
    // InternalArchQualityDef.g:3497:1: rule__QualityAttribute__Group__3 : rule__QualityAttribute__Group__3__Impl ;
    public final void rule__QualityAttribute__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3501:1: ( rule__QualityAttribute__Group__3__Impl )
            // InternalArchQualityDef.g:3502:2: rule__QualityAttribute__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__QualityAttribute__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group__3"


    // $ANTLR start "rule__QualityAttribute__Group__3__Impl"
    // InternalArchQualityDef.g:3508:1: rule__QualityAttribute__Group__3__Impl : ( ( rule__QualityAttribute__Group_3__0 )? ) ;
    public final void rule__QualityAttribute__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3512:1: ( ( ( rule__QualityAttribute__Group_3__0 )? ) )
            // InternalArchQualityDef.g:3513:1: ( ( rule__QualityAttribute__Group_3__0 )? )
            {
            // InternalArchQualityDef.g:3513:1: ( ( rule__QualityAttribute__Group_3__0 )? )
            // InternalArchQualityDef.g:3514:2: ( rule__QualityAttribute__Group_3__0 )?
            {
             before(grammarAccess.getQualityAttributeAccess().getGroup_3()); 
            // InternalArchQualityDef.g:3515:2: ( rule__QualityAttribute__Group_3__0 )?
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0==45) ) {
                alt26=1;
            }
            switch (alt26) {
                case 1 :
                    // InternalArchQualityDef.g:3515:3: rule__QualityAttribute__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__QualityAttribute__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getQualityAttributeAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group__3__Impl"


    // $ANTLR start "rule__QualityAttribute__Group_2__0"
    // InternalArchQualityDef.g:3524:1: rule__QualityAttribute__Group_2__0 : rule__QualityAttribute__Group_2__0__Impl rule__QualityAttribute__Group_2__1 ;
    public final void rule__QualityAttribute__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3528:1: ( rule__QualityAttribute__Group_2__0__Impl rule__QualityAttribute__Group_2__1 )
            // InternalArchQualityDef.g:3529:2: rule__QualityAttribute__Group_2__0__Impl rule__QualityAttribute__Group_2__1
            {
            pushFollow(FOLLOW_11);
            rule__QualityAttribute__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityAttribute__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group_2__0"


    // $ANTLR start "rule__QualityAttribute__Group_2__0__Impl"
    // InternalArchQualityDef.g:3536:1: rule__QualityAttribute__Group_2__0__Impl : ( 'description:' ) ;
    public final void rule__QualityAttribute__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3540:1: ( ( 'description:' ) )
            // InternalArchQualityDef.g:3541:1: ( 'description:' )
            {
            // InternalArchQualityDef.g:3541:1: ( 'description:' )
            // InternalArchQualityDef.g:3542:2: 'description:'
            {
             before(grammarAccess.getQualityAttributeAccess().getDescriptionKeyword_2_0()); 
            match(input,44,FOLLOW_2); 
             after(grammarAccess.getQualityAttributeAccess().getDescriptionKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group_2__0__Impl"


    // $ANTLR start "rule__QualityAttribute__Group_2__1"
    // InternalArchQualityDef.g:3551:1: rule__QualityAttribute__Group_2__1 : rule__QualityAttribute__Group_2__1__Impl ;
    public final void rule__QualityAttribute__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3555:1: ( rule__QualityAttribute__Group_2__1__Impl )
            // InternalArchQualityDef.g:3556:2: rule__QualityAttribute__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__QualityAttribute__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group_2__1"


    // $ANTLR start "rule__QualityAttribute__Group_2__1__Impl"
    // InternalArchQualityDef.g:3562:1: rule__QualityAttribute__Group_2__1__Impl : ( ( rule__QualityAttribute__DescriptionAssignment_2_1 ) ) ;
    public final void rule__QualityAttribute__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3566:1: ( ( ( rule__QualityAttribute__DescriptionAssignment_2_1 ) ) )
            // InternalArchQualityDef.g:3567:1: ( ( rule__QualityAttribute__DescriptionAssignment_2_1 ) )
            {
            // InternalArchQualityDef.g:3567:1: ( ( rule__QualityAttribute__DescriptionAssignment_2_1 ) )
            // InternalArchQualityDef.g:3568:2: ( rule__QualityAttribute__DescriptionAssignment_2_1 )
            {
             before(grammarAccess.getQualityAttributeAccess().getDescriptionAssignment_2_1()); 
            // InternalArchQualityDef.g:3569:2: ( rule__QualityAttribute__DescriptionAssignment_2_1 )
            // InternalArchQualityDef.g:3569:3: rule__QualityAttribute__DescriptionAssignment_2_1
            {
            pushFollow(FOLLOW_2);
            rule__QualityAttribute__DescriptionAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getQualityAttributeAccess().getDescriptionAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group_2__1__Impl"


    // $ANTLR start "rule__QualityAttribute__Group_3__0"
    // InternalArchQualityDef.g:3578:1: rule__QualityAttribute__Group_3__0 : rule__QualityAttribute__Group_3__0__Impl rule__QualityAttribute__Group_3__1 ;
    public final void rule__QualityAttribute__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3582:1: ( rule__QualityAttribute__Group_3__0__Impl rule__QualityAttribute__Group_3__1 )
            // InternalArchQualityDef.g:3583:2: rule__QualityAttribute__Group_3__0__Impl rule__QualityAttribute__Group_3__1
            {
            pushFollow(FOLLOW_20);
            rule__QualityAttribute__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityAttribute__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group_3__0"


    // $ANTLR start "rule__QualityAttribute__Group_3__0__Impl"
    // InternalArchQualityDef.g:3590:1: rule__QualityAttribute__Group_3__0__Impl : ( '[' ) ;
    public final void rule__QualityAttribute__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3594:1: ( ( '[' ) )
            // InternalArchQualityDef.g:3595:1: ( '[' )
            {
            // InternalArchQualityDef.g:3595:1: ( '[' )
            // InternalArchQualityDef.g:3596:2: '['
            {
             before(grammarAccess.getQualityAttributeAccess().getLeftSquareBracketKeyword_3_0()); 
            match(input,45,FOLLOW_2); 
             after(grammarAccess.getQualityAttributeAccess().getLeftSquareBracketKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group_3__0__Impl"


    // $ANTLR start "rule__QualityAttribute__Group_3__1"
    // InternalArchQualityDef.g:3605:1: rule__QualityAttribute__Group_3__1 : rule__QualityAttribute__Group_3__1__Impl rule__QualityAttribute__Group_3__2 ;
    public final void rule__QualityAttribute__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3609:1: ( rule__QualityAttribute__Group_3__1__Impl rule__QualityAttribute__Group_3__2 )
            // InternalArchQualityDef.g:3610:2: rule__QualityAttribute__Group_3__1__Impl rule__QualityAttribute__Group_3__2
            {
            pushFollow(FOLLOW_23);
            rule__QualityAttribute__Group_3__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityAttribute__Group_3__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group_3__1"


    // $ANTLR start "rule__QualityAttribute__Group_3__1__Impl"
    // InternalArchQualityDef.g:3617:1: rule__QualityAttribute__Group_3__1__Impl : ( ( rule__QualityAttribute__EvidenceAssignment_3_1 ) ) ;
    public final void rule__QualityAttribute__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3621:1: ( ( ( rule__QualityAttribute__EvidenceAssignment_3_1 ) ) )
            // InternalArchQualityDef.g:3622:1: ( ( rule__QualityAttribute__EvidenceAssignment_3_1 ) )
            {
            // InternalArchQualityDef.g:3622:1: ( ( rule__QualityAttribute__EvidenceAssignment_3_1 ) )
            // InternalArchQualityDef.g:3623:2: ( rule__QualityAttribute__EvidenceAssignment_3_1 )
            {
             before(grammarAccess.getQualityAttributeAccess().getEvidenceAssignment_3_1()); 
            // InternalArchQualityDef.g:3624:2: ( rule__QualityAttribute__EvidenceAssignment_3_1 )
            // InternalArchQualityDef.g:3624:3: rule__QualityAttribute__EvidenceAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__QualityAttribute__EvidenceAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getQualityAttributeAccess().getEvidenceAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group_3__1__Impl"


    // $ANTLR start "rule__QualityAttribute__Group_3__2"
    // InternalArchQualityDef.g:3632:1: rule__QualityAttribute__Group_3__2 : rule__QualityAttribute__Group_3__2__Impl rule__QualityAttribute__Group_3__3 ;
    public final void rule__QualityAttribute__Group_3__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3636:1: ( rule__QualityAttribute__Group_3__2__Impl rule__QualityAttribute__Group_3__3 )
            // InternalArchQualityDef.g:3637:2: rule__QualityAttribute__Group_3__2__Impl rule__QualityAttribute__Group_3__3
            {
            pushFollow(FOLLOW_23);
            rule__QualityAttribute__Group_3__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityAttribute__Group_3__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group_3__2"


    // $ANTLR start "rule__QualityAttribute__Group_3__2__Impl"
    // InternalArchQualityDef.g:3644:1: rule__QualityAttribute__Group_3__2__Impl : ( ( rule__QualityAttribute__Group_3_2__0 )* ) ;
    public final void rule__QualityAttribute__Group_3__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3648:1: ( ( ( rule__QualityAttribute__Group_3_2__0 )* ) )
            // InternalArchQualityDef.g:3649:1: ( ( rule__QualityAttribute__Group_3_2__0 )* )
            {
            // InternalArchQualityDef.g:3649:1: ( ( rule__QualityAttribute__Group_3_2__0 )* )
            // InternalArchQualityDef.g:3650:2: ( rule__QualityAttribute__Group_3_2__0 )*
            {
             before(grammarAccess.getQualityAttributeAccess().getGroup_3_2()); 
            // InternalArchQualityDef.g:3651:2: ( rule__QualityAttribute__Group_3_2__0 )*
            loop27:
            do {
                int alt27=2;
                int LA27_0 = input.LA(1);

                if ( (LA27_0==23) ) {
                    alt27=1;
                }


                switch (alt27) {
            	case 1 :
            	    // InternalArchQualityDef.g:3651:3: rule__QualityAttribute__Group_3_2__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__QualityAttribute__Group_3_2__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop27;
                }
            } while (true);

             after(grammarAccess.getQualityAttributeAccess().getGroup_3_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group_3__2__Impl"


    // $ANTLR start "rule__QualityAttribute__Group_3__3"
    // InternalArchQualityDef.g:3659:1: rule__QualityAttribute__Group_3__3 : rule__QualityAttribute__Group_3__3__Impl ;
    public final void rule__QualityAttribute__Group_3__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3663:1: ( rule__QualityAttribute__Group_3__3__Impl )
            // InternalArchQualityDef.g:3664:2: rule__QualityAttribute__Group_3__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__QualityAttribute__Group_3__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group_3__3"


    // $ANTLR start "rule__QualityAttribute__Group_3__3__Impl"
    // InternalArchQualityDef.g:3670:1: rule__QualityAttribute__Group_3__3__Impl : ( ']' ) ;
    public final void rule__QualityAttribute__Group_3__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3674:1: ( ( ']' ) )
            // InternalArchQualityDef.g:3675:1: ( ']' )
            {
            // InternalArchQualityDef.g:3675:1: ( ']' )
            // InternalArchQualityDef.g:3676:2: ']'
            {
             before(grammarAccess.getQualityAttributeAccess().getRightSquareBracketKeyword_3_3()); 
            match(input,46,FOLLOW_2); 
             after(grammarAccess.getQualityAttributeAccess().getRightSquareBracketKeyword_3_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group_3__3__Impl"


    // $ANTLR start "rule__QualityAttribute__Group_3_2__0"
    // InternalArchQualityDef.g:3686:1: rule__QualityAttribute__Group_3_2__0 : rule__QualityAttribute__Group_3_2__0__Impl rule__QualityAttribute__Group_3_2__1 ;
    public final void rule__QualityAttribute__Group_3_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3690:1: ( rule__QualityAttribute__Group_3_2__0__Impl rule__QualityAttribute__Group_3_2__1 )
            // InternalArchQualityDef.g:3691:2: rule__QualityAttribute__Group_3_2__0__Impl rule__QualityAttribute__Group_3_2__1
            {
            pushFollow(FOLLOW_20);
            rule__QualityAttribute__Group_3_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityAttribute__Group_3_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group_3_2__0"


    // $ANTLR start "rule__QualityAttribute__Group_3_2__0__Impl"
    // InternalArchQualityDef.g:3698:1: rule__QualityAttribute__Group_3_2__0__Impl : ( ',' ) ;
    public final void rule__QualityAttribute__Group_3_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3702:1: ( ( ',' ) )
            // InternalArchQualityDef.g:3703:1: ( ',' )
            {
            // InternalArchQualityDef.g:3703:1: ( ',' )
            // InternalArchQualityDef.g:3704:2: ','
            {
             before(grammarAccess.getQualityAttributeAccess().getCommaKeyword_3_2_0()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getQualityAttributeAccess().getCommaKeyword_3_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group_3_2__0__Impl"


    // $ANTLR start "rule__QualityAttribute__Group_3_2__1"
    // InternalArchQualityDef.g:3713:1: rule__QualityAttribute__Group_3_2__1 : rule__QualityAttribute__Group_3_2__1__Impl ;
    public final void rule__QualityAttribute__Group_3_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3717:1: ( rule__QualityAttribute__Group_3_2__1__Impl )
            // InternalArchQualityDef.g:3718:2: rule__QualityAttribute__Group_3_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__QualityAttribute__Group_3_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group_3_2__1"


    // $ANTLR start "rule__QualityAttribute__Group_3_2__1__Impl"
    // InternalArchQualityDef.g:3724:1: rule__QualityAttribute__Group_3_2__1__Impl : ( ( rule__QualityAttribute__EvidenceAssignment_3_2_1 ) ) ;
    public final void rule__QualityAttribute__Group_3_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3728:1: ( ( ( rule__QualityAttribute__EvidenceAssignment_3_2_1 ) ) )
            // InternalArchQualityDef.g:3729:1: ( ( rule__QualityAttribute__EvidenceAssignment_3_2_1 ) )
            {
            // InternalArchQualityDef.g:3729:1: ( ( rule__QualityAttribute__EvidenceAssignment_3_2_1 ) )
            // InternalArchQualityDef.g:3730:2: ( rule__QualityAttribute__EvidenceAssignment_3_2_1 )
            {
             before(grammarAccess.getQualityAttributeAccess().getEvidenceAssignment_3_2_1()); 
            // InternalArchQualityDef.g:3731:2: ( rule__QualityAttribute__EvidenceAssignment_3_2_1 )
            // InternalArchQualityDef.g:3731:3: rule__QualityAttribute__EvidenceAssignment_3_2_1
            {
            pushFollow(FOLLOW_2);
            rule__QualityAttribute__EvidenceAssignment_3_2_1();

            state._fsp--;


            }

             after(grammarAccess.getQualityAttributeAccess().getEvidenceAssignment_3_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__Group_3_2__1__Impl"


    // $ANTLR start "rule__QualityCharacteristic__Group__0"
    // InternalArchQualityDef.g:3740:1: rule__QualityCharacteristic__Group__0 : rule__QualityCharacteristic__Group__0__Impl rule__QualityCharacteristic__Group__1 ;
    public final void rule__QualityCharacteristic__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3744:1: ( rule__QualityCharacteristic__Group__0__Impl rule__QualityCharacteristic__Group__1 )
            // InternalArchQualityDef.g:3745:2: rule__QualityCharacteristic__Group__0__Impl rule__QualityCharacteristic__Group__1
            {
            pushFollow(FOLLOW_20);
            rule__QualityCharacteristic__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityCharacteristic__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group__0"


    // $ANTLR start "rule__QualityCharacteristic__Group__0__Impl"
    // InternalArchQualityDef.g:3752:1: rule__QualityCharacteristic__Group__0__Impl : ( 'QualityCharacteristic' ) ;
    public final void rule__QualityCharacteristic__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3756:1: ( ( 'QualityCharacteristic' ) )
            // InternalArchQualityDef.g:3757:1: ( 'QualityCharacteristic' )
            {
            // InternalArchQualityDef.g:3757:1: ( 'QualityCharacteristic' )
            // InternalArchQualityDef.g:3758:2: 'QualityCharacteristic'
            {
             before(grammarAccess.getQualityCharacteristicAccess().getQualityCharacteristicKeyword_0()); 
            match(input,48,FOLLOW_2); 
             after(grammarAccess.getQualityCharacteristicAccess().getQualityCharacteristicKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group__0__Impl"


    // $ANTLR start "rule__QualityCharacteristic__Group__1"
    // InternalArchQualityDef.g:3767:1: rule__QualityCharacteristic__Group__1 : rule__QualityCharacteristic__Group__1__Impl rule__QualityCharacteristic__Group__2 ;
    public final void rule__QualityCharacteristic__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3771:1: ( rule__QualityCharacteristic__Group__1__Impl rule__QualityCharacteristic__Group__2 )
            // InternalArchQualityDef.g:3772:2: rule__QualityCharacteristic__Group__1__Impl rule__QualityCharacteristic__Group__2
            {
            pushFollow(FOLLOW_22);
            rule__QualityCharacteristic__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityCharacteristic__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group__1"


    // $ANTLR start "rule__QualityCharacteristic__Group__1__Impl"
    // InternalArchQualityDef.g:3779:1: rule__QualityCharacteristic__Group__1__Impl : ( ( rule__QualityCharacteristic__NameAssignment_1 ) ) ;
    public final void rule__QualityCharacteristic__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3783:1: ( ( ( rule__QualityCharacteristic__NameAssignment_1 ) ) )
            // InternalArchQualityDef.g:3784:1: ( ( rule__QualityCharacteristic__NameAssignment_1 ) )
            {
            // InternalArchQualityDef.g:3784:1: ( ( rule__QualityCharacteristic__NameAssignment_1 ) )
            // InternalArchQualityDef.g:3785:2: ( rule__QualityCharacteristic__NameAssignment_1 )
            {
             before(grammarAccess.getQualityCharacteristicAccess().getNameAssignment_1()); 
            // InternalArchQualityDef.g:3786:2: ( rule__QualityCharacteristic__NameAssignment_1 )
            // InternalArchQualityDef.g:3786:3: rule__QualityCharacteristic__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__QualityCharacteristic__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getQualityCharacteristicAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group__1__Impl"


    // $ANTLR start "rule__QualityCharacteristic__Group__2"
    // InternalArchQualityDef.g:3794:1: rule__QualityCharacteristic__Group__2 : rule__QualityCharacteristic__Group__2__Impl rule__QualityCharacteristic__Group__3 ;
    public final void rule__QualityCharacteristic__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3798:1: ( rule__QualityCharacteristic__Group__2__Impl rule__QualityCharacteristic__Group__3 )
            // InternalArchQualityDef.g:3799:2: rule__QualityCharacteristic__Group__2__Impl rule__QualityCharacteristic__Group__3
            {
            pushFollow(FOLLOW_22);
            rule__QualityCharacteristic__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityCharacteristic__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group__2"


    // $ANTLR start "rule__QualityCharacteristic__Group__2__Impl"
    // InternalArchQualityDef.g:3806:1: rule__QualityCharacteristic__Group__2__Impl : ( ( rule__QualityCharacteristic__Group_2__0 )? ) ;
    public final void rule__QualityCharacteristic__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3810:1: ( ( ( rule__QualityCharacteristic__Group_2__0 )? ) )
            // InternalArchQualityDef.g:3811:1: ( ( rule__QualityCharacteristic__Group_2__0 )? )
            {
            // InternalArchQualityDef.g:3811:1: ( ( rule__QualityCharacteristic__Group_2__0 )? )
            // InternalArchQualityDef.g:3812:2: ( rule__QualityCharacteristic__Group_2__0 )?
            {
             before(grammarAccess.getQualityCharacteristicAccess().getGroup_2()); 
            // InternalArchQualityDef.g:3813:2: ( rule__QualityCharacteristic__Group_2__0 )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==44) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalArchQualityDef.g:3813:3: rule__QualityCharacteristic__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__QualityCharacteristic__Group_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getQualityCharacteristicAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group__2__Impl"


    // $ANTLR start "rule__QualityCharacteristic__Group__3"
    // InternalArchQualityDef.g:3821:1: rule__QualityCharacteristic__Group__3 : rule__QualityCharacteristic__Group__3__Impl ;
    public final void rule__QualityCharacteristic__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3825:1: ( rule__QualityCharacteristic__Group__3__Impl )
            // InternalArchQualityDef.g:3826:2: rule__QualityCharacteristic__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__QualityCharacteristic__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group__3"


    // $ANTLR start "rule__QualityCharacteristic__Group__3__Impl"
    // InternalArchQualityDef.g:3832:1: rule__QualityCharacteristic__Group__3__Impl : ( ( rule__QualityCharacteristic__Group_3__0 )? ) ;
    public final void rule__QualityCharacteristic__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3836:1: ( ( ( rule__QualityCharacteristic__Group_3__0 )? ) )
            // InternalArchQualityDef.g:3837:1: ( ( rule__QualityCharacteristic__Group_3__0 )? )
            {
            // InternalArchQualityDef.g:3837:1: ( ( rule__QualityCharacteristic__Group_3__0 )? )
            // InternalArchQualityDef.g:3838:2: ( rule__QualityCharacteristic__Group_3__0 )?
            {
             before(grammarAccess.getQualityCharacteristicAccess().getGroup_3()); 
            // InternalArchQualityDef.g:3839:2: ( rule__QualityCharacteristic__Group_3__0 )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==45) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalArchQualityDef.g:3839:3: rule__QualityCharacteristic__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__QualityCharacteristic__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getQualityCharacteristicAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group__3__Impl"


    // $ANTLR start "rule__QualityCharacteristic__Group_2__0"
    // InternalArchQualityDef.g:3848:1: rule__QualityCharacteristic__Group_2__0 : rule__QualityCharacteristic__Group_2__0__Impl rule__QualityCharacteristic__Group_2__1 ;
    public final void rule__QualityCharacteristic__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3852:1: ( rule__QualityCharacteristic__Group_2__0__Impl rule__QualityCharacteristic__Group_2__1 )
            // InternalArchQualityDef.g:3853:2: rule__QualityCharacteristic__Group_2__0__Impl rule__QualityCharacteristic__Group_2__1
            {
            pushFollow(FOLLOW_11);
            rule__QualityCharacteristic__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityCharacteristic__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group_2__0"


    // $ANTLR start "rule__QualityCharacteristic__Group_2__0__Impl"
    // InternalArchQualityDef.g:3860:1: rule__QualityCharacteristic__Group_2__0__Impl : ( 'description:' ) ;
    public final void rule__QualityCharacteristic__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3864:1: ( ( 'description:' ) )
            // InternalArchQualityDef.g:3865:1: ( 'description:' )
            {
            // InternalArchQualityDef.g:3865:1: ( 'description:' )
            // InternalArchQualityDef.g:3866:2: 'description:'
            {
             before(grammarAccess.getQualityCharacteristicAccess().getDescriptionKeyword_2_0()); 
            match(input,44,FOLLOW_2); 
             after(grammarAccess.getQualityCharacteristicAccess().getDescriptionKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group_2__0__Impl"


    // $ANTLR start "rule__QualityCharacteristic__Group_2__1"
    // InternalArchQualityDef.g:3875:1: rule__QualityCharacteristic__Group_2__1 : rule__QualityCharacteristic__Group_2__1__Impl ;
    public final void rule__QualityCharacteristic__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3879:1: ( rule__QualityCharacteristic__Group_2__1__Impl )
            // InternalArchQualityDef.g:3880:2: rule__QualityCharacteristic__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__QualityCharacteristic__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group_2__1"


    // $ANTLR start "rule__QualityCharacteristic__Group_2__1__Impl"
    // InternalArchQualityDef.g:3886:1: rule__QualityCharacteristic__Group_2__1__Impl : ( ( rule__QualityCharacteristic__DescriptionAssignment_2_1 ) ) ;
    public final void rule__QualityCharacteristic__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3890:1: ( ( ( rule__QualityCharacteristic__DescriptionAssignment_2_1 ) ) )
            // InternalArchQualityDef.g:3891:1: ( ( rule__QualityCharacteristic__DescriptionAssignment_2_1 ) )
            {
            // InternalArchQualityDef.g:3891:1: ( ( rule__QualityCharacteristic__DescriptionAssignment_2_1 ) )
            // InternalArchQualityDef.g:3892:2: ( rule__QualityCharacteristic__DescriptionAssignment_2_1 )
            {
             before(grammarAccess.getQualityCharacteristicAccess().getDescriptionAssignment_2_1()); 
            // InternalArchQualityDef.g:3893:2: ( rule__QualityCharacteristic__DescriptionAssignment_2_1 )
            // InternalArchQualityDef.g:3893:3: rule__QualityCharacteristic__DescriptionAssignment_2_1
            {
            pushFollow(FOLLOW_2);
            rule__QualityCharacteristic__DescriptionAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getQualityCharacteristicAccess().getDescriptionAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group_2__1__Impl"


    // $ANTLR start "rule__QualityCharacteristic__Group_3__0"
    // InternalArchQualityDef.g:3902:1: rule__QualityCharacteristic__Group_3__0 : rule__QualityCharacteristic__Group_3__0__Impl rule__QualityCharacteristic__Group_3__1 ;
    public final void rule__QualityCharacteristic__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3906:1: ( rule__QualityCharacteristic__Group_3__0__Impl rule__QualityCharacteristic__Group_3__1 )
            // InternalArchQualityDef.g:3907:2: rule__QualityCharacteristic__Group_3__0__Impl rule__QualityCharacteristic__Group_3__1
            {
            pushFollow(FOLLOW_20);
            rule__QualityCharacteristic__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityCharacteristic__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group_3__0"


    // $ANTLR start "rule__QualityCharacteristic__Group_3__0__Impl"
    // InternalArchQualityDef.g:3914:1: rule__QualityCharacteristic__Group_3__0__Impl : ( '[' ) ;
    public final void rule__QualityCharacteristic__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3918:1: ( ( '[' ) )
            // InternalArchQualityDef.g:3919:1: ( '[' )
            {
            // InternalArchQualityDef.g:3919:1: ( '[' )
            // InternalArchQualityDef.g:3920:2: '['
            {
             before(grammarAccess.getQualityCharacteristicAccess().getLeftSquareBracketKeyword_3_0()); 
            match(input,45,FOLLOW_2); 
             after(grammarAccess.getQualityCharacteristicAccess().getLeftSquareBracketKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group_3__0__Impl"


    // $ANTLR start "rule__QualityCharacteristic__Group_3__1"
    // InternalArchQualityDef.g:3929:1: rule__QualityCharacteristic__Group_3__1 : rule__QualityCharacteristic__Group_3__1__Impl rule__QualityCharacteristic__Group_3__2 ;
    public final void rule__QualityCharacteristic__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3933:1: ( rule__QualityCharacteristic__Group_3__1__Impl rule__QualityCharacteristic__Group_3__2 )
            // InternalArchQualityDef.g:3934:2: rule__QualityCharacteristic__Group_3__1__Impl rule__QualityCharacteristic__Group_3__2
            {
            pushFollow(FOLLOW_23);
            rule__QualityCharacteristic__Group_3__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityCharacteristic__Group_3__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group_3__1"


    // $ANTLR start "rule__QualityCharacteristic__Group_3__1__Impl"
    // InternalArchQualityDef.g:3941:1: rule__QualityCharacteristic__Group_3__1__Impl : ( ( rule__QualityCharacteristic__EvidenceAssignment_3_1 ) ) ;
    public final void rule__QualityCharacteristic__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3945:1: ( ( ( rule__QualityCharacteristic__EvidenceAssignment_3_1 ) ) )
            // InternalArchQualityDef.g:3946:1: ( ( rule__QualityCharacteristic__EvidenceAssignment_3_1 ) )
            {
            // InternalArchQualityDef.g:3946:1: ( ( rule__QualityCharacteristic__EvidenceAssignment_3_1 ) )
            // InternalArchQualityDef.g:3947:2: ( rule__QualityCharacteristic__EvidenceAssignment_3_1 )
            {
             before(grammarAccess.getQualityCharacteristicAccess().getEvidenceAssignment_3_1()); 
            // InternalArchQualityDef.g:3948:2: ( rule__QualityCharacteristic__EvidenceAssignment_3_1 )
            // InternalArchQualityDef.g:3948:3: rule__QualityCharacteristic__EvidenceAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__QualityCharacteristic__EvidenceAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getQualityCharacteristicAccess().getEvidenceAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group_3__1__Impl"


    // $ANTLR start "rule__QualityCharacteristic__Group_3__2"
    // InternalArchQualityDef.g:3956:1: rule__QualityCharacteristic__Group_3__2 : rule__QualityCharacteristic__Group_3__2__Impl rule__QualityCharacteristic__Group_3__3 ;
    public final void rule__QualityCharacteristic__Group_3__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3960:1: ( rule__QualityCharacteristic__Group_3__2__Impl rule__QualityCharacteristic__Group_3__3 )
            // InternalArchQualityDef.g:3961:2: rule__QualityCharacteristic__Group_3__2__Impl rule__QualityCharacteristic__Group_3__3
            {
            pushFollow(FOLLOW_23);
            rule__QualityCharacteristic__Group_3__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityCharacteristic__Group_3__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group_3__2"


    // $ANTLR start "rule__QualityCharacteristic__Group_3__2__Impl"
    // InternalArchQualityDef.g:3968:1: rule__QualityCharacteristic__Group_3__2__Impl : ( ( rule__QualityCharacteristic__Group_3_2__0 )* ) ;
    public final void rule__QualityCharacteristic__Group_3__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3972:1: ( ( ( rule__QualityCharacteristic__Group_3_2__0 )* ) )
            // InternalArchQualityDef.g:3973:1: ( ( rule__QualityCharacteristic__Group_3_2__0 )* )
            {
            // InternalArchQualityDef.g:3973:1: ( ( rule__QualityCharacteristic__Group_3_2__0 )* )
            // InternalArchQualityDef.g:3974:2: ( rule__QualityCharacteristic__Group_3_2__0 )*
            {
             before(grammarAccess.getQualityCharacteristicAccess().getGroup_3_2()); 
            // InternalArchQualityDef.g:3975:2: ( rule__QualityCharacteristic__Group_3_2__0 )*
            loop30:
            do {
                int alt30=2;
                int LA30_0 = input.LA(1);

                if ( (LA30_0==23) ) {
                    alt30=1;
                }


                switch (alt30) {
            	case 1 :
            	    // InternalArchQualityDef.g:3975:3: rule__QualityCharacteristic__Group_3_2__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__QualityCharacteristic__Group_3_2__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop30;
                }
            } while (true);

             after(grammarAccess.getQualityCharacteristicAccess().getGroup_3_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group_3__2__Impl"


    // $ANTLR start "rule__QualityCharacteristic__Group_3__3"
    // InternalArchQualityDef.g:3983:1: rule__QualityCharacteristic__Group_3__3 : rule__QualityCharacteristic__Group_3__3__Impl ;
    public final void rule__QualityCharacteristic__Group_3__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3987:1: ( rule__QualityCharacteristic__Group_3__3__Impl )
            // InternalArchQualityDef.g:3988:2: rule__QualityCharacteristic__Group_3__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__QualityCharacteristic__Group_3__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group_3__3"


    // $ANTLR start "rule__QualityCharacteristic__Group_3__3__Impl"
    // InternalArchQualityDef.g:3994:1: rule__QualityCharacteristic__Group_3__3__Impl : ( ']' ) ;
    public final void rule__QualityCharacteristic__Group_3__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:3998:1: ( ( ']' ) )
            // InternalArchQualityDef.g:3999:1: ( ']' )
            {
            // InternalArchQualityDef.g:3999:1: ( ']' )
            // InternalArchQualityDef.g:4000:2: ']'
            {
             before(grammarAccess.getQualityCharacteristicAccess().getRightSquareBracketKeyword_3_3()); 
            match(input,46,FOLLOW_2); 
             after(grammarAccess.getQualityCharacteristicAccess().getRightSquareBracketKeyword_3_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group_3__3__Impl"


    // $ANTLR start "rule__QualityCharacteristic__Group_3_2__0"
    // InternalArchQualityDef.g:4010:1: rule__QualityCharacteristic__Group_3_2__0 : rule__QualityCharacteristic__Group_3_2__0__Impl rule__QualityCharacteristic__Group_3_2__1 ;
    public final void rule__QualityCharacteristic__Group_3_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4014:1: ( rule__QualityCharacteristic__Group_3_2__0__Impl rule__QualityCharacteristic__Group_3_2__1 )
            // InternalArchQualityDef.g:4015:2: rule__QualityCharacteristic__Group_3_2__0__Impl rule__QualityCharacteristic__Group_3_2__1
            {
            pushFollow(FOLLOW_20);
            rule__QualityCharacteristic__Group_3_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityCharacteristic__Group_3_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group_3_2__0"


    // $ANTLR start "rule__QualityCharacteristic__Group_3_2__0__Impl"
    // InternalArchQualityDef.g:4022:1: rule__QualityCharacteristic__Group_3_2__0__Impl : ( ',' ) ;
    public final void rule__QualityCharacteristic__Group_3_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4026:1: ( ( ',' ) )
            // InternalArchQualityDef.g:4027:1: ( ',' )
            {
            // InternalArchQualityDef.g:4027:1: ( ',' )
            // InternalArchQualityDef.g:4028:2: ','
            {
             before(grammarAccess.getQualityCharacteristicAccess().getCommaKeyword_3_2_0()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getQualityCharacteristicAccess().getCommaKeyword_3_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group_3_2__0__Impl"


    // $ANTLR start "rule__QualityCharacteristic__Group_3_2__1"
    // InternalArchQualityDef.g:4037:1: rule__QualityCharacteristic__Group_3_2__1 : rule__QualityCharacteristic__Group_3_2__1__Impl ;
    public final void rule__QualityCharacteristic__Group_3_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4041:1: ( rule__QualityCharacteristic__Group_3_2__1__Impl )
            // InternalArchQualityDef.g:4042:2: rule__QualityCharacteristic__Group_3_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__QualityCharacteristic__Group_3_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group_3_2__1"


    // $ANTLR start "rule__QualityCharacteristic__Group_3_2__1__Impl"
    // InternalArchQualityDef.g:4048:1: rule__QualityCharacteristic__Group_3_2__1__Impl : ( ( rule__QualityCharacteristic__EvidenceAssignment_3_2_1 ) ) ;
    public final void rule__QualityCharacteristic__Group_3_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4052:1: ( ( ( rule__QualityCharacteristic__EvidenceAssignment_3_2_1 ) ) )
            // InternalArchQualityDef.g:4053:1: ( ( rule__QualityCharacteristic__EvidenceAssignment_3_2_1 ) )
            {
            // InternalArchQualityDef.g:4053:1: ( ( rule__QualityCharacteristic__EvidenceAssignment_3_2_1 ) )
            // InternalArchQualityDef.g:4054:2: ( rule__QualityCharacteristic__EvidenceAssignment_3_2_1 )
            {
             before(grammarAccess.getQualityCharacteristicAccess().getEvidenceAssignment_3_2_1()); 
            // InternalArchQualityDef.g:4055:2: ( rule__QualityCharacteristic__EvidenceAssignment_3_2_1 )
            // InternalArchQualityDef.g:4055:3: rule__QualityCharacteristic__EvidenceAssignment_3_2_1
            {
            pushFollow(FOLLOW_2);
            rule__QualityCharacteristic__EvidenceAssignment_3_2_1();

            state._fsp--;


            }

             after(grammarAccess.getQualityCharacteristicAccess().getEvidenceAssignment_3_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__Group_3_2__1__Impl"


    // $ANTLR start "rule__QualityRel__Group__0"
    // InternalArchQualityDef.g:4064:1: rule__QualityRel__Group__0 : rule__QualityRel__Group__0__Impl rule__QualityRel__Group__1 ;
    public final void rule__QualityRel__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4068:1: ( rule__QualityRel__Group__0__Impl rule__QualityRel__Group__1 )
            // InternalArchQualityDef.g:4069:2: rule__QualityRel__Group__0__Impl rule__QualityRel__Group__1
            {
            pushFollow(FOLLOW_24);
            rule__QualityRel__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityRel__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group__0"


    // $ANTLR start "rule__QualityRel__Group__0__Impl"
    // InternalArchQualityDef.g:4076:1: rule__QualityRel__Group__0__Impl : ( ( rule__QualityRel__SrcAssignment_0 ) ) ;
    public final void rule__QualityRel__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4080:1: ( ( ( rule__QualityRel__SrcAssignment_0 ) ) )
            // InternalArchQualityDef.g:4081:1: ( ( rule__QualityRel__SrcAssignment_0 ) )
            {
            // InternalArchQualityDef.g:4081:1: ( ( rule__QualityRel__SrcAssignment_0 ) )
            // InternalArchQualityDef.g:4082:2: ( rule__QualityRel__SrcAssignment_0 )
            {
             before(grammarAccess.getQualityRelAccess().getSrcAssignment_0()); 
            // InternalArchQualityDef.g:4083:2: ( rule__QualityRel__SrcAssignment_0 )
            // InternalArchQualityDef.g:4083:3: rule__QualityRel__SrcAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__QualityRel__SrcAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getQualityRelAccess().getSrcAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group__0__Impl"


    // $ANTLR start "rule__QualityRel__Group__1"
    // InternalArchQualityDef.g:4091:1: rule__QualityRel__Group__1 : rule__QualityRel__Group__1__Impl rule__QualityRel__Group__2 ;
    public final void rule__QualityRel__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4095:1: ( rule__QualityRel__Group__1__Impl rule__QualityRel__Group__2 )
            // InternalArchQualityDef.g:4096:2: rule__QualityRel__Group__1__Impl rule__QualityRel__Group__2
            {
            pushFollow(FOLLOW_20);
            rule__QualityRel__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityRel__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group__1"


    // $ANTLR start "rule__QualityRel__Group__1__Impl"
    // InternalArchQualityDef.g:4103:1: rule__QualityRel__Group__1__Impl : ( '->' ) ;
    public final void rule__QualityRel__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4107:1: ( ( '->' ) )
            // InternalArchQualityDef.g:4108:1: ( '->' )
            {
            // InternalArchQualityDef.g:4108:1: ( '->' )
            // InternalArchQualityDef.g:4109:2: '->'
            {
             before(grammarAccess.getQualityRelAccess().getHyphenMinusGreaterThanSignKeyword_1()); 
            match(input,49,FOLLOW_2); 
             after(grammarAccess.getQualityRelAccess().getHyphenMinusGreaterThanSignKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group__1__Impl"


    // $ANTLR start "rule__QualityRel__Group__2"
    // InternalArchQualityDef.g:4118:1: rule__QualityRel__Group__2 : rule__QualityRel__Group__2__Impl rule__QualityRel__Group__3 ;
    public final void rule__QualityRel__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4122:1: ( rule__QualityRel__Group__2__Impl rule__QualityRel__Group__3 )
            // InternalArchQualityDef.g:4123:2: rule__QualityRel__Group__2__Impl rule__QualityRel__Group__3
            {
            pushFollow(FOLLOW_25);
            rule__QualityRel__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityRel__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group__2"


    // $ANTLR start "rule__QualityRel__Group__2__Impl"
    // InternalArchQualityDef.g:4130:1: rule__QualityRel__Group__2__Impl : ( ( rule__QualityRel__TrgAssignment_2 ) ) ;
    public final void rule__QualityRel__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4134:1: ( ( ( rule__QualityRel__TrgAssignment_2 ) ) )
            // InternalArchQualityDef.g:4135:1: ( ( rule__QualityRel__TrgAssignment_2 ) )
            {
            // InternalArchQualityDef.g:4135:1: ( ( rule__QualityRel__TrgAssignment_2 ) )
            // InternalArchQualityDef.g:4136:2: ( rule__QualityRel__TrgAssignment_2 )
            {
             before(grammarAccess.getQualityRelAccess().getTrgAssignment_2()); 
            // InternalArchQualityDef.g:4137:2: ( rule__QualityRel__TrgAssignment_2 )
            // InternalArchQualityDef.g:4137:3: rule__QualityRel__TrgAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__QualityRel__TrgAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getQualityRelAccess().getTrgAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group__2__Impl"


    // $ANTLR start "rule__QualityRel__Group__3"
    // InternalArchQualityDef.g:4145:1: rule__QualityRel__Group__3 : rule__QualityRel__Group__3__Impl ;
    public final void rule__QualityRel__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4149:1: ( rule__QualityRel__Group__3__Impl )
            // InternalArchQualityDef.g:4150:2: rule__QualityRel__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__QualityRel__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group__3"


    // $ANTLR start "rule__QualityRel__Group__3__Impl"
    // InternalArchQualityDef.g:4156:1: rule__QualityRel__Group__3__Impl : ( ( rule__QualityRel__Group_3__0 )? ) ;
    public final void rule__QualityRel__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4160:1: ( ( ( rule__QualityRel__Group_3__0 )? ) )
            // InternalArchQualityDef.g:4161:1: ( ( rule__QualityRel__Group_3__0 )? )
            {
            // InternalArchQualityDef.g:4161:1: ( ( rule__QualityRel__Group_3__0 )? )
            // InternalArchQualityDef.g:4162:2: ( rule__QualityRel__Group_3__0 )?
            {
             before(grammarAccess.getQualityRelAccess().getGroup_3()); 
            // InternalArchQualityDef.g:4163:2: ( rule__QualityRel__Group_3__0 )?
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==45) ) {
                alt31=1;
            }
            switch (alt31) {
                case 1 :
                    // InternalArchQualityDef.g:4163:3: rule__QualityRel__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__QualityRel__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getQualityRelAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group__3__Impl"


    // $ANTLR start "rule__QualityRel__Group_3__0"
    // InternalArchQualityDef.g:4172:1: rule__QualityRel__Group_3__0 : rule__QualityRel__Group_3__0__Impl rule__QualityRel__Group_3__1 ;
    public final void rule__QualityRel__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4176:1: ( rule__QualityRel__Group_3__0__Impl rule__QualityRel__Group_3__1 )
            // InternalArchQualityDef.g:4177:2: rule__QualityRel__Group_3__0__Impl rule__QualityRel__Group_3__1
            {
            pushFollow(FOLLOW_20);
            rule__QualityRel__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityRel__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group_3__0"


    // $ANTLR start "rule__QualityRel__Group_3__0__Impl"
    // InternalArchQualityDef.g:4184:1: rule__QualityRel__Group_3__0__Impl : ( '[' ) ;
    public final void rule__QualityRel__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4188:1: ( ( '[' ) )
            // InternalArchQualityDef.g:4189:1: ( '[' )
            {
            // InternalArchQualityDef.g:4189:1: ( '[' )
            // InternalArchQualityDef.g:4190:2: '['
            {
             before(grammarAccess.getQualityRelAccess().getLeftSquareBracketKeyword_3_0()); 
            match(input,45,FOLLOW_2); 
             after(grammarAccess.getQualityRelAccess().getLeftSquareBracketKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group_3__0__Impl"


    // $ANTLR start "rule__QualityRel__Group_3__1"
    // InternalArchQualityDef.g:4199:1: rule__QualityRel__Group_3__1 : rule__QualityRel__Group_3__1__Impl rule__QualityRel__Group_3__2 ;
    public final void rule__QualityRel__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4203:1: ( rule__QualityRel__Group_3__1__Impl rule__QualityRel__Group_3__2 )
            // InternalArchQualityDef.g:4204:2: rule__QualityRel__Group_3__1__Impl rule__QualityRel__Group_3__2
            {
            pushFollow(FOLLOW_23);
            rule__QualityRel__Group_3__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityRel__Group_3__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group_3__1"


    // $ANTLR start "rule__QualityRel__Group_3__1__Impl"
    // InternalArchQualityDef.g:4211:1: rule__QualityRel__Group_3__1__Impl : ( ( rule__QualityRel__EvidenceAssignment_3_1 ) ) ;
    public final void rule__QualityRel__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4215:1: ( ( ( rule__QualityRel__EvidenceAssignment_3_1 ) ) )
            // InternalArchQualityDef.g:4216:1: ( ( rule__QualityRel__EvidenceAssignment_3_1 ) )
            {
            // InternalArchQualityDef.g:4216:1: ( ( rule__QualityRel__EvidenceAssignment_3_1 ) )
            // InternalArchQualityDef.g:4217:2: ( rule__QualityRel__EvidenceAssignment_3_1 )
            {
             before(grammarAccess.getQualityRelAccess().getEvidenceAssignment_3_1()); 
            // InternalArchQualityDef.g:4218:2: ( rule__QualityRel__EvidenceAssignment_3_1 )
            // InternalArchQualityDef.g:4218:3: rule__QualityRel__EvidenceAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__QualityRel__EvidenceAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getQualityRelAccess().getEvidenceAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group_3__1__Impl"


    // $ANTLR start "rule__QualityRel__Group_3__2"
    // InternalArchQualityDef.g:4226:1: rule__QualityRel__Group_3__2 : rule__QualityRel__Group_3__2__Impl rule__QualityRel__Group_3__3 ;
    public final void rule__QualityRel__Group_3__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4230:1: ( rule__QualityRel__Group_3__2__Impl rule__QualityRel__Group_3__3 )
            // InternalArchQualityDef.g:4231:2: rule__QualityRel__Group_3__2__Impl rule__QualityRel__Group_3__3
            {
            pushFollow(FOLLOW_23);
            rule__QualityRel__Group_3__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityRel__Group_3__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group_3__2"


    // $ANTLR start "rule__QualityRel__Group_3__2__Impl"
    // InternalArchQualityDef.g:4238:1: rule__QualityRel__Group_3__2__Impl : ( ( rule__QualityRel__Group_3_2__0 )* ) ;
    public final void rule__QualityRel__Group_3__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4242:1: ( ( ( rule__QualityRel__Group_3_2__0 )* ) )
            // InternalArchQualityDef.g:4243:1: ( ( rule__QualityRel__Group_3_2__0 )* )
            {
            // InternalArchQualityDef.g:4243:1: ( ( rule__QualityRel__Group_3_2__0 )* )
            // InternalArchQualityDef.g:4244:2: ( rule__QualityRel__Group_3_2__0 )*
            {
             before(grammarAccess.getQualityRelAccess().getGroup_3_2()); 
            // InternalArchQualityDef.g:4245:2: ( rule__QualityRel__Group_3_2__0 )*
            loop32:
            do {
                int alt32=2;
                int LA32_0 = input.LA(1);

                if ( (LA32_0==23) ) {
                    alt32=1;
                }


                switch (alt32) {
            	case 1 :
            	    // InternalArchQualityDef.g:4245:3: rule__QualityRel__Group_3_2__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__QualityRel__Group_3_2__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop32;
                }
            } while (true);

             after(grammarAccess.getQualityRelAccess().getGroup_3_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group_3__2__Impl"


    // $ANTLR start "rule__QualityRel__Group_3__3"
    // InternalArchQualityDef.g:4253:1: rule__QualityRel__Group_3__3 : rule__QualityRel__Group_3__3__Impl ;
    public final void rule__QualityRel__Group_3__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4257:1: ( rule__QualityRel__Group_3__3__Impl )
            // InternalArchQualityDef.g:4258:2: rule__QualityRel__Group_3__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__QualityRel__Group_3__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group_3__3"


    // $ANTLR start "rule__QualityRel__Group_3__3__Impl"
    // InternalArchQualityDef.g:4264:1: rule__QualityRel__Group_3__3__Impl : ( ']' ) ;
    public final void rule__QualityRel__Group_3__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4268:1: ( ( ']' ) )
            // InternalArchQualityDef.g:4269:1: ( ']' )
            {
            // InternalArchQualityDef.g:4269:1: ( ']' )
            // InternalArchQualityDef.g:4270:2: ']'
            {
             before(grammarAccess.getQualityRelAccess().getRightSquareBracketKeyword_3_3()); 
            match(input,46,FOLLOW_2); 
             after(grammarAccess.getQualityRelAccess().getRightSquareBracketKeyword_3_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group_3__3__Impl"


    // $ANTLR start "rule__QualityRel__Group_3_2__0"
    // InternalArchQualityDef.g:4280:1: rule__QualityRel__Group_3_2__0 : rule__QualityRel__Group_3_2__0__Impl rule__QualityRel__Group_3_2__1 ;
    public final void rule__QualityRel__Group_3_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4284:1: ( rule__QualityRel__Group_3_2__0__Impl rule__QualityRel__Group_3_2__1 )
            // InternalArchQualityDef.g:4285:2: rule__QualityRel__Group_3_2__0__Impl rule__QualityRel__Group_3_2__1
            {
            pushFollow(FOLLOW_20);
            rule__QualityRel__Group_3_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__QualityRel__Group_3_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group_3_2__0"


    // $ANTLR start "rule__QualityRel__Group_3_2__0__Impl"
    // InternalArchQualityDef.g:4292:1: rule__QualityRel__Group_3_2__0__Impl : ( ',' ) ;
    public final void rule__QualityRel__Group_3_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4296:1: ( ( ',' ) )
            // InternalArchQualityDef.g:4297:1: ( ',' )
            {
            // InternalArchQualityDef.g:4297:1: ( ',' )
            // InternalArchQualityDef.g:4298:2: ','
            {
             before(grammarAccess.getQualityRelAccess().getCommaKeyword_3_2_0()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getQualityRelAccess().getCommaKeyword_3_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group_3_2__0__Impl"


    // $ANTLR start "rule__QualityRel__Group_3_2__1"
    // InternalArchQualityDef.g:4307:1: rule__QualityRel__Group_3_2__1 : rule__QualityRel__Group_3_2__1__Impl ;
    public final void rule__QualityRel__Group_3_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4311:1: ( rule__QualityRel__Group_3_2__1__Impl )
            // InternalArchQualityDef.g:4312:2: rule__QualityRel__Group_3_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__QualityRel__Group_3_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group_3_2__1"


    // $ANTLR start "rule__QualityRel__Group_3_2__1__Impl"
    // InternalArchQualityDef.g:4318:1: rule__QualityRel__Group_3_2__1__Impl : ( ( rule__QualityRel__EvidenceAssignment_3_2_1 ) ) ;
    public final void rule__QualityRel__Group_3_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4322:1: ( ( ( rule__QualityRel__EvidenceAssignment_3_2_1 ) ) )
            // InternalArchQualityDef.g:4323:1: ( ( rule__QualityRel__EvidenceAssignment_3_2_1 ) )
            {
            // InternalArchQualityDef.g:4323:1: ( ( rule__QualityRel__EvidenceAssignment_3_2_1 ) )
            // InternalArchQualityDef.g:4324:2: ( rule__QualityRel__EvidenceAssignment_3_2_1 )
            {
             before(grammarAccess.getQualityRelAccess().getEvidenceAssignment_3_2_1()); 
            // InternalArchQualityDef.g:4325:2: ( rule__QualityRel__EvidenceAssignment_3_2_1 )
            // InternalArchQualityDef.g:4325:3: rule__QualityRel__EvidenceAssignment_3_2_1
            {
            pushFollow(FOLLOW_2);
            rule__QualityRel__EvidenceAssignment_3_2_1();

            state._fsp--;


            }

             after(grammarAccess.getQualityRelAccess().getEvidenceAssignment_3_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__Group_3_2__1__Impl"


    // $ANTLR start "rule__ArchQualityModel__LastupdateAssignment_3_0"
    // InternalArchQualityDef.g:4334:1: rule__ArchQualityModel__LastupdateAssignment_3_0 : ( ruleEDate ) ;
    public final void rule__ArchQualityModel__LastupdateAssignment_3_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4338:1: ( ( ruleEDate ) )
            // InternalArchQualityDef.g:4339:2: ( ruleEDate )
            {
            // InternalArchQualityDef.g:4339:2: ( ruleEDate )
            // InternalArchQualityDef.g:4340:3: ruleEDate
            {
             before(grammarAccess.getArchQualityModelAccess().getLastupdateEDateParserRuleCall_3_0_0()); 
            pushFollow(FOLLOW_2);
            ruleEDate();

            state._fsp--;

             after(grammarAccess.getArchQualityModelAccess().getLastupdateEDateParserRuleCall_3_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__LastupdateAssignment_3_0"


    // $ANTLR start "rule__ArchQualityModel__ResearchAssignment_4_2"
    // InternalArchQualityDef.g:4349:1: rule__ArchQualityModel__ResearchAssignment_4_2 : ( ruleResearchContribution ) ;
    public final void rule__ArchQualityModel__ResearchAssignment_4_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4353:1: ( ( ruleResearchContribution ) )
            // InternalArchQualityDef.g:4354:2: ( ruleResearchContribution )
            {
            // InternalArchQualityDef.g:4354:2: ( ruleResearchContribution )
            // InternalArchQualityDef.g:4355:3: ruleResearchContribution
            {
             before(grammarAccess.getArchQualityModelAccess().getResearchResearchContributionParserRuleCall_4_2_0()); 
            pushFollow(FOLLOW_2);
            ruleResearchContribution();

            state._fsp--;

             after(grammarAccess.getArchQualityModelAccess().getResearchResearchContributionParserRuleCall_4_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__ResearchAssignment_4_2"


    // $ANTLR start "rule__ArchQualityModel__ResearchAssignment_4_3_1"
    // InternalArchQualityDef.g:4364:1: rule__ArchQualityModel__ResearchAssignment_4_3_1 : ( ruleResearchContribution ) ;
    public final void rule__ArchQualityModel__ResearchAssignment_4_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4368:1: ( ( ruleResearchContribution ) )
            // InternalArchQualityDef.g:4369:2: ( ruleResearchContribution )
            {
            // InternalArchQualityDef.g:4369:2: ( ruleResearchContribution )
            // InternalArchQualityDef.g:4370:3: ruleResearchContribution
            {
             before(grammarAccess.getArchQualityModelAccess().getResearchResearchContributionParserRuleCall_4_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleResearchContribution();

            state._fsp--;

             after(grammarAccess.getArchQualityModelAccess().getResearchResearchContributionParserRuleCall_4_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__ResearchAssignment_4_3_1"


    // $ANTLR start "rule__ArchQualityModel__QualitydefAssignment_5_2"
    // InternalArchQualityDef.g:4379:1: rule__ArchQualityModel__QualitydefAssignment_5_2 : ( ruleQualityElement ) ;
    public final void rule__ArchQualityModel__QualitydefAssignment_5_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4383:1: ( ( ruleQualityElement ) )
            // InternalArchQualityDef.g:4384:2: ( ruleQualityElement )
            {
            // InternalArchQualityDef.g:4384:2: ( ruleQualityElement )
            // InternalArchQualityDef.g:4385:3: ruleQualityElement
            {
             before(grammarAccess.getArchQualityModelAccess().getQualitydefQualityElementParserRuleCall_5_2_0()); 
            pushFollow(FOLLOW_2);
            ruleQualityElement();

            state._fsp--;

             after(grammarAccess.getArchQualityModelAccess().getQualitydefQualityElementParserRuleCall_5_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__QualitydefAssignment_5_2"


    // $ANTLR start "rule__ArchQualityModel__QualitydefAssignment_5_3_1"
    // InternalArchQualityDef.g:4394:1: rule__ArchQualityModel__QualitydefAssignment_5_3_1 : ( ruleQualityElement ) ;
    public final void rule__ArchQualityModel__QualitydefAssignment_5_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4398:1: ( ( ruleQualityElement ) )
            // InternalArchQualityDef.g:4399:2: ( ruleQualityElement )
            {
            // InternalArchQualityDef.g:4399:2: ( ruleQualityElement )
            // InternalArchQualityDef.g:4400:3: ruleQualityElement
            {
             before(grammarAccess.getArchQualityModelAccess().getQualitydefQualityElementParserRuleCall_5_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleQualityElement();

            state._fsp--;

             after(grammarAccess.getArchQualityModelAccess().getQualitydefQualityElementParserRuleCall_5_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArchQualityModel__QualitydefAssignment_5_3_1"


    // $ANTLR start "rule__Author__NameAssignment"
    // InternalArchQualityDef.g:4409:1: rule__Author__NameAssignment : ( ( rule__Author__NameAlternatives_0 ) ) ;
    public final void rule__Author__NameAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4413:1: ( ( ( rule__Author__NameAlternatives_0 ) ) )
            // InternalArchQualityDef.g:4414:2: ( ( rule__Author__NameAlternatives_0 ) )
            {
            // InternalArchQualityDef.g:4414:2: ( ( rule__Author__NameAlternatives_0 ) )
            // InternalArchQualityDef.g:4415:3: ( rule__Author__NameAlternatives_0 )
            {
             before(grammarAccess.getAuthorAccess().getNameAlternatives_0()); 
            // InternalArchQualityDef.g:4416:3: ( rule__Author__NameAlternatives_0 )
            // InternalArchQualityDef.g:4416:4: rule__Author__NameAlternatives_0
            {
            pushFollow(FOLLOW_2);
            rule__Author__NameAlternatives_0();

            state._fsp--;


            }

             after(grammarAccess.getAuthorAccess().getNameAlternatives_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Author__NameAssignment"


    // $ANTLR start "rule__Field__AuthorsAssignment_1_0_2"
    // InternalArchQualityDef.g:4424:1: rule__Field__AuthorsAssignment_1_0_2 : ( ruleAuthor ) ;
    public final void rule__Field__AuthorsAssignment_1_0_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4428:1: ( ( ruleAuthor ) )
            // InternalArchQualityDef.g:4429:2: ( ruleAuthor )
            {
            // InternalArchQualityDef.g:4429:2: ( ruleAuthor )
            // InternalArchQualityDef.g:4430:3: ruleAuthor
            {
             before(grammarAccess.getFieldAccess().getAuthorsAuthorParserRuleCall_1_0_2_0()); 
            pushFollow(FOLLOW_2);
            ruleAuthor();

            state._fsp--;

             after(grammarAccess.getFieldAccess().getAuthorsAuthorParserRuleCall_1_0_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__AuthorsAssignment_1_0_2"


    // $ANTLR start "rule__Field__AuthorsAssignment_1_0_3_1"
    // InternalArchQualityDef.g:4439:1: rule__Field__AuthorsAssignment_1_0_3_1 : ( ruleAuthor ) ;
    public final void rule__Field__AuthorsAssignment_1_0_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4443:1: ( ( ruleAuthor ) )
            // InternalArchQualityDef.g:4444:2: ( ruleAuthor )
            {
            // InternalArchQualityDef.g:4444:2: ( ruleAuthor )
            // InternalArchQualityDef.g:4445:3: ruleAuthor
            {
             before(grammarAccess.getFieldAccess().getAuthorsAuthorParserRuleCall_1_0_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleAuthor();

            state._fsp--;

             after(grammarAccess.getFieldAccess().getAuthorsAuthorParserRuleCall_1_0_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__AuthorsAssignment_1_0_3_1"


    // $ANTLR start "rule__Field__TitleAssignment_1_1_2"
    // InternalArchQualityDef.g:4454:1: rule__Field__TitleAssignment_1_1_2 : ( RULE_STRING ) ;
    public final void rule__Field__TitleAssignment_1_1_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4458:1: ( ( RULE_STRING ) )
            // InternalArchQualityDef.g:4459:2: ( RULE_STRING )
            {
            // InternalArchQualityDef.g:4459:2: ( RULE_STRING )
            // InternalArchQualityDef.g:4460:3: RULE_STRING
            {
             before(grammarAccess.getFieldAccess().getTitleSTRINGTerminalRuleCall_1_1_2_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getTitleSTRINGTerminalRuleCall_1_1_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__TitleAssignment_1_1_2"


    // $ANTLR start "rule__Field__YearAssignment_1_2_2"
    // InternalArchQualityDef.g:4469:1: rule__Field__YearAssignment_1_2_2 : ( RULE_STRING ) ;
    public final void rule__Field__YearAssignment_1_2_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4473:1: ( ( RULE_STRING ) )
            // InternalArchQualityDef.g:4474:2: ( RULE_STRING )
            {
            // InternalArchQualityDef.g:4474:2: ( RULE_STRING )
            // InternalArchQualityDef.g:4475:3: RULE_STRING
            {
             before(grammarAccess.getFieldAccess().getYearSTRINGTerminalRuleCall_1_2_2_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getYearSTRINGTerminalRuleCall_1_2_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__YearAssignment_1_2_2"


    // $ANTLR start "rule__Field__PagesAssignment_1_3_2"
    // InternalArchQualityDef.g:4484:1: rule__Field__PagesAssignment_1_3_2 : ( RULE_STRING ) ;
    public final void rule__Field__PagesAssignment_1_3_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4488:1: ( ( RULE_STRING ) )
            // InternalArchQualityDef.g:4489:2: ( RULE_STRING )
            {
            // InternalArchQualityDef.g:4489:2: ( RULE_STRING )
            // InternalArchQualityDef.g:4490:3: RULE_STRING
            {
             before(grammarAccess.getFieldAccess().getPagesSTRINGTerminalRuleCall_1_3_2_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getPagesSTRINGTerminalRuleCall_1_3_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__PagesAssignment_1_3_2"


    // $ANTLR start "rule__Field__AddressAssignment_1_4_2"
    // InternalArchQualityDef.g:4499:1: rule__Field__AddressAssignment_1_4_2 : ( RULE_STRING ) ;
    public final void rule__Field__AddressAssignment_1_4_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4503:1: ( ( RULE_STRING ) )
            // InternalArchQualityDef.g:4504:2: ( RULE_STRING )
            {
            // InternalArchQualityDef.g:4504:2: ( RULE_STRING )
            // InternalArchQualityDef.g:4505:3: RULE_STRING
            {
             before(grammarAccess.getFieldAccess().getAddressSTRINGTerminalRuleCall_1_4_2_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getAddressSTRINGTerminalRuleCall_1_4_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__AddressAssignment_1_4_2"


    // $ANTLR start "rule__Field__BooktitleAssignment_1_5_2"
    // InternalArchQualityDef.g:4514:1: rule__Field__BooktitleAssignment_1_5_2 : ( RULE_STRING ) ;
    public final void rule__Field__BooktitleAssignment_1_5_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4518:1: ( ( RULE_STRING ) )
            // InternalArchQualityDef.g:4519:2: ( RULE_STRING )
            {
            // InternalArchQualityDef.g:4519:2: ( RULE_STRING )
            // InternalArchQualityDef.g:4520:3: RULE_STRING
            {
             before(grammarAccess.getFieldAccess().getBooktitleSTRINGTerminalRuleCall_1_5_2_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getBooktitleSTRINGTerminalRuleCall_1_5_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__BooktitleAssignment_1_5_2"


    // $ANTLR start "rule__Field__JournalAssignment_1_6_2"
    // InternalArchQualityDef.g:4529:1: rule__Field__JournalAssignment_1_6_2 : ( RULE_STRING ) ;
    public final void rule__Field__JournalAssignment_1_6_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4533:1: ( ( RULE_STRING ) )
            // InternalArchQualityDef.g:4534:2: ( RULE_STRING )
            {
            // InternalArchQualityDef.g:4534:2: ( RULE_STRING )
            // InternalArchQualityDef.g:4535:3: RULE_STRING
            {
             before(grammarAccess.getFieldAccess().getJournalSTRINGTerminalRuleCall_1_6_2_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getJournalSTRINGTerminalRuleCall_1_6_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__JournalAssignment_1_6_2"


    // $ANTLR start "rule__Field__ChapterAssignment_1_7_2"
    // InternalArchQualityDef.g:4544:1: rule__Field__ChapterAssignment_1_7_2 : ( RULE_STRING ) ;
    public final void rule__Field__ChapterAssignment_1_7_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4548:1: ( ( RULE_STRING ) )
            // InternalArchQualityDef.g:4549:2: ( RULE_STRING )
            {
            // InternalArchQualityDef.g:4549:2: ( RULE_STRING )
            // InternalArchQualityDef.g:4550:3: RULE_STRING
            {
             before(grammarAccess.getFieldAccess().getChapterSTRINGTerminalRuleCall_1_7_2_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getChapterSTRINGTerminalRuleCall_1_7_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__ChapterAssignment_1_7_2"


    // $ANTLR start "rule__Field__SeriesAssignment_1_8_2"
    // InternalArchQualityDef.g:4559:1: rule__Field__SeriesAssignment_1_8_2 : ( RULE_STRING ) ;
    public final void rule__Field__SeriesAssignment_1_8_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4563:1: ( ( RULE_STRING ) )
            // InternalArchQualityDef.g:4564:2: ( RULE_STRING )
            {
            // InternalArchQualityDef.g:4564:2: ( RULE_STRING )
            // InternalArchQualityDef.g:4565:3: RULE_STRING
            {
             before(grammarAccess.getFieldAccess().getSeriesSTRINGTerminalRuleCall_1_8_2_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getSeriesSTRINGTerminalRuleCall_1_8_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__SeriesAssignment_1_8_2"


    // $ANTLR start "rule__Field__VolumeAssignment_1_9_2"
    // InternalArchQualityDef.g:4574:1: rule__Field__VolumeAssignment_1_9_2 : ( RULE_STRING ) ;
    public final void rule__Field__VolumeAssignment_1_9_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4578:1: ( ( RULE_STRING ) )
            // InternalArchQualityDef.g:4579:2: ( RULE_STRING )
            {
            // InternalArchQualityDef.g:4579:2: ( RULE_STRING )
            // InternalArchQualityDef.g:4580:3: RULE_STRING
            {
             before(grammarAccess.getFieldAccess().getVolumeSTRINGTerminalRuleCall_1_9_2_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getVolumeSTRINGTerminalRuleCall_1_9_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__VolumeAssignment_1_9_2"


    // $ANTLR start "rule__Field__EditorAssignment_1_10_2"
    // InternalArchQualityDef.g:4589:1: rule__Field__EditorAssignment_1_10_2 : ( RULE_STRING ) ;
    public final void rule__Field__EditorAssignment_1_10_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4593:1: ( ( RULE_STRING ) )
            // InternalArchQualityDef.g:4594:2: ( RULE_STRING )
            {
            // InternalArchQualityDef.g:4594:2: ( RULE_STRING )
            // InternalArchQualityDef.g:4595:3: RULE_STRING
            {
             before(grammarAccess.getFieldAccess().getEditorSTRINGTerminalRuleCall_1_10_2_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getEditorSTRINGTerminalRuleCall_1_10_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__EditorAssignment_1_10_2"


    // $ANTLR start "rule__Field__OrganizationAssignment_1_11_2"
    // InternalArchQualityDef.g:4604:1: rule__Field__OrganizationAssignment_1_11_2 : ( RULE_STRING ) ;
    public final void rule__Field__OrganizationAssignment_1_11_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4608:1: ( ( RULE_STRING ) )
            // InternalArchQualityDef.g:4609:2: ( RULE_STRING )
            {
            // InternalArchQualityDef.g:4609:2: ( RULE_STRING )
            // InternalArchQualityDef.g:4610:3: RULE_STRING
            {
             before(grammarAccess.getFieldAccess().getOrganizationSTRINGTerminalRuleCall_1_11_2_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getOrganizationSTRINGTerminalRuleCall_1_11_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__OrganizationAssignment_1_11_2"


    // $ANTLR start "rule__Field__CitationscountAssignment_1_12_4"
    // InternalArchQualityDef.g:4619:1: rule__Field__CitationscountAssignment_1_12_4 : ( RULE_INT ) ;
    public final void rule__Field__CitationscountAssignment_1_12_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4623:1: ( ( RULE_INT ) )
            // InternalArchQualityDef.g:4624:2: ( RULE_INT )
            {
            // InternalArchQualityDef.g:4624:2: ( RULE_INT )
            // InternalArchQualityDef.g:4625:3: RULE_INT
            {
             before(grammarAccess.getFieldAccess().getCitationscountINTTerminalRuleCall_1_12_4_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getFieldAccess().getCitationscountINTTerminalRuleCall_1_12_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__CitationscountAssignment_1_12_4"


    // $ANTLR start "rule__ResearchContribution__NameAssignment_4"
    // InternalArchQualityDef.g:4634:1: rule__ResearchContribution__NameAssignment_4 : ( RULE_ID ) ;
    public final void rule__ResearchContribution__NameAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4638:1: ( ( RULE_ID ) )
            // InternalArchQualityDef.g:4639:2: ( RULE_ID )
            {
            // InternalArchQualityDef.g:4639:2: ( RULE_ID )
            // InternalArchQualityDef.g:4640:3: RULE_ID
            {
             before(grammarAccess.getResearchContributionAccess().getNameIDTerminalRuleCall_4_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getResearchContributionAccess().getNameIDTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__NameAssignment_4"


    // $ANTLR start "rule__ResearchContribution__FieldsAssignment_6_0"
    // InternalArchQualityDef.g:4649:1: rule__ResearchContribution__FieldsAssignment_6_0 : ( ruleField ) ;
    public final void rule__ResearchContribution__FieldsAssignment_6_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4653:1: ( ( ruleField ) )
            // InternalArchQualityDef.g:4654:2: ( ruleField )
            {
            // InternalArchQualityDef.g:4654:2: ( ruleField )
            // InternalArchQualityDef.g:4655:3: ruleField
            {
             before(grammarAccess.getResearchContributionAccess().getFieldsFieldParserRuleCall_6_0_0()); 
            pushFollow(FOLLOW_2);
            ruleField();

            state._fsp--;

             after(grammarAccess.getResearchContributionAccess().getFieldsFieldParserRuleCall_6_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__FieldsAssignment_6_0"


    // $ANTLR start "rule__ResearchContribution__FieldsAssignment_6_1_1"
    // InternalArchQualityDef.g:4664:1: rule__ResearchContribution__FieldsAssignment_6_1_1 : ( ruleField ) ;
    public final void rule__ResearchContribution__FieldsAssignment_6_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4668:1: ( ( ruleField ) )
            // InternalArchQualityDef.g:4669:2: ( ruleField )
            {
            // InternalArchQualityDef.g:4669:2: ( ruleField )
            // InternalArchQualityDef.g:4670:3: ruleField
            {
             before(grammarAccess.getResearchContributionAccess().getFieldsFieldParserRuleCall_6_1_1_0()); 
            pushFollow(FOLLOW_2);
            ruleField();

            state._fsp--;

             after(grammarAccess.getResearchContributionAccess().getFieldsFieldParserRuleCall_6_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ResearchContribution__FieldsAssignment_6_1_1"


    // $ANTLR start "rule__Metric__NameAssignment_1"
    // InternalArchQualityDef.g:4679:1: rule__Metric__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Metric__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4683:1: ( ( RULE_ID ) )
            // InternalArchQualityDef.g:4684:2: ( RULE_ID )
            {
            // InternalArchQualityDef.g:4684:2: ( RULE_ID )
            // InternalArchQualityDef.g:4685:3: RULE_ID
            {
             before(grammarAccess.getMetricAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getMetricAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__NameAssignment_1"


    // $ANTLR start "rule__Metric__DescriptionAssignment_2_1"
    // InternalArchQualityDef.g:4694:1: rule__Metric__DescriptionAssignment_2_1 : ( RULE_STRING ) ;
    public final void rule__Metric__DescriptionAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4698:1: ( ( RULE_STRING ) )
            // InternalArchQualityDef.g:4699:2: ( RULE_STRING )
            {
            // InternalArchQualityDef.g:4699:2: ( RULE_STRING )
            // InternalArchQualityDef.g:4700:3: RULE_STRING
            {
             before(grammarAccess.getMetricAccess().getDescriptionSTRINGTerminalRuleCall_2_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getMetricAccess().getDescriptionSTRINGTerminalRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__DescriptionAssignment_2_1"


    // $ANTLR start "rule__Metric__EvidenceAssignment_3_1"
    // InternalArchQualityDef.g:4709:1: rule__Metric__EvidenceAssignment_3_1 : ( ( RULE_ID ) ) ;
    public final void rule__Metric__EvidenceAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4713:1: ( ( ( RULE_ID ) ) )
            // InternalArchQualityDef.g:4714:2: ( ( RULE_ID ) )
            {
            // InternalArchQualityDef.g:4714:2: ( ( RULE_ID ) )
            // InternalArchQualityDef.g:4715:3: ( RULE_ID )
            {
             before(grammarAccess.getMetricAccess().getEvidenceResearchContributionCrossReference_3_1_0()); 
            // InternalArchQualityDef.g:4716:3: ( RULE_ID )
            // InternalArchQualityDef.g:4717:4: RULE_ID
            {
             before(grammarAccess.getMetricAccess().getEvidenceResearchContributionIDTerminalRuleCall_3_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getMetricAccess().getEvidenceResearchContributionIDTerminalRuleCall_3_1_0_1()); 

            }

             after(grammarAccess.getMetricAccess().getEvidenceResearchContributionCrossReference_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__EvidenceAssignment_3_1"


    // $ANTLR start "rule__Metric__EvidenceAssignment_3_2_1"
    // InternalArchQualityDef.g:4728:1: rule__Metric__EvidenceAssignment_3_2_1 : ( ( RULE_ID ) ) ;
    public final void rule__Metric__EvidenceAssignment_3_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4732:1: ( ( ( RULE_ID ) ) )
            // InternalArchQualityDef.g:4733:2: ( ( RULE_ID ) )
            {
            // InternalArchQualityDef.g:4733:2: ( ( RULE_ID ) )
            // InternalArchQualityDef.g:4734:3: ( RULE_ID )
            {
             before(grammarAccess.getMetricAccess().getEvidenceResearchContributionCrossReference_3_2_1_0()); 
            // InternalArchQualityDef.g:4735:3: ( RULE_ID )
            // InternalArchQualityDef.g:4736:4: RULE_ID
            {
             before(grammarAccess.getMetricAccess().getEvidenceResearchContributionIDTerminalRuleCall_3_2_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getMetricAccess().getEvidenceResearchContributionIDTerminalRuleCall_3_2_1_0_1()); 

            }

             after(grammarAccess.getMetricAccess().getEvidenceResearchContributionCrossReference_3_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Metric__EvidenceAssignment_3_2_1"


    // $ANTLR start "rule__QualityAttribute__NameAssignment_1"
    // InternalArchQualityDef.g:4747:1: rule__QualityAttribute__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__QualityAttribute__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4751:1: ( ( RULE_ID ) )
            // InternalArchQualityDef.g:4752:2: ( RULE_ID )
            {
            // InternalArchQualityDef.g:4752:2: ( RULE_ID )
            // InternalArchQualityDef.g:4753:3: RULE_ID
            {
             before(grammarAccess.getQualityAttributeAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getQualityAttributeAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__NameAssignment_1"


    // $ANTLR start "rule__QualityAttribute__DescriptionAssignment_2_1"
    // InternalArchQualityDef.g:4762:1: rule__QualityAttribute__DescriptionAssignment_2_1 : ( RULE_STRING ) ;
    public final void rule__QualityAttribute__DescriptionAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4766:1: ( ( RULE_STRING ) )
            // InternalArchQualityDef.g:4767:2: ( RULE_STRING )
            {
            // InternalArchQualityDef.g:4767:2: ( RULE_STRING )
            // InternalArchQualityDef.g:4768:3: RULE_STRING
            {
             before(grammarAccess.getQualityAttributeAccess().getDescriptionSTRINGTerminalRuleCall_2_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getQualityAttributeAccess().getDescriptionSTRINGTerminalRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__DescriptionAssignment_2_1"


    // $ANTLR start "rule__QualityAttribute__EvidenceAssignment_3_1"
    // InternalArchQualityDef.g:4777:1: rule__QualityAttribute__EvidenceAssignment_3_1 : ( ( RULE_ID ) ) ;
    public final void rule__QualityAttribute__EvidenceAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4781:1: ( ( ( RULE_ID ) ) )
            // InternalArchQualityDef.g:4782:2: ( ( RULE_ID ) )
            {
            // InternalArchQualityDef.g:4782:2: ( ( RULE_ID ) )
            // InternalArchQualityDef.g:4783:3: ( RULE_ID )
            {
             before(grammarAccess.getQualityAttributeAccess().getEvidenceResearchContributionCrossReference_3_1_0()); 
            // InternalArchQualityDef.g:4784:3: ( RULE_ID )
            // InternalArchQualityDef.g:4785:4: RULE_ID
            {
             before(grammarAccess.getQualityAttributeAccess().getEvidenceResearchContributionIDTerminalRuleCall_3_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getQualityAttributeAccess().getEvidenceResearchContributionIDTerminalRuleCall_3_1_0_1()); 

            }

             after(grammarAccess.getQualityAttributeAccess().getEvidenceResearchContributionCrossReference_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__EvidenceAssignment_3_1"


    // $ANTLR start "rule__QualityAttribute__EvidenceAssignment_3_2_1"
    // InternalArchQualityDef.g:4796:1: rule__QualityAttribute__EvidenceAssignment_3_2_1 : ( ( RULE_ID ) ) ;
    public final void rule__QualityAttribute__EvidenceAssignment_3_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4800:1: ( ( ( RULE_ID ) ) )
            // InternalArchQualityDef.g:4801:2: ( ( RULE_ID ) )
            {
            // InternalArchQualityDef.g:4801:2: ( ( RULE_ID ) )
            // InternalArchQualityDef.g:4802:3: ( RULE_ID )
            {
             before(grammarAccess.getQualityAttributeAccess().getEvidenceResearchContributionCrossReference_3_2_1_0()); 
            // InternalArchQualityDef.g:4803:3: ( RULE_ID )
            // InternalArchQualityDef.g:4804:4: RULE_ID
            {
             before(grammarAccess.getQualityAttributeAccess().getEvidenceResearchContributionIDTerminalRuleCall_3_2_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getQualityAttributeAccess().getEvidenceResearchContributionIDTerminalRuleCall_3_2_1_0_1()); 

            }

             after(grammarAccess.getQualityAttributeAccess().getEvidenceResearchContributionCrossReference_3_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityAttribute__EvidenceAssignment_3_2_1"


    // $ANTLR start "rule__QualityCharacteristic__NameAssignment_1"
    // InternalArchQualityDef.g:4815:1: rule__QualityCharacteristic__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__QualityCharacteristic__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4819:1: ( ( RULE_ID ) )
            // InternalArchQualityDef.g:4820:2: ( RULE_ID )
            {
            // InternalArchQualityDef.g:4820:2: ( RULE_ID )
            // InternalArchQualityDef.g:4821:3: RULE_ID
            {
             before(grammarAccess.getQualityCharacteristicAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getQualityCharacteristicAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__NameAssignment_1"


    // $ANTLR start "rule__QualityCharacteristic__DescriptionAssignment_2_1"
    // InternalArchQualityDef.g:4830:1: rule__QualityCharacteristic__DescriptionAssignment_2_1 : ( RULE_STRING ) ;
    public final void rule__QualityCharacteristic__DescriptionAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4834:1: ( ( RULE_STRING ) )
            // InternalArchQualityDef.g:4835:2: ( RULE_STRING )
            {
            // InternalArchQualityDef.g:4835:2: ( RULE_STRING )
            // InternalArchQualityDef.g:4836:3: RULE_STRING
            {
             before(grammarAccess.getQualityCharacteristicAccess().getDescriptionSTRINGTerminalRuleCall_2_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getQualityCharacteristicAccess().getDescriptionSTRINGTerminalRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__DescriptionAssignment_2_1"


    // $ANTLR start "rule__QualityCharacteristic__EvidenceAssignment_3_1"
    // InternalArchQualityDef.g:4845:1: rule__QualityCharacteristic__EvidenceAssignment_3_1 : ( ( RULE_ID ) ) ;
    public final void rule__QualityCharacteristic__EvidenceAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4849:1: ( ( ( RULE_ID ) ) )
            // InternalArchQualityDef.g:4850:2: ( ( RULE_ID ) )
            {
            // InternalArchQualityDef.g:4850:2: ( ( RULE_ID ) )
            // InternalArchQualityDef.g:4851:3: ( RULE_ID )
            {
             before(grammarAccess.getQualityCharacteristicAccess().getEvidenceResearchContributionCrossReference_3_1_0()); 
            // InternalArchQualityDef.g:4852:3: ( RULE_ID )
            // InternalArchQualityDef.g:4853:4: RULE_ID
            {
             before(grammarAccess.getQualityCharacteristicAccess().getEvidenceResearchContributionIDTerminalRuleCall_3_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getQualityCharacteristicAccess().getEvidenceResearchContributionIDTerminalRuleCall_3_1_0_1()); 

            }

             after(grammarAccess.getQualityCharacteristicAccess().getEvidenceResearchContributionCrossReference_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__EvidenceAssignment_3_1"


    // $ANTLR start "rule__QualityCharacteristic__EvidenceAssignment_3_2_1"
    // InternalArchQualityDef.g:4864:1: rule__QualityCharacteristic__EvidenceAssignment_3_2_1 : ( ( RULE_ID ) ) ;
    public final void rule__QualityCharacteristic__EvidenceAssignment_3_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4868:1: ( ( ( RULE_ID ) ) )
            // InternalArchQualityDef.g:4869:2: ( ( RULE_ID ) )
            {
            // InternalArchQualityDef.g:4869:2: ( ( RULE_ID ) )
            // InternalArchQualityDef.g:4870:3: ( RULE_ID )
            {
             before(grammarAccess.getQualityCharacteristicAccess().getEvidenceResearchContributionCrossReference_3_2_1_0()); 
            // InternalArchQualityDef.g:4871:3: ( RULE_ID )
            // InternalArchQualityDef.g:4872:4: RULE_ID
            {
             before(grammarAccess.getQualityCharacteristicAccess().getEvidenceResearchContributionIDTerminalRuleCall_3_2_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getQualityCharacteristicAccess().getEvidenceResearchContributionIDTerminalRuleCall_3_2_1_0_1()); 

            }

             after(grammarAccess.getQualityCharacteristicAccess().getEvidenceResearchContributionCrossReference_3_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityCharacteristic__EvidenceAssignment_3_2_1"


    // $ANTLR start "rule__QualityRel__SrcAssignment_0"
    // InternalArchQualityDef.g:4883:1: rule__QualityRel__SrcAssignment_0 : ( ( RULE_ID ) ) ;
    public final void rule__QualityRel__SrcAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4887:1: ( ( ( RULE_ID ) ) )
            // InternalArchQualityDef.g:4888:2: ( ( RULE_ID ) )
            {
            // InternalArchQualityDef.g:4888:2: ( ( RULE_ID ) )
            // InternalArchQualityDef.g:4889:3: ( RULE_ID )
            {
             before(grammarAccess.getQualityRelAccess().getSrcQualityElementCrossReference_0_0()); 
            // InternalArchQualityDef.g:4890:3: ( RULE_ID )
            // InternalArchQualityDef.g:4891:4: RULE_ID
            {
             before(grammarAccess.getQualityRelAccess().getSrcQualityElementIDTerminalRuleCall_0_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getQualityRelAccess().getSrcQualityElementIDTerminalRuleCall_0_0_1()); 

            }

             after(grammarAccess.getQualityRelAccess().getSrcQualityElementCrossReference_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__SrcAssignment_0"


    // $ANTLR start "rule__QualityRel__TrgAssignment_2"
    // InternalArchQualityDef.g:4902:1: rule__QualityRel__TrgAssignment_2 : ( ( RULE_ID ) ) ;
    public final void rule__QualityRel__TrgAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4906:1: ( ( ( RULE_ID ) ) )
            // InternalArchQualityDef.g:4907:2: ( ( RULE_ID ) )
            {
            // InternalArchQualityDef.g:4907:2: ( ( RULE_ID ) )
            // InternalArchQualityDef.g:4908:3: ( RULE_ID )
            {
             before(grammarAccess.getQualityRelAccess().getTrgQualityElementCrossReference_2_0()); 
            // InternalArchQualityDef.g:4909:3: ( RULE_ID )
            // InternalArchQualityDef.g:4910:4: RULE_ID
            {
             before(grammarAccess.getQualityRelAccess().getTrgQualityElementIDTerminalRuleCall_2_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getQualityRelAccess().getTrgQualityElementIDTerminalRuleCall_2_0_1()); 

            }

             after(grammarAccess.getQualityRelAccess().getTrgQualityElementCrossReference_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__TrgAssignment_2"


    // $ANTLR start "rule__QualityRel__EvidenceAssignment_3_1"
    // InternalArchQualityDef.g:4921:1: rule__QualityRel__EvidenceAssignment_3_1 : ( ( RULE_ID ) ) ;
    public final void rule__QualityRel__EvidenceAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4925:1: ( ( ( RULE_ID ) ) )
            // InternalArchQualityDef.g:4926:2: ( ( RULE_ID ) )
            {
            // InternalArchQualityDef.g:4926:2: ( ( RULE_ID ) )
            // InternalArchQualityDef.g:4927:3: ( RULE_ID )
            {
             before(grammarAccess.getQualityRelAccess().getEvidenceResearchContributionCrossReference_3_1_0()); 
            // InternalArchQualityDef.g:4928:3: ( RULE_ID )
            // InternalArchQualityDef.g:4929:4: RULE_ID
            {
             before(grammarAccess.getQualityRelAccess().getEvidenceResearchContributionIDTerminalRuleCall_3_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getQualityRelAccess().getEvidenceResearchContributionIDTerminalRuleCall_3_1_0_1()); 

            }

             after(grammarAccess.getQualityRelAccess().getEvidenceResearchContributionCrossReference_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__EvidenceAssignment_3_1"


    // $ANTLR start "rule__QualityRel__EvidenceAssignment_3_2_1"
    // InternalArchQualityDef.g:4940:1: rule__QualityRel__EvidenceAssignment_3_2_1 : ( ( RULE_ID ) ) ;
    public final void rule__QualityRel__EvidenceAssignment_3_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalArchQualityDef.g:4944:1: ( ( ( RULE_ID ) ) )
            // InternalArchQualityDef.g:4945:2: ( ( RULE_ID ) )
            {
            // InternalArchQualityDef.g:4945:2: ( ( RULE_ID ) )
            // InternalArchQualityDef.g:4946:3: ( RULE_ID )
            {
             before(grammarAccess.getQualityRelAccess().getEvidenceResearchContributionCrossReference_3_2_1_0()); 
            // InternalArchQualityDef.g:4947:3: ( RULE_ID )
            // InternalArchQualityDef.g:4948:4: RULE_ID
            {
             before(grammarAccess.getQualityRelAccess().getEvidenceResearchContributionIDTerminalRuleCall_3_2_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getQualityRelAccess().getEvidenceResearchContributionIDTerminalRuleCall_3_2_1_0_1()); 

            }

             after(grammarAccess.getQualityRelAccess().getEvidenceResearchContributionCrossReference_3_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__QualityRel__EvidenceAssignment_3_2_1"

    // Delegated rules


    protected DFA13 dfa13 = new DFA13(this);
    static final String dfa_1s = "\21\uffff";
    static final String dfa_2s = "\1\5\20\uffff";
    static final String dfa_3s = "\1\24\20\uffff";
    static final String dfa_4s = "\1\47\20\uffff";
    static final String dfa_5s = "\1\uffff\1\1\1\2\1\3\4\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1\14\1\15";
    static final String dfa_6s = "\21\uffff}>";
    static final String[] dfa_7s = {
            "\1\7\2\uffff\1\6\2\uffff\1\1\1\uffff\1\2\1\3\1\4\1\10\1\11\1\12\1\13\1\14\1\15\1\16\1\17\1\20",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final short[] dfa_2 = DFA.unpackEncodedString(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final char[] dfa_4 = DFA.unpackEncodedStringToUnsignedChars(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[] dfa_6 = DFA.unpackEncodedString(dfa_6s);
    static final short[][] dfa_7 = unpackEncodedStringArray(dfa_7s);

    class DFA13 extends DFA {

        public DFA13(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 13;
            this.eot = dfa_1;
            this.eof = dfa_2;
            this.min = dfa_3;
            this.max = dfa_4;
            this.accept = dfa_5;
            this.special = dfa_6;
            this.transition = dfa_7;
        }
        public String getDescription() {
            return "362:1: rule__Field__Alternatives_1 : ( ( ( rule__Field__Group_1_0__0 ) ) | ( ( rule__Field__Group_1_1__0 ) ) | ( ( rule__Field__Group_1_2__0 ) ) | ( ( rule__Field__Group_1_3__0 )? ) | ( ( rule__Field__Group_1_4__0 )? ) | ( ( rule__Field__Group_1_5__0 )? ) | ( ( rule__Field__Group_1_6__0 )? ) | ( ( rule__Field__Group_1_7__0 )? ) | ( ( rule__Field__Group_1_8__0 )? ) | ( ( rule__Field__Group_1_9__0 )? ) | ( ( rule__Field__Group_1_10__0 )? ) | ( ( rule__Field__Group_1_11__0 )? ) | ( ( rule__Field__Group_1_12__0 )? ) );";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000003500000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000900000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000800002L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x00018C0000000010L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x000000FFF4000000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000008100000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x000000000003F800L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000300000000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000400000800000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000200000000000L});

}